# Raz Netflix Premium v3.0

Plugin WordPress para transformar sua área de membros em uma experiência cinematográfica estilo Netflix/Disney+.

## 🆕 Novidades da v3.0

### 1. Sistema de Comentários nas Aulas
- Alunos podem comentar e interagir nas aulas
- Opção de habilitar/desabilitar globalmente ou por curso
- Moderação: alunos podem excluir próprios comentários, admins podem excluir qualquer um

### 2. Progresso Circular por Módulo
- Cada módulo exibe um círculo de progresso em porcentagem
- Visual surpreendente na sidebar das aulas
- Indicação visual clara de conclusão (✓ quando 100%)

### 3. Paleta de Cores Customizável
- 5 cores configuráveis: Accent, Secondary, Background, Surface, Text
- 6 temas prontos: Netflix, Disney+, Spotify, Fire, Purple, Light
- Funciona em todas as páginas do plugin

### 4. Hero na Página "Meus Cursos"
- Adicione imagem ou vídeo de capa no topo
- Configurável no painel frontend do admin

### 5. Capas nos Módulos
- Cada módulo pode ter sua própria imagem de capa
- Aparece nos cards do curso estilo Netflix

### 6. Telas de Login Redesenhadas
- Login, Esqueci Senha e Nova Senha com visual premium
- Efeitos visuais modernos (gradientes, blur, animações)

## 📦 Instalação

1. Faça upload do arquivo `raz-netflix-premium-v3.zip` em **Plugins > Adicionar Novo > Enviar Plugin**
2. Ative o plugin
3. Configure em **Configurações > 🎬 Netflix Premium** ou no painel frontend

## ⚙️ Configuração

### No Admin WordPress
Acesse **Configurações > 🎬 Netflix Premium** para:
- Definir paleta de cores
- Habilitar/desabilitar partículas
- Habilitar/desabilitar comentários globalmente

### No Painel Frontend (Gestão de Cursos)
Inclua o arquivo `templates/admin/netflix-settings.php` no seu template de configurações para ter acesso às opções via frontend.

### Para Capas de Módulos
Inclua o arquivo `templates/admin/module-cover-field.php` no modal de edição de módulos do seu tema.

## 🎨 Integrando as Configurações no Tema

### 1. Adicionar aba de configurações Netflix no painel admin frontend

No arquivo `configuracoes.php` do tema, adicione:

```php
<?php 
// Verificar se o plugin está ativo
if (class_exists('Raz_Netflix_Premium')) {
    include RAZ_NETFLIX_DIR . 'templates/admin/netflix-settings.php';
}
?>
```

### 2. Habilitar comentários por curso

No `curso-editar.php`, na aba de configurações, adicione:

```php
<div class="form-group">
    <label class="form-label">Comentários nas Aulas</label>
    <label class="switch-wrapper">
        <input type="checkbox" name="enable_comments" value="1" 
               <?php checked(get_post_meta($curso_id, '_raz_netflix_enable_comments', true), '1'); ?>>
        <span class="switch-slider"></span>
        Permitir comentários dos alunos
    </label>
</div>
```

### 3. Campo de capa no modal de módulo

No modal de edição de módulo, inclua:

```php
<?php 
if (class_exists('Raz_Netflix_Premium')) {
    include RAZ_NETFLIX_DIR . 'templates/admin/module-cover-field.php';
}
?>
```

E no JavaScript de salvar módulo, adicione:

```javascript
fd.append('modulo_cover', document.getElementById('modulo_cover').value);
```

No handler AJAX de salvar módulo:

```php
if (!empty($_POST['modulo_cover'])) {
    update_post_meta($modulo_id, '_raz_modulo_cover', esc_url_raw($_POST['modulo_cover']));
}
```

## 🗃️ Banco de Dados

O plugin cria uma tabela `{prefix}_raz_lesson_comments` para armazenar os comentários.

## 📝 Opções Salvas

| Opção | Descrição | Padrão |
|-------|-----------|--------|
| `raz_netflix_accent_color` | Cor principal | #e50914 |
| `raz_netflix_secondary_color` | Cor de sucesso | #46d369 |
| `raz_netflix_bg_color` | Cor de fundo | #0a0a0a |
| `raz_netflix_surface_color` | Cor das superfícies | #141414 |
| `raz_netflix_text_color` | Cor do texto | #ffffff |
| `raz_netflix_enable_particles` | Partículas | 1 |
| `raz_netflix_enable_comments` | Comentários | 1 |
| `raz_netflix_meus_cursos_hero` | URL do hero | (vazio) |
| `raz_netflix_meus_cursos_hero_type` | Tipo: image/video | image |

## 🔧 Requisitos

- WordPress 5.8+
- PHP 7.4+
- Tema Raz Midias LMS

## 📄 Licença

Proprietário - Raz Midias
