<?php
/**
 * Plugin Name: Raz Netflix Premium
 * Plugin URI: https://razmidias.com.br
 * Description: Experiência cinematográfica premium estilo Netflix/Disney+ para área de membros.
 * Version: 3.1.0
 * Author: Raz Midias
 * License: Proprietary
 * Text Domain: raz-netflix
 */

defined('ABSPATH') || exit;

define('RAZ_NETFLIX_VERSION', '3.1.0');
define('RAZ_NETFLIX_DIR', plugin_dir_path(__FILE__));
define('RAZ_NETFLIX_URL', plugin_dir_url(__FILE__));

class Raz_Netflix_Premium {
    
    private static $instance = null;
    
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        add_filter('template_include', array($this, 'override_templates'), 999);
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'), 999);
        add_action('wp_head', array($this, 'inject_critical_css'), 1);
        add_action('wp_footer', array($this, 'inject_scripts'));
        add_filter('body_class', array($this, 'add_body_classes'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Injeções no frontend admin
        add_action('wp_footer', array($this, 'inject_admin_settings_fallback'));
        add_action('wp_footer', array($this, 'inject_module_cover_js'));
        
        // AJAX handlers
        add_action('wp_ajax_raz_netflix_get_comments', array($this, 'ajax_get_comments'));
        add_action('wp_ajax_raz_netflix_save_comment', array($this, 'ajax_save_comment'));
        add_action('wp_ajax_raz_netflix_delete_comment', array($this, 'ajax_delete_comment'));
        add_action('wp_ajax_raz_netflix_save_settings_frontend', array($this, 'ajax_save_settings_frontend'));
        add_action('wp_ajax_raz_netflix_save_module_cover', array($this, 'ajax_save_module_cover'));
        
        // Interceptar salvamento de módulo do tema
        add_action('wp_ajax_raz_save_modulo', array($this, 'intercept_save_modulo'), 5);
        
        register_activation_hook(__FILE__, array($this, 'create_tables'));
    }
    
    public function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $table_name = $wpdb->prefix . 'raz_lesson_comments';
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            aula_id bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            comment_text text NOT NULL,
            parent_id bigint(20) unsigned DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            status varchar(20) DEFAULT 'approved',
            PRIMARY KEY (id),
            KEY aula_id (aula_id),
            KEY user_id (user_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        add_option('raz_netflix_accent_color', '#e50914');
        add_option('raz_netflix_secondary_color', '#46d369');
        add_option('raz_netflix_bg_color', '#0a0a0a');
        add_option('raz_netflix_surface_color', '#141414');
        add_option('raz_netflix_text_color', '#ffffff');
        add_option('raz_netflix_enable_particles', '1');
        add_option('raz_netflix_enable_comments', '1');
        add_option('raz_netflix_meus_cursos_hero', '');
        add_option('raz_netflix_meus_cursos_hero_type', 'image');
    }
    
    public function override_templates($template) {
        if (is_singular('aula') && is_user_logged_in()) {
            $t = RAZ_NETFLIX_DIR . 'templates/single-aula-netflix.php';
            if (file_exists($t)) return $t;
        }
        if (is_singular('curso') && is_user_logged_in()) {
            $t = RAZ_NETFLIX_DIR . 'templates/single-curso-netflix.php';
            if (file_exists($t)) return $t;
        }
        if ((is_page_template('page-meus-cursos.php') || (is_page() && get_post_field('post_name') === 'meus-cursos')) && is_user_logged_in()) {
            $t = RAZ_NETFLIX_DIR . 'templates/page-meus-cursos-netflix.php';
            if (file_exists($t)) return $t;
        }
        if (is_page_template('page-login.php') || (is_page() && get_post_field('post_name') === 'login')) {
            $t = RAZ_NETFLIX_DIR . 'templates/page-login-netflix.php';
            if (file_exists($t)) return $t;
        }
        if (is_page_template('page-forgot-password.php') || (is_page() && get_post_field('post_name') === 'esqueci-senha')) {
            $t = RAZ_NETFLIX_DIR . 'templates/page-forgot-password-netflix.php';
            if (file_exists($t)) return $t;
        }
        if (is_page_template('page-reset-password.php') || (is_page() && get_post_field('post_name') === 'nova-senha')) {
            $t = RAZ_NETFLIX_DIR . 'templates/page-reset-password-netflix.php';
            if (file_exists($t)) return $t;
        }
        return $template;
    }
    
    public function enqueue_assets() {
        if (!$this->is_lms_page()) return;
        wp_enqueue_style('raz-netflix-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap', array(), null);
        wp_enqueue_style('raz-netflix-premium', RAZ_NETFLIX_URL . 'assets/css/netflix-premium.css', array(), RAZ_NETFLIX_VERSION);
        wp_enqueue_script('raz-netflix-premium', RAZ_NETFLIX_URL . 'assets/js/netflix-premium.js', array('jquery'), RAZ_NETFLIX_VERSION, true);
        wp_localize_script('raz-netflix-premium', 'razNetflix', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('raz_netflix_nonce'),
        ));
    }
    
    private function is_lms_page() {
        if (is_singular('curso') || is_singular('aula')) return true;
        global $post;
        if ($post && in_array($post->post_name, array('meus-cursos', 'login', 'esqueci-senha', 'nova-senha'))) return true;
        return false;
    }
    
    public function inject_critical_css() {
        if (!$this->is_lms_page() && !is_page(array('login', 'esqueci-senha', 'nova-senha'))) return;
        $accent = get_option('raz_netflix_accent_color', '#e50914');
        $secondary = get_option('raz_netflix_secondary_color', '#46d369');
        $bg = get_option('raz_netflix_bg_color', '#0a0a0a');
        $surface = get_option('raz_netflix_surface_color', '#141414');
        $text = get_option('raz_netflix_text_color', '#ffffff');
        ?>
        <style id="raz-netflix-critical">
            :root {
                --nf-accent: <?php echo esc_attr($accent); ?>;
                --nf-secondary: <?php echo esc_attr($secondary); ?>;
                --nf-bg: <?php echo esc_attr($bg); ?>;
                --nf-surface: <?php echo esc_attr($surface); ?>;
                --nf-text: <?php echo esc_attr($text); ?>;
            }
        </style>
        <?php
    }
    
    public function add_body_classes($classes) {
        if ($this->is_lms_page()) {
            $classes[] = 'raz-netflix-premium';
        }
        return $classes;
    }
    
    public function inject_scripts() {
        if (!$this->is_lms_page()) return;
        echo '<script>document.addEventListener("DOMContentLoaded",function(){document.body.classList.add("nf-loaded")});</script>';
    }
    
    // ========================================
    // INJEÇÃO DAS CONFIGURAÇÕES NO FRONTEND
    // ========================================
    
    public function inject_admin_settings_fallback() {
        global $post;
        if (!$post || $post->post_name !== 'configuracoes') return;
        if (!current_user_can('manage_options')) return;
        
        $accent = get_option('raz_netflix_accent_color', '#e50914');
        $secondary = get_option('raz_netflix_secondary_color', '#46d369');
        $bg_color = get_option('raz_netflix_bg_color', '#0a0a0a');
        $surface = get_option('raz_netflix_surface_color', '#141414');
        $text_color = get_option('raz_netflix_text_color', '#ffffff');
        $particles = get_option('raz_netflix_enable_particles', '1');
        $comments = get_option('raz_netflix_enable_comments', '1');
        $hero_url = get_option('raz_netflix_meus_cursos_hero', '');
        $hero_type = get_option('raz_netflix_meus_cursos_hero_type', 'image');
        $nonce = wp_create_nonce('raz_netflix_nonce');
        ?>
        <div id="netflix-premium-settings" style="margin-top:40px;">
        <style>
        .nf-card{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:24px;margin-bottom:24px;box-shadow:0 1px 3px rgba(0,0,0,0.1)}
        .nf-card h3{margin:0 0 20px;font-size:16px;font-weight:700;display:flex;align-items:center;gap:10px;padding-bottom:14px;border-bottom:1px solid #f1f5f9;color:#1e293b}
        .nf-colors{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:20px}
        .nf-color-item{display:flex;flex-direction:column;gap:8px}
        .nf-color-item label{font-size:13px;font-weight:600;color:#374151}
        .nf-color-wrap{display:flex;align-items:center;gap:10px;background:#f8fafc;padding:8px;border:1px solid #e2e8f0;border-radius:8px}
        .nf-color-wrap input[type="color"]{width:40px;height:32px;padding:0;border:none;background:none;cursor:pointer;border-radius:4px}
        .nf-color-wrap input[type="text"]{flex:1;border:none;background:transparent;font-family:monospace;font-size:13px;text-transform:uppercase}
        .nf-presets{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px;padding-top:16px;border-top:1px solid #f1f5f9}
        .nf-preset{width:36px;height:36px;border-radius:8px;cursor:pointer;border:3px solid transparent;transition:all 0.2s}
        .nf-preset:hover{transform:scale(1.15)}
        .nf-toggle-row{display:flex;align-items:center;justify-content:space-between;padding:14px 0;border-bottom:1px solid #f1f5f9}
        .nf-toggle{position:relative;width:48px;height:26px}
        .nf-toggle input{opacity:0;width:0;height:0}
        .nf-toggle-slider{position:absolute;cursor:pointer;inset:0;background:#cbd5e1;border-radius:13px;transition:0.3s}
        .nf-toggle-slider:before{position:absolute;content:"";height:20px;width:20px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:0.3s}
        .nf-toggle input:checked+.nf-toggle-slider{background:#e50914}
        .nf-toggle input:checked+.nf-toggle-slider:before{transform:translateX(22px)}
        .nf-hero-wrap{display:flex;gap:20px;align-items:flex-start;margin-top:16px}
        .nf-hero-preview{width:240px;height:135px;background:linear-gradient(135deg,#1e293b,#334155);border:2px dashed #475569;border-radius:10px;display:flex;align-items:center;justify-content:center;overflow:hidden}
        .nf-hero-preview img,.nf-hero-preview video{width:100%;height:100%;object-fit:cover}
        .nf-hero-preview.has-media{border-style:solid;border-color:#0891b2}
        .nf-btn-save{display:inline-flex;align-items:center;gap:8px;padding:14px 28px;background:linear-gradient(135deg,#e50914,#b91c1c);color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;transition:all 0.2s;box-shadow:0 4px 15px rgba(229,9,20,0.3)}
        .nf-btn-save:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(229,9,20,0.4)}
        </style>
        
        <div class="nf-card">
            <h3>🎬 Netflix Premium - Paleta de Cores</h3>
            <div class="nf-colors">
                <div class="nf-color-item"><label>Cor Principal</label><div class="nf-color-wrap"><input type="color" id="nf_accent" value="<?php echo esc_attr($accent); ?>"><input type="text" id="nf_accent_hex" value="<?php echo esc_attr($accent); ?>"></div></div>
                <div class="nf-color-item"><label>Cor Secundária</label><div class="nf-color-wrap"><input type="color" id="nf_secondary" value="<?php echo esc_attr($secondary); ?>"><input type="text" id="nf_secondary_hex" value="<?php echo esc_attr($secondary); ?>"></div></div>
                <div class="nf-color-item"><label>Cor de Fundo</label><div class="nf-color-wrap"><input type="color" id="nf_bg" value="<?php echo esc_attr($bg_color); ?>"><input type="text" id="nf_bg_hex" value="<?php echo esc_attr($bg_color); ?>"></div></div>
                <div class="nf-color-item"><label>Cor Superfícies</label><div class="nf-color-wrap"><input type="color" id="nf_surface" value="<?php echo esc_attr($surface); ?>"><input type="text" id="nf_surface_hex" value="<?php echo esc_attr($surface); ?>"></div></div>
                <div class="nf-color-item"><label>Cor do Texto</label><div class="nf-color-wrap"><input type="color" id="nf_text" value="<?php echo esc_attr($text_color); ?>"><input type="text" id="nf_text_hex" value="<?php echo esc_attr($text_color); ?>"></div></div>
            </div>
            <div class="nf-presets">
                <span style="width:100%;font-size:13px;font-weight:600;color:#374151;margin-bottom:8px;">Temas Prontos:</span>
                <div class="nf-preset" style="background:linear-gradient(135deg,#e50914,#0a0a0a)" title="Netflix" onclick="nfPreset('#e50914','#46d369','#0a0a0a','#141414','#ffffff')"></div>
                <div class="nf-preset" style="background:linear-gradient(135deg,#0071eb,#0a0a0a)" title="Disney+" onclick="nfPreset('#0071eb','#00d4aa','#0a0a0a','#1a1d29','#ffffff')"></div>
                <div class="nf-preset" style="background:linear-gradient(135deg,#1db954,#121212)" title="Spotify" onclick="nfPreset('#1db954','#1ed760','#121212','#181818','#ffffff')"></div>
                <div class="nf-preset" style="background:linear-gradient(135deg,#ff6b35,#1a1a2e)" title="Fire" onclick="nfPreset('#ff6b35','#ffc107','#1a1a2e','#16213e','#ffffff')"></div>
                <div class="nf-preset" style="background:linear-gradient(135deg,#667eea,#764ba2)" title="Purple" onclick="nfPreset('#667eea','#764ba2','#0f0f1a','#1a1a2e','#ffffff')"></div>
                <div class="nf-preset" style="background:linear-gradient(135deg,#f59e0b,#1f2937)" title="Gold" onclick="nfPreset('#f59e0b','#fbbf24','#111827','#1f2937','#ffffff')"></div>
            </div>
        </div>
        
        <div class="nf-card">
            <h3>⚙️ Funcionalidades</h3>
            <div class="nf-toggle-row"><div><strong>Partículas de Fundo</strong><br><small style="color:#64748b;">Efeito visual de partículas flutuantes</small></div><label class="nf-toggle"><input type="checkbox" id="nf_particles" <?php checked($particles, '1'); ?>><span class="nf-toggle-slider"></span></label></div>
            <div class="nf-toggle-row"><div><strong>Sistema de Comentários</strong><br><small style="color:#64748b;">Permite comentários nas aulas</small></div><label class="nf-toggle"><input type="checkbox" id="nf_comments" <?php checked($comments, '1'); ?>><span class="nf-toggle-slider"></span></label></div>
        </div>
        
        <div class="nf-card">
            <h3>🖼️ Hero da Página "Meus Cursos"</h3>
            <p style="font-size:13px;color:#64748b;margin-bottom:16px;">Adicione uma imagem ou vídeo de capa no topo.</p>
            <div class="nf-hero-wrap">
                <div class="nf-hero-preview <?php echo $hero_url ? 'has-media' : ''; ?>" id="nf-hero-preview">
                    <?php if ($hero_url) : ?>
                        <?php if ($hero_type === 'video') : ?><video src="<?php echo esc_url($hero_url); ?>" muted autoplay loop></video><?php else : ?><img src="<?php echo esc_url($hero_url); ?>"><?php endif; ?>
                    <?php else : ?><span style="color:#64748b;font-size:12px;">Sem mídia</span><?php endif; ?>
                </div>
                <div style="display:flex;flex-direction:column;gap:10px;">
                    <div style="display:flex;gap:12px;margin-bottom:8px;"><label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;"><input type="radio" name="nf_hero_type" value="image" <?php checked($hero_type, 'image'); ?>> Imagem</label><label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;"><input type="radio" name="nf_hero_type" value="video" <?php checked($hero_type, 'video'); ?>> Vídeo</label></div>
                    <input type="hidden" id="nf_hero_url" value="<?php echo esc_url($hero_url); ?>">
                    <button type="button" style="padding:10px 18px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;cursor:pointer;font-size:13px;" onclick="nfSelectHero()">📷 Selecionar Mídia</button>
                    <?php if ($hero_url) : ?><button type="button" style="background:none;border:none;color:#ef4444;font-size:12px;cursor:pointer;" onclick="nfRemoveHero()">✕ Remover</button><?php endif; ?>
                </div>
            </div>
        </div>
        
        <div style="text-align:right;margin-top:24px;"><button type="button" class="nf-btn-save" onclick="nfSaveSettings()">💾 Salvar Configurações Netflix</button></div>
        </div>
        
        <script>
        (function(){
            ['accent','secondary','bg','surface','text'].forEach(function(id){
                var c=document.getElementById('nf_'+id),h=document.getElementById('nf_'+id+'_hex');
                if(c&&h){c.addEventListener('input',function(){h.value=this.value});h.addEventListener('input',function(){c.value=this.value})}
            });
            
            window.nfPreset=function(a,s,b,f,t){
                document.getElementById('nf_accent').value=a;document.getElementById('nf_accent_hex').value=a;
                document.getElementById('nf_secondary').value=s;document.getElementById('nf_secondary_hex').value=s;
                document.getElementById('nf_bg').value=b;document.getElementById('nf_bg_hex').value=b;
                document.getElementById('nf_surface').value=f;document.getElementById('nf_surface_hex').value=f;
                document.getElementById('nf_text').value=t;document.getElementById('nf_text_hex').value=t;
            };
            
            var heroFrame;
            window.nfSelectHero=function(){
                if(typeof wp==='undefined'||typeof wp.media==='undefined'){alert('Recarregue a página');return}
                if(!heroFrame){heroFrame=wp.media({title:'Selecionar Mídia',button:{text:'Usar'},multiple:false});heroFrame.on('select',function(){var a=heroFrame.state().get('selection').first().toJSON();document.getElementById('nf_hero_url').value=a.url;var p=document.getElementById('nf-hero-preview'),t=document.querySelector('input[name="nf_hero_type"]:checked').value;p.innerHTML=t==='video'?'<video src="'+a.url+'" muted autoplay loop></video>':'<img src="'+a.url+'">';p.classList.add('has-media')})}
                heroFrame.open();
            };
            window.nfRemoveHero=function(){document.getElementById('nf_hero_url').value='';var p=document.getElementById('nf-hero-preview');p.innerHTML='<span style="color:#64748b;font-size:12px;">Sem mídia</span>';p.classList.remove('has-media')};
            
            window.nfSaveSettings=function(){
                var fd=new FormData();
                fd.append('action','raz_netflix_save_settings_frontend');
                fd.append('nonce','<?php echo $nonce; ?>');
                fd.append('accent',document.getElementById('nf_accent').value);
                fd.append('secondary',document.getElementById('nf_secondary').value);
                fd.append('bg',document.getElementById('nf_bg').value);
                fd.append('surface',document.getElementById('nf_surface').value);
                fd.append('text',document.getElementById('nf_text').value);
                fd.append('particles',document.getElementById('nf_particles').checked?'1':'0');
                fd.append('comments',document.getElementById('nf_comments').checked?'1':'0');
                fd.append('hero_url',document.getElementById('nf_hero_url').value);
                fd.append('hero_type',document.querySelector('input[name="nf_hero_type"]:checked').value);
                fetch('<?php echo admin_url('admin-ajax.php'); ?>',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{alert(d.success?'✅ Configurações salvas!':'❌ Erro ao salvar')});
            };
        })();
        </script>
        <?php
    }
    
    public function ajax_save_settings_frontend() {
        check_ajax_referer('raz_netflix_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Não autorizado');
        
        update_option('raz_netflix_accent_color', sanitize_hex_color($_POST['accent']));
        update_option('raz_netflix_secondary_color', sanitize_hex_color($_POST['secondary']));
        update_option('raz_netflix_bg_color', sanitize_hex_color($_POST['bg']));
        update_option('raz_netflix_surface_color', sanitize_hex_color($_POST['surface']));
        update_option('raz_netflix_text_color', sanitize_hex_color($_POST['text']));
        update_option('raz_netflix_enable_particles', sanitize_text_field($_POST['particles']));
        update_option('raz_netflix_enable_comments', sanitize_text_field($_POST['comments']));
        update_option('raz_netflix_meus_cursos_hero', esc_url_raw($_POST['hero_url']));
        update_option('raz_netflix_meus_cursos_hero_type', sanitize_text_field($_POST['hero_type']));
        wp_send_json_success();
    }
    
    // ========================================
    // INJEÇÃO DO CAMPO DE CAPA NO MÓDULO
    // ========================================
    
    public function inject_module_cover_js() {
        global $post;
        $is_admin = false;
        if ($post && in_array($post->post_name, array('curso-editar', 'cursos', 'gestao-cursos'))) $is_admin = true;
        $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        if (strpos($uri, 'gestao-cursos') !== false || strpos($uri, 'curso-editar') !== false) $is_admin = true;
        if (!$is_admin || !current_user_can('edit_posts')) return;
        
        $nonce = wp_create_nonce('raz_netflix_nonce');
        ?>
        <script>
        (function(){
            document.addEventListener('DOMContentLoaded', function(){
                setTimeout(injectCoverField, 500);
                observeModals();
            });
            
            function observeModals(){
                var observer = new MutationObserver(function(mutations){
                    mutations.forEach(function(m){
                        if(m.target.id === 'modal-modulo' && m.target.style.display !== 'none'){
                            setTimeout(injectCoverField, 100);
                        }
                    });
                });
                var modal = document.getElementById('modal-modulo');
                if(modal) observer.observe(modal, {attributes: true, attributeFilter: ['style']});
            }
            
            function injectCoverField(){
                var form = document.getElementById('form-modulo');
                if(!form || document.getElementById('nf-cover-field')) return;
                
                var html = '<div id="nf-cover-field" style="margin-top:20px;padding-top:20px;border-top:1px solid #e2e8f0;">' +
                    '<label style="display:block;margin-bottom:10px;font-weight:600;">🎬 Capa do Módulo (Netflix)</label>' +
                    '<div style="display:flex;gap:16px;align-items:flex-start;">' +
                        '<div id="nf-cover-preview" style="width:160px;height:90px;background:linear-gradient(135deg,#1e293b,#334155);border:2px dashed #475569;border-radius:8px;display:flex;align-items:center;justify-content:center;overflow:hidden;"><span style="color:#64748b;font-size:11px;">Sem capa</span></div>' +
                        '<div style="display:flex;flex-direction:column;gap:8px;">' +
                            '<input type="hidden" name="modulo_cover" id="nf_modulo_cover" value="">' +
                            '<button type="button" class="btn btn-secondary" style="padding:8px 14px;font-size:12px;" onclick="nfPickCover()">📷 Selecionar</button>' +
                            '<button type="button" id="nf-remove-cover" style="font-size:11px;color:#ef4444;background:none;border:none;cursor:pointer;display:none;" onclick="nfClearCover()">✕ Remover</button>' +
                        '</div>' +
                    '</div>' +
                '</div>';
                form.insertAdjacentHTML('beforeend', html);
            }
            
            var coverFrame;
            window.nfPickCover = function(){
                if(typeof wp==='undefined') return;
                if(!coverFrame){
                    coverFrame = wp.media({title:'Capa do Módulo',button:{text:'Usar'},multiple:false,library:{type:'image'}});
                    coverFrame.on('select', function(){
                        var a = coverFrame.state().get('selection').first().toJSON();
                        document.getElementById('nf_modulo_cover').value = a.url;
                        var p = document.getElementById('nf-cover-preview');
                        p.innerHTML = '<img src="'+a.url+'" style="width:100%;height:100%;object-fit:cover;">';
                        p.style.borderStyle = 'solid';
                        p.style.borderColor = '#0891b2';
                        document.getElementById('nf-remove-cover').style.display = 'block';
                    });
                }
                coverFrame.open();
            };
            
            window.nfClearCover = function(){
                document.getElementById('nf_modulo_cover').value = '';
                var p = document.getElementById('nf-cover-preview');
                p.innerHTML = '<span style="color:#64748b;font-size:11px;">Sem capa</span>';
                p.style.borderStyle = 'dashed';
                p.style.borderColor = '#475569';
                document.getElementById('nf-remove-cover').style.display = 'none';
            };
            
            window.nfLoadCover = function(url){
                if(!url) return;
                var input = document.getElementById('nf_modulo_cover');
                if(input) input.value = url;
                var p = document.getElementById('nf-cover-preview');
                if(p){
                    p.innerHTML = '<img src="'+url+'" style="width:100%;height:100%;object-fit:cover;">';
                    p.style.borderStyle = 'solid';
                    p.style.borderColor = '#0891b2';
                }
                var btn = document.getElementById('nf-remove-cover');
                if(btn) btn.style.display = 'block';
            };
        })();
        </script>
        <?php
    }
    
    public function intercept_save_modulo() {
        if (isset($_POST['modulo_cover']) && isset($_POST['modulo_id'])) {
            $modulo_id = intval($_POST['modulo_id']);
            $cover = esc_url_raw($_POST['modulo_cover']);
            if ($modulo_id > 0) {
                update_post_meta($modulo_id, '_raz_modulo_cover', $cover);
            }
        }
    }
    
    public function ajax_save_module_cover() {
        check_ajax_referer('raz_netflix_nonce', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Não autorizado');
        $modulo_id = intval($_POST['modulo_id']);
        $cover_url = esc_url_raw($_POST['cover_url']);
        update_post_meta($modulo_id, '_raz_modulo_cover', $cover_url);
        wp_send_json_success();
    }
    
    // ========================================
    // COMENTÁRIOS
    // ========================================
    
    public function ajax_get_comments() {
        check_ajax_referer('raz_netflix_nonce', 'nonce');
        global $wpdb;
        $aula_id = intval($_POST['aula_id']);
        $user_id = get_current_user_id();
        $table = $wpdb->prefix . 'raz_lesson_comments';
        $comments = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE aula_id = %d AND status = 'approved' ORDER BY created_at DESC", $aula_id));
        $data = array();
        foreach ($comments as $c) {
            $user = get_userdata($c->user_id);
            $data[] = array(
                'id' => $c->id,
                'user_name' => $user ? $user->display_name : 'Usuário',
                'user_avatar' => get_avatar_url($c->user_id, array('size' => 48)),
                'comment_text' => $c->comment_text,
                'time_ago' => human_time_diff(strtotime($c->created_at)) . ' atrás',
                'can_delete' => $c->user_id == $user_id || current_user_can('manage_options')
            );
        }
        wp_send_json_success($data);
    }
    
    public function ajax_save_comment() {
        check_ajax_referer('raz_netflix_nonce', 'nonce');
        global $wpdb;
        $user_id = get_current_user_id();
        $aula_id = intval($_POST['aula_id']);
        $comment_text = sanitize_textarea_field($_POST['comment_text']);
        if (empty($comment_text)) wp_send_json_error('Comentário vazio');
        $table = $wpdb->prefix . 'raz_lesson_comments';
        $wpdb->insert($table, array('aula_id' => $aula_id, 'user_id' => $user_id, 'comment_text' => $comment_text));
        wp_send_json_success(array('id' => $wpdb->insert_id));
    }
    
    public function ajax_delete_comment() {
        check_ajax_referer('raz_netflix_nonce', 'nonce');
        global $wpdb;
        $comment_id = intval($_POST['comment_id']);
        $user_id = get_current_user_id();
        $table = $wpdb->prefix . 'raz_lesson_comments';
        $comment = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $comment_id));
        if (!$comment) wp_send_json_error('Não encontrado');
        if ($comment->user_id != $user_id && !current_user_can('manage_options')) wp_send_json_error('Não autorizado');
        $wpdb->delete($table, array('id' => $comment_id));
        wp_send_json_success();
    }
    
    // ========================================
    // ADMIN WP
    // ========================================
    
    public function add_admin_menu() {
        add_options_page('Netflix Premium', '🎬 Netflix Premium', 'manage_options', 'raz-netflix-premium', array($this, 'settings_page'));
    }
    
    public function register_settings() {
        register_setting('raz_netflix_options', 'raz_netflix_accent_color');
        register_setting('raz_netflix_options', 'raz_netflix_secondary_color');
        register_setting('raz_netflix_options', 'raz_netflix_bg_color');
        register_setting('raz_netflix_options', 'raz_netflix_surface_color');
        register_setting('raz_netflix_options', 'raz_netflix_text_color');
        register_setting('raz_netflix_options', 'raz_netflix_enable_particles');
        register_setting('raz_netflix_options', 'raz_netflix_enable_comments');
    }
    
    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>🎬 Raz Netflix Premium v3.1</h1>
            <p>Configure também no frontend em <strong>Configurações</strong> do painel de gestão.</p>
            <form method="post" action="options.php">
                <?php settings_fields('raz_netflix_options'); ?>
                <table class="form-table">
                    <tr><th>Cor Principal</th><td><input type="color" name="raz_netflix_accent_color" value="<?php echo esc_attr(get_option('raz_netflix_accent_color', '#e50914')); ?>"></td></tr>
                    <tr><th>Cor Secundária</th><td><input type="color" name="raz_netflix_secondary_color" value="<?php echo esc_attr(get_option('raz_netflix_secondary_color', '#46d369')); ?>"></td></tr>
                    <tr><th>Cor de Fundo</th><td><input type="color" name="raz_netflix_bg_color" value="<?php echo esc_attr(get_option('raz_netflix_bg_color', '#0a0a0a')); ?>"></td></tr>
                    <tr><th>Cor Superfícies</th><td><input type="color" name="raz_netflix_surface_color" value="<?php echo esc_attr(get_option('raz_netflix_surface_color', '#141414')); ?>"></td></tr>
                    <tr><th>Cor Texto</th><td><input type="color" name="raz_netflix_text_color" value="<?php echo esc_attr(get_option('raz_netflix_text_color', '#ffffff')); ?>"></td></tr>
                    <tr><th>Partículas</th><td><input type="checkbox" name="raz_netflix_enable_particles" value="1" <?php checked(get_option('raz_netflix_enable_particles', '1'), '1'); ?>></td></tr>
                    <tr><th>Comentários</th><td><input type="checkbox" name="raz_netflix_enable_comments" value="1" <?php checked(get_option('raz_netflix_enable_comments', '1'), '1'); ?>></td></tr>
                </table>
                <?php submit_button('Salvar'); ?>
            </form>
        </div>
        <?php
    }
    
    public static function comments_enabled($curso_id = null) {
        $global = get_option('raz_netflix_enable_comments', '1') === '1';
        if (!$global) return false;
        if ($curso_id) {
            $opt = get_post_meta($curso_id, '_raz_netflix_enable_comments', true);
            if ($opt === '0') return false;
        }
        return true;
    }
}

function raz_netflix_premium_init() {
    return Raz_Netflix_Premium::instance();
}
add_action('plugins_loaded', 'raz_netflix_premium_init');

register_activation_hook(__FILE__, function() {
    Raz_Netflix_Premium::instance()->create_tables();
});