/**
 * Raz Netflix Premium v3 - Main JS
 */
(function($) {
    'use strict';
    
    // Initialize when DOM is ready
    $(document).ready(function() {
        document.body.classList.add('nf-loaded');
        $('.raz-netflix-loading').remove();
    });
    
})(jQuery);
