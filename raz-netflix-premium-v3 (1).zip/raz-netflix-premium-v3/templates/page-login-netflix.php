<?php
/**
 * Template: Login - Netflix Premium
 * @package RazNetflixPremium
 */
if (is_user_logged_in()) {
    $user = wp_get_current_user();
    wp_redirect(in_array('administrator', $user->roles) ? home_url('/gestao-cursos/') : home_url('/meus-cursos/'));
    exit;
}

$accent = get_option('raz_netflix_accent_color', '#e50914');
$bg = get_option('raz_netflix_bg_color', '#0a0a0a');
$login_logo = get_option('raz_lms_login_logo', '');
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_login'])) {
    $user = wp_signon(array('user_login' => sanitize_text_field($_POST['user_login']), 'user_password' => $_POST['user_password'], 'remember' => isset($_POST['remember'])), is_ssl());
    if (is_wp_error($user)) {
        $error = 'Email ou senha incorretos.';
    } else {
        wp_redirect(in_array('administrator', $user->roles) ? home_url('/gestao-cursos/') : home_url('/meus-cursos/'));
        exit;
    }
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Entrar - <?php bloginfo('name'); ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',-apple-system,sans-serif;min-height:100vh;display:flex;background:<?php echo esc_attr($bg); ?>;position:relative;overflow:hidden}
body::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,rgba(229,9,20,0.1) 0%,transparent 50%,rgba(70,211,105,0.05) 100%);pointer-events:none}
body::after{content:'';position:absolute;top:50%;left:50%;width:150vmax;height:150vmax;background:radial-gradient(circle,rgba(229,9,20,0.03) 0%,transparent 50%);transform:translate(-50%,-50%);pointer-events:none;animation:pulse 15s ease-in-out infinite}
@keyframes pulse{0%,100%{transform:translate(-50%,-50%) scale(1)}50%{transform:translate(-50%,-50%) scale(1.1)}}

.login-container{flex:1;display:flex;align-items:center;justify-content:center;padding:20px;position:relative;z-index:1}
.login-box{background:rgba(20,20,20,0.95);backdrop-filter:blur(20px);border-radius:16px;padding:48px 40px;width:100%;max-width:420px;box-shadow:0 25px 80px rgba(0,0,0,0.5),0 0 0 1px rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1)}
.login-logo{text-align:center;margin-bottom:32px}
.login-logo img{max-height:60px;max-width:200px}
.login-logo h1{font-size:28px;font-weight:700;color:#fff;letter-spacing:-0.5px}
.login-title{text-align:center;margin-bottom:8px;font-size:24px;font-weight:600;color:#fff}
.login-subtitle{text-align:center;margin-bottom:32px;color:#a0a0a0;font-size:14px}
.form-group{margin-bottom:24px}
.form-group label{display:block;margin-bottom:8px;font-weight:500;font-size:14px;color:#e5e5e5}
.form-group input{width:100%;padding:16px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:12px;font-size:16px;color:#fff;transition:all 0.2s;font-family:inherit}
.form-group input:focus{outline:none;border-color:<?php echo esc_attr($accent); ?>;background:rgba(255,255,255,0.08);box-shadow:0 0 0 3px rgba(229,9,20,0.15)}
.form-group input::placeholder{color:#6b6b6b}
.password-wrapper{position:relative}
.password-wrapper input{padding-right:48px}
.toggle-password{position:absolute;right:14px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;padding:4px;color:#6b6b6b;transition:color 0.15s}
.toggle-password:hover{color:#a0a0a0}
.toggle-password svg{width:20px;height:20px}
.form-row{display:flex;justify-content:space-between;align-items:center;margin-bottom:28px;flex-wrap:wrap;gap:12px}
.form-row label{display:flex;align-items:center;gap:10px;font-size:14px;color:#a0a0a0;cursor:pointer}
.form-row label input[type="checkbox"]{width:18px;height:18px;accent-color:<?php echo esc_attr($accent); ?>}
.form-row a{font-size:14px;color:<?php echo esc_attr($accent); ?>;text-decoration:none;font-weight:500}
.form-row a:hover{text-decoration:underline}
.btn-login{width:100%;padding:16px;background:<?php echo esc_attr($accent); ?>;color:#fff;border:none;border-radius:12px;font-size:16px;font-weight:600;cursor:pointer;transition:all 0.2s;font-family:inherit;position:relative;overflow:hidden}
.btn-login:hover{filter:brightness(1.1);transform:translateY(-1px);box-shadow:0 10px 30px rgba(229,9,20,0.3)}
.btn-login:active{transform:translateY(0)}
.error-message{background:rgba(239,68,68,0.1);color:#ef4444;padding:14px 16px;border-radius:10px;margin-bottom:24px;font-size:14px;text-align:center;border:1px solid rgba(239,68,68,0.2)}
.divider{display:flex;align-items:center;gap:16px;margin:28px 0;color:#6b6b6b;font-size:13px}
.divider::before,.divider::after{content:'';flex:1;height:1px;background:rgba(255,255,255,0.1)}
.login-footer{text-align:center;margin-top:24px;font-size:14px;color:#6b6b6b}
.login-footer a{color:<?php echo esc_attr($accent); ?>;text-decoration:none;font-weight:500}
@media(max-width:480px){.login-box{padding:32px 24px;border-radius:12px}}
</style>
</head>
<body>
<div class="login-container">
    <div class="login-box">
        <div class="login-logo">
            <?php if ($login_logo) : ?><img src="<?php echo esc_url($login_logo); ?>" alt="<?php bloginfo('name'); ?>">
            <?php else : ?><h1><?php bloginfo('name'); ?></h1><?php endif; ?>
        </div>
        <h2 class="login-title">Bem-vindo de volta</h2>
        <p class="login-subtitle">Entre na sua conta para continuar aprendendo</p>
        <?php if ($error) : ?><div class="error-message"><?php echo esc_html($error); ?></div><?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label>Email</label>
                <input type="text" name="user_login" placeholder="seu@email.com" required autofocus>
            </div>
            <div class="form-group">
                <label>Senha</label>
                <div class="password-wrapper">
                    <input type="password" name="user_password" id="user_password" placeholder="••••••••" required>
                    <button type="button" class="toggle-password" onclick="togglePassword()">
                        <svg id="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        <svg id="eye-off-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:none"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                    </button>
                </div>
            </div>
            <div class="form-row">
                <label><input type="checkbox" name="remember" value="1"> Lembrar de mim</label>
                <a href="<?php echo home_url('/esqueci-senha'); ?>">Esqueceu a senha?</a>
            </div>
            <button type="submit" class="btn-login">Entrar</button>
        </form>
    </div>
</div>
<script>
function togglePassword(){var p=document.getElementById('user_password'),e=document.getElementById('eye-icon'),o=document.getElementById('eye-off-icon');if(p.type==='password'){p.type='text';e.style.display='none';o.style.display='block';}else{p.type='password';e.style.display='block';o.style.display='none';}}
</script>
<?php wp_footer(); ?>
</body>
</html>
