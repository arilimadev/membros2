<?php
/**
 * Template: Single Aula - Netflix Premium Experience v3.1
 * Experiência cinematográfica premium para aulas
 * @package RazNetflixPremium
 */

if (function_exists('raz_validate_access_or_redirect')) {
    if (!raz_validate_access_or_redirect('aula')) return;
}

$aula = get_post();
$aula_id = $aula->ID;
$modulo = function_exists('raz_lms_get_modulo_from_aula') ? raz_lms_get_modulo_from_aula($aula_id) : null;
$curso = function_exists('raz_lms_get_curso_from_aula') ? raz_lms_get_curso_from_aula($aula_id) : null;
$user_id = get_current_user_id();
$user = wp_get_current_user();

// Verificar bloqueio por rotina
$rotina_status = function_exists('raz_lms_check_routine_access') ? raz_lms_check_routine_access($user_id, $aula_id) : array('locked' => false);
$is_locked = isset($rotina_status['locked']) ? $rotina_status['locked'] : false;

// Vídeo
$video_url = get_post_meta($aula_id, '_raz_aula_video_url', true);
$video_provider = get_post_meta($aula_id, '_raz_aula_video_provider', true) ?: '';
$has_video = !empty($video_url) && !empty($video_provider) && !$is_locked;

// Buscar módulos e aulas
$all_modulos = $curso ? (function_exists('raz_lms_get_modulos') ? raz_lms_get_modulos($curso->ID) : array()) : array();
$modulos = array();
$all_aulas_visible = array();

if ($curso && function_exists('raz_user_can_access_modulo')) {
    foreach ($all_modulos as $mod) {
        if (raz_user_can_access_modulo($user_id, $mod->ID, $curso->ID)) {
            $modulos[] = $mod;
            if (function_exists('raz_lms_get_aulas')) {
                $aulas_mod = raz_lms_get_aulas($mod->ID);
                foreach($aulas_mod as $am) {
                    $all_aulas_visible[] = $am;
                }
            }
        }
    }
}

// Navegação
$prev_aula = null;
$next_aula = null;
$current_index = -1;

foreach ($all_aulas_visible as $index => $item) {
    if ($item->ID == $aula_id) {
        $current_index = $index;
        break;
    }
}

if ($current_index !== -1) {
    if (isset($all_aulas_visible[$current_index - 1])) {
        $prev_aula = $all_aulas_visible[$current_index - 1];
    }
    if (isset($all_aulas_visible[$current_index + 1])) {
        $next_aula = $all_aulas_visible[$current_index + 1];
    }
}

// Status
$is_completed = function_exists('raz_lms_is_lesson_completed') ? raz_lms_is_lesson_completed($user_id, $aula_id) : false;

// Materiais
$materiais = get_post_meta($aula_id, '_raz_aula_materiais', true);
$has_materials = !empty($materiais) && is_array($materiais) && !$is_locked;

// Log de acesso
if ($user_id && $curso) {
    if (function_exists('raz_lms_log_user_access')) {
        raz_lms_log_user_access($user_id, $aula_id, $curso->ID);
    }
    update_user_meta($user_id, '_raz_last_aula_' . $curso->ID, $aula_id);
    update_user_meta($user_id, '_raz_last_curso', $curso->ID);
}

// Comentários
$comments_enabled = class_exists('Raz_Netflix_Premium') ? Raz_Netflix_Premium::comments_enabled($curso ? $curso->ID : null) : false;

// Cores do sistema
$accent = get_option('raz_netflix_accent_color', '#e50914');
$secondary = get_option('raz_netflix_secondary_color', '#46d369');
$bg_color = get_option('raz_netflix_bg_color', '#0a0a0a');
$surface_color = get_option('raz_netflix_surface_color', '#141414');
$text_color = get_option('raz_netflix_text_color', '#ffffff');

// Progresso do curso
$total_aulas = count($all_aulas_visible);
$completed_count = 0;
foreach ($all_aulas_visible as $a) {
    if (function_exists('raz_lms_is_lesson_completed') && raz_lms_is_lesson_completed($user_id, $a->ID)) {
        $completed_count++;
    }
}
$course_progress = $total_aulas > 0 ? round(($completed_count / $total_aulas) * 100) : 0;

// Função de embed
function raz_nf_video_embed($url, $provider) {
    if (empty($url) || empty($provider)) return '';
    
    switch ($provider) {
        case 'youtube':
            preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $url, $m);
            if (isset($m[1])) {
                return '<iframe src="https://www.youtube.com/embed/'.$m[1].'?rel=0&enablejsapi=1&modestbranding=1" frameborder="0" allow="accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture" allowfullscreen id="raz-video-iframe" data-provider="youtube"></iframe>';
            }
            break;
        case 'vimeo':
            preg_match('/vimeo\.com\/(?:video\/)?(\d+)/', $url, $m);
            if (isset($m[1])) {
                return '<iframe src="https://player.vimeo.com/video/'.$m[1].'?title=0&byline=0&portrait=0" frameborder="0" allow="autoplay;fullscreen" allowfullscreen id="raz-video-iframe" data-provider="vimeo"></iframe>';
            }
            break;
        case 'panda':
        case 'bunny':
            return '<iframe src="'.esc_url($url).'" frameborder="0" allow="autoplay;fullscreen" allowfullscreen id="raz-video-iframe" data-provider="'.$provider.'"></iframe>';
        case 'custom':
            return '<video src="'.esc_url($url).'" controls playsinline id="raz-video-element" data-provider="custom"></video>';
    }
    return '';
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> data-theme="dark">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title><?php echo esc_html($aula->post_title); ?> - <?php bloginfo('name'); ?></title>
<?php wp_head(); ?>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
    --nf-accent: <?php echo esc_attr($accent); ?>;
    --nf-secondary: <?php echo esc_attr($secondary); ?>;
    --nf-bg: <?php echo esc_attr($bg_color); ?>;
    --nf-surface: <?php echo esc_attr($surface_color); ?>;
    --nf-surface-2: #1a1a1a;
    --nf-surface-3: #252525;
    --nf-text: <?php echo esc_attr($text_color); ?>;
    --nf-text-secondary: rgba(255,255,255,0.7);
    --nf-text-muted: rgba(255,255,255,0.4);
    --nf-border: rgba(255,255,255,0.1);
    --nf-glow: 0 0 30px rgba(229,9,20,0.3);
}

* { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    background: var(--nf-bg);
    color: var(--nf-text);
    min-height: 100vh;
    overflow-x: hidden;
    line-height: 1.6;
}

/* Loading Animation */
.nf-loading {
    position: fixed;
    inset: 0;
    background: var(--nf-bg);
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: opacity 0.5s, visibility 0.5s;
}

.nf-loading.hide {
    opacity: 0;
    visibility: hidden;
}

.nf-loader {
    width: 50px;
    height: 50px;
    border: 3px solid var(--nf-surface-2);
    border-top-color: var(--nf-accent);
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin { to { transform: rotate(360deg); } }

/* Layout */
.nf-app {
    display: flex;
    min-height: 100vh;
}

.nf-main {
    flex: 1;
    display: flex;
    flex-direction: column;
    min-width: 0;
}

/* Player Container */
.nf-player-wrap {
    position: relative;
    background: #000;
    width: 100%;
}

.nf-player-wrap.has-video {
    aspect-ratio: 16/9;
    max-height: 75vh;
}

.nf-video-container {
    position: relative;
    width: 100%;
    height: 100%;
}

.nf-video-container iframe,
.nf-video-container video {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

/* Player Header Overlay */
.nf-player-header {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    z-index: 50;
    padding: 20px 24px;
    background: linear-gradient(180deg, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.5) 50%, transparent 100%);
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    opacity: 1;
    transition: opacity 0.3s;
}

.nf-player-wrap:hover .nf-player-header {
    opacity: 1;
}

.nf-header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.nf-back-btn {
    width: 44px;
    height: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 50%;
    color: #fff;
    text-decoration: none;
    transition: all 0.3s;
}

.nf-back-btn:hover {
    background: var(--nf-accent);
    border-color: var(--nf-accent);
    transform: scale(1.1);
}

.nf-course-info {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.nf-course-info small {
    font-size: 11px;
    color: var(--nf-text-muted);
    text-transform: uppercase;
    letter-spacing: 1px;
}

.nf-course-info strong {
    font-size: 14px;
    font-weight: 600;
}

.nf-header-right {
    display: flex;
    align-items: center;
    gap: 12px;
}

.nf-icon-btn {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 50%;
    color: #fff;
    cursor: pointer;
    transition: all 0.3s;
}

.nf-icon-btn:hover {
    background: rgba(255,255,255,0.2);
    transform: scale(1.05);
}

.nf-icon-btn svg {
    width: 18px;
    height: 18px;
}

/* Info Bar */
.nf-info-bar {
    padding: 24px 32px;
    background: linear-gradient(180deg, var(--nf-surface) 0%, var(--nf-bg) 100%);
    border-bottom: 1px solid var(--nf-border);
}

.nf-breadcrumb {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
    color: var(--nf-text-muted);
    margin-bottom: 16px;
}

.nf-breadcrumb a {
    color: var(--nf-accent);
    text-decoration: none;
    transition: color 0.2s;
}

.nf-breadcrumb a:hover {
    color: #fff;
    text-decoration: underline;
}

.nf-lesson-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 24px;
    flex-wrap: wrap;
}

.nf-lesson-title {
    flex: 1;
    min-width: 0;
}

.nf-lesson-title h1 {
    font-size: 1.75rem;
    font-weight: 700;
    line-height: 1.3;
    margin-bottom: 8px;
}

.nf-lesson-meta {
    display: flex;
    align-items: center;
    gap: 16px;
    font-size: 13px;
    color: var(--nf-text-secondary);
}

.nf-lesson-meta span {
    display: flex;
    align-items: center;
    gap: 6px;
}

.nf-lesson-actions {
    display: flex;
    gap: 12px;
    flex-shrink: 0;
}

.nf-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    padding: 14px 28px;
    font-size: 14px;
    font-weight: 600;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    border: none;
    position: relative;
    overflow: hidden;
}

.nf-btn::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,0.2) 0%, transparent 50%);
    opacity: 0;
    transition: opacity 0.3s;
}

.nf-btn:hover::before {
    opacity: 1;
}

.nf-btn svg {
    width: 18px;
    height: 18px;
}

.nf-btn-outline {
    background: transparent;
    border: 2px solid var(--nf-border);
    color: var(--nf-text);
}

.nf-btn-outline:hover {
    border-color: var(--nf-accent);
    color: var(--nf-accent);
}

.nf-btn-primary {
    background: var(--nf-accent);
    color: #fff;
    box-shadow: 0 4px 15px rgba(229,9,20,0.4);
}

.nf-btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 25px rgba(229,9,20,0.5);
}

.nf-btn-success {
    background: var(--nf-secondary);
    color: #fff;
    box-shadow: 0 4px 15px rgba(70,211,105,0.4);
}

.nf-btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 25px rgba(70,211,105,0.5);
}

/* Tabs */
.nf-tabs-container {
    background: var(--nf-surface);
    border-bottom: 1px solid var(--nf-border);
    position: sticky;
    top: 0;
    z-index: 40;
}

.nf-tabs {
    display: flex;
    padding: 0 32px;
    gap: 8px;
    overflow-x: auto;
    scrollbar-width: none;
}

.nf-tabs::-webkit-scrollbar {
    display: none;
}

.nf-tab {
    padding: 18px 24px;
    font-size: 14px;
    font-weight: 500;
    color: var(--nf-text-secondary);
    cursor: pointer;
    border-bottom: 3px solid transparent;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 10px;
    white-space: nowrap;
    position: relative;
}

.nf-tab:hover {
    color: var(--nf-text);
}

.nf-tab.active {
    color: var(--nf-accent);
    border-bottom-color: var(--nf-accent);
}

.nf-tab svg {
    width: 18px;
    height: 18px;
}

.nf-badge {
    background: var(--nf-accent);
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    padding: 3px 10px;
    border-radius: 12px;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.7; }
}

/* Tab Content */
.nf-tab-panel {
    display: none;
    animation: fadeSlideIn 0.4s ease;
}

.nf-tab-panel.active {
    display: block;
}

@keyframes fadeSlideIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.nf-content {
    max-width: 900px;
    margin: 0 auto;
    padding: 40px 32px;
}

.nf-content-text {
    font-size: 16px;
    line-height: 1.8;
    color: var(--nf-text-secondary);
}

.nf-content-text h1, .nf-content-text h2, .nf-content-text h3 {
    color: var(--nf-text);
    margin: 32px 0 16px;
}

.nf-content-text p {
    margin-bottom: 16px;
}

.nf-content-text img {
    max-width: 100%;
    border-radius: 12px;
    margin: 24px 0;
}

.nf-content-text a {
    color: var(--nf-accent);
}

/* Materials */
.nf-materials-grid {
    display: grid;
    gap: 16px;
}

.nf-material-card {
    display: flex;
    align-items: center;
    gap: 20px;
    padding: 20px 24px;
    background: var(--nf-surface);
    border: 1px solid var(--nf-border);
    border-radius: 16px;
    text-decoration: none;
    color: var(--nf-text);
    transition: all 0.3s;
}

.nf-material-card:hover {
    background: var(--nf-surface-2);
    border-color: var(--nf-accent);
    transform: translateX(8px);
    box-shadow: var(--nf-glow);
}

.nf-material-icon {
    width: 56px;
    height: 56px;
    background: linear-gradient(135deg, var(--nf-accent), #ff6b6b);
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.nf-material-icon svg {
    width: 28px;
    height: 28px;
    color: #fff;
}

.nf-material-info {
    flex: 1;
}

.nf-material-info strong {
    display: block;
    font-size: 15px;
    margin-bottom: 4px;
}

.nf-material-info span {
    font-size: 12px;
    color: var(--nf-text-muted);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.nf-material-download {
    color: var(--nf-text-muted);
    transition: color 0.3s;
}

.nf-material-card:hover .nf-material-download {
    color: var(--nf-accent);
}

/* Comments */
.nf-comments-section h3 {
    font-size: 1.25rem;
    margin-bottom: 24px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.nf-comment-form {
    display: flex;
    gap: 16px;
    padding: 24px;
    background: var(--nf-surface);
    border-radius: 20px;
    border: 1px solid var(--nf-border);
    margin-bottom: 32px;
}

.nf-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid var(--nf-accent);
    flex-shrink: 0;
}

.nf-comment-input-wrap {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 16px;
}

.nf-comment-textarea {
    width: 100%;
    min-height: 100px;
    padding: 16px;
    background: var(--nf-bg);
    border: 1px solid var(--nf-border);
    border-radius: 12px;
    color: var(--nf-text);
    font-family: inherit;
    font-size: 14px;
    resize: vertical;
    transition: border-color 0.3s;
}

.nf-comment-textarea:focus {
    outline: none;
    border-color: var(--nf-accent);
}

.nf-comment-textarea::placeholder {
    color: var(--nf-text-muted);
}

.nf-comment-submit {
    align-self: flex-end;
    padding: 12px 28px;
    background: var(--nf-accent);
    border: none;
    border-radius: 10px;
    color: #fff;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}

.nf-comment-submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(229,9,20,0.4);
}

.nf-comment-submit:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none;
}

.nf-comments-list {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.nf-comment {
    display: flex;
    gap: 16px;
    padding: 24px;
    background: var(--nf-surface);
    border-radius: 20px;
    border: 1px solid var(--nf-border);
    animation: fadeSlideIn 0.4s ease;
}

.nf-comment-body {
    flex: 1;
}

.nf-comment-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.nf-comment-author {
    font-weight: 600;
    font-size: 14px;
}

.nf-comment-time {
    font-size: 12px;
    color: var(--nf-text-muted);
}

.nf-comment-text {
    color: var(--nf-text-secondary);
    font-size: 14px;
    line-height: 1.7;
    margin-bottom: 12px;
}

.nf-comment-delete {
    background: none;
    border: none;
    color: var(--nf-text-muted);
    font-size: 13px;
    cursor: pointer;
    transition: color 0.3s;
}

.nf-comment-delete:hover {
    color: #ef4444;
}

.nf-empty-state {
    text-align: center;
    padding: 60px 20px;
    color: var(--nf-text-muted);
}

.nf-empty-state svg {
    width: 64px;
    height: 64px;
    margin-bottom: 16px;
    opacity: 0.3;
}

/* Sidebar */
.nf-sidebar {
    width: 420px;
    min-width: 420px;
    background: var(--nf-surface);
    border-left: 1px solid var(--nf-border);
    display: flex;
    flex-direction: column;
    transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}

.nf-sidebar-header {
    padding: 24px;
    border-bottom: 1px solid var(--nf-border);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.nf-sidebar-title {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.nf-sidebar-title small {
    font-size: 11px;
    color: var(--nf-text-muted);
    text-transform: uppercase;
    letter-spacing: 1px;
}

.nf-sidebar-title strong {
    font-size: 15px;
    font-weight: 700;
}

.nf-sidebar-close {
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--nf-surface-2);
    border: none;
    border-radius: 10px;
    color: var(--nf-text-secondary);
    cursor: pointer;
    transition: all 0.3s;
}

.nf-sidebar-close:hover {
    background: var(--nf-accent);
    color: #fff;
}

/* Progress Bar */
.nf-course-progress {
    padding: 20px 24px;
    background: var(--nf-bg);
    border-bottom: 1px solid var(--nf-border);
}

.nf-progress-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}

.nf-progress-header span {
    font-size: 13px;
    color: var(--nf-text-secondary);
}

.nf-progress-header strong {
    font-size: 14px;
    color: var(--nf-accent);
}

.nf-progress-bar {
    height: 6px;
    background: var(--nf-surface-2);
    border-radius: 3px;
    overflow: hidden;
}

.nf-progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--nf-accent), #ff6b6b);
    border-radius: 3px;
    transition: width 0.5s ease;
}

.nf-sidebar-content {
    flex: 1;
    overflow-y: auto;
}

/* Modules */
.nf-module {
    border-bottom: 1px solid var(--nf-border);
}

.nf-module-header {
    padding: 20px 24px;
    display: flex;
    align-items: center;
    gap: 16px;
    cursor: pointer;
    transition: background 0.3s;
}

.nf-module-header:hover {
    background: var(--nf-surface-2);
}

.nf-module.open .nf-module-header {
    background: var(--nf-surface-2);
}

/* Circular Progress */
.nf-circle-progress {
    width: 52px;
    height: 52px;
    position: relative;
    flex-shrink: 0;
}

.nf-circle-progress svg {
    width: 100%;
    height: 100%;
    transform: rotate(-90deg);
}

.nf-circle-progress .track {
    fill: none;
    stroke: var(--nf-surface-3);
    stroke-width: 4;
}

.nf-circle-progress .progress {
    fill: none;
    stroke: var(--nf-accent);
    stroke-width: 4;
    stroke-linecap: round;
    transition: stroke-dashoffset 0.6s ease;
}

.nf-circle-progress.completed .progress {
    stroke: var(--nf-secondary);
}

.nf-circle-progress .value {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 11px;
    font-weight: 700;
}

.nf-circle-progress.completed .value {
    color: var(--nf-secondary);
}

.nf-module-info {
    flex: 1;
    min-width: 0;
}

.nf-module-info strong {
    display: block;
    font-size: 14px;
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 4px;
}

.nf-module-info small {
    font-size: 12px;
    color: var(--nf-text-muted);
}

.nf-module-chevron {
    width: 20px;
    height: 20px;
    color: var(--nf-text-muted);
    transition: transform 0.3s;
}

.nf-module.open .nf-module-chevron {
    transform: rotate(180deg);
}

/* Lessons */
.nf-lessons-list {
    max-height: 0;
    overflow: hidden;
    background: var(--nf-bg);
    transition: max-height 0.4s ease;
}

.nf-module.open .nf-lessons-list {
    max-height: 2000px;
}

.nf-lesson {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 16px 24px 16px 92px;
    border-bottom: 1px solid var(--nf-border);
    transition: all 0.3s;
}

.nf-lesson:last-child {
    border-bottom: none;
}

.nf-lesson:hover {
    background: var(--nf-surface);
}

.nf-lesson.active {
    background: rgba(229,9,20,0.1);
    border-left: 3px solid var(--nf-accent);
    padding-left: 89px;
}

.nf-lesson.locked {
    opacity: 0.4;
    cursor: not-allowed;
}

.nf-lesson-check {
    width: 26px;
    height: 26px;
    border: 2px solid var(--nf-border);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    cursor: pointer;
    transition: all 0.3s;
    font-size: 12px;
}

.nf-lesson-check:hover {
    border-color: var(--nf-secondary);
    background: rgba(70,211,105,0.1);
}

.nf-lesson-check.done {
    background: var(--nf-secondary);
    border-color: var(--nf-secondary);
    color: #fff;
}

.nf-lesson a {
    flex: 1;
    color: var(--nf-text-secondary);
    text-decoration: none;
    font-size: 13px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    transition: color 0.3s;
}

.nf-lesson:hover a,
.nf-lesson.active a {
    color: var(--nf-text);
}

/* Lock Screen */
.nf-lock-screen {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 80px 24px;
    text-align: center;
    max-width: 500px;
    margin: 0 auto;
}

.nf-lock-icon {
    width: 120px;
    height: 120px;
    background: linear-gradient(135deg, var(--nf-surface-2), var(--nf-surface-3));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 32px;
    font-size: 56px;
    animation: float 3s ease-in-out infinite;
}

@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}

.nf-lock-screen h2 {
    font-size: 1.75rem;
    margin-bottom: 12px;
}

.nf-lock-screen p {
    color: var(--nf-text-secondary);
    margin-bottom: 32px;
    font-size: 15px;
}

.nf-lock-date {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    padding: 16px 28px;
    background: var(--nf-surface);
    border: 1px solid var(--nf-border);
    border-radius: 12px;
    font-weight: 600;
}

/* Search Modal */
.nf-search-modal {
    position: fixed;
    inset: 0;
    z-index: 1000;
    background: rgba(0,0,0,0.95);
    backdrop-filter: blur(20px);
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding: 100px 20px 20px;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s;
}

.nf-search-modal.active {
    opacity: 1;
    visibility: visible;
}

.nf-search-container {
    width: 100%;
    max-width: 650px;
    transform: translateY(-20px);
    transition: transform 0.3s;
}

.nf-search-modal.active .nf-search-container {
    transform: translateY(0);
}

.nf-search-input-wrap {
    position: relative;
}

.nf-search-input {
    width: 100%;
    padding: 22px 60px;
    background: var(--nf-surface);
    border: 2px solid var(--nf-border);
    border-radius: 16px;
    font-size: 18px;
    color: var(--nf-text);
    outline: none;
    transition: border-color 0.3s;
}

.nf-search-input:focus {
    border-color: var(--nf-accent);
}

.nf-search-input::placeholder {
    color: var(--nf-text-muted);
}

.nf-search-icon {
    position: absolute;
    left: 22px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--nf-text-muted);
}

.nf-search-close {
    position: absolute;
    right: 16px;
    top: 50%;
    transform: translateY(-50%);
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--nf-surface-2);
    border: none;
    border-radius: 10px;
    color: var(--nf-text-secondary);
    cursor: pointer;
    transition: all 0.3s;
}

.nf-search-close:hover {
    background: var(--nf-accent);
    color: #fff;
}

.nf-search-results {
    margin-top: 20px;
    max-height: 60vh;
    overflow-y: auto;
}

.nf-search-result {
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 18px 20px;
    background: var(--nf-surface);
    border-radius: 14px;
    margin-bottom: 10px;
    text-decoration: none;
    color: var(--nf-text);
    transition: all 0.3s;
}

.nf-search-result:hover {
    background: var(--nf-surface-2);
    transform: translateX(8px);
}

.nf-search-result-icon {
    width: 48px;
    height: 48px;
    background: linear-gradient(135deg, var(--nf-accent), #ff6b6b);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.nf-search-result-icon svg {
    width: 22px;
    height: 22px;
    color: #fff;
}

.nf-search-result-info {
    flex: 1;
}

.nf-search-result-title {
    font-weight: 600;
    margin-bottom: 4px;
}

.nf-search-result-module {
    font-size: 12px;
    color: var(--nf-text-muted);
}

/* Mobile Toggle */
.nf-sidebar-toggle {
    display: none;
    position: fixed;
    bottom: 24px;
    right: 24px;
    width: 64px;
    height: 64px;
    background: linear-gradient(135deg, var(--nf-accent), #ff6b6b);
    border: none;
    border-radius: 50%;
    color: #fff;
    cursor: pointer;
    z-index: 200;
    box-shadow: 0 4px 25px rgba(229,9,20,0.5);
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 4px;
    transition: transform 0.3s;
}

.nf-sidebar-toggle:hover {
    transform: scale(1.1);
}

.nf-sidebar-toggle svg {
    width: 22px;
    height: 22px;
}

.nf-sidebar-toggle span {
    font-size: 9px;
    font-weight: 700;
    text-transform: uppercase;
}

.nf-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.8);
    z-index: 499;
    backdrop-filter: blur(5px);
}

.nf-overlay.show {
    display: block;
}

/* Responsive */
@media (max-width: 1200px) {
    .nf-sidebar {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        z-index: 500;
        transform: translateX(100%);
        width: 90%;
        max-width: 420px;
    }
    
    .nf-sidebar.open {
        transform: translateX(0);
    }
    
    .nf-sidebar-toggle {
        display: flex;
    }
}

@media (max-width: 768px) {
    .nf-player-header {
        padding: 16px;
    }
    
    .nf-course-info {
        display: none;
    }
    
    .nf-info-bar {
        padding: 20px;
    }
    
    .nf-lesson-title h1 {
        font-size: 1.25rem;
    }
    
    .nf-lesson-actions {
        width: 100%;
    }
    
    .nf-btn {
        flex: 1;
        padding: 14px 16px;
    }
    
    .nf-tabs {
        padding: 0 20px;
    }
    
    .nf-tab {
        padding: 16px 18px;
        font-size: 13px;
    }
    
    .nf-content {
        padding: 24px 20px;
    }
    
    .nf-lesson {
        padding-left: 72px;
    }
    
    .nf-lesson.active {
        padding-left: 69px;
    }
}

/* Scrollbar */
::-webkit-scrollbar {
    width: 8px;
}

::-webkit-scrollbar-track {
    background: var(--nf-bg);
}

::-webkit-scrollbar-thumb {
    background: var(--nf-surface-3);
    border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
    background: var(--nf-accent);
}
</style>
</head>
<body>

<!-- Loading Screen -->
<div class="nf-loading" id="loading">
    <div class="nf-loader"></div>
</div>

<div class="nf-app">
    <main class="nf-main">
        <?php if ($is_locked) : ?>
        <!-- Lock Screen -->
        <div class="nf-lock-screen">
            <div class="nf-lock-icon">🔒</div>
            <h2>Conteúdo Bloqueado</h2>
            <p><?php echo isset($rotina_status['message']) ? esc_html($rotina_status['message']) : 'Esta aula ainda não está disponível.'; ?></p>
            <div class="nf-lock-date">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                Disponível em: <?php echo isset($rotina_status['release_date']) ? date_i18n('d/m/Y \à\s H:i', $rotina_status['release_date']) : '--'; ?>
            </div>
        </div>
        <?php else : ?>
        
        <!-- Player -->
        <div class="nf-player-wrap <?php echo $has_video ? 'has-video' : ''; ?>">
            <div class="nf-player-header">
                <div class="nf-header-left">
                    <a href="<?php echo $curso ? get_permalink($curso->ID) : home_url('/meus-cursos'); ?>" class="nf-back-btn" title="Voltar">
                        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                    </a>
                    <div class="nf-course-info">
                        <small>Você está assistindo</small>
                        <strong><?php echo $curso ? esc_html($curso->post_title) : ''; ?></strong>
                    </div>
                </div>
                <div class="nf-header-right">
                    <button class="nf-icon-btn" onclick="openSearch()" title="Buscar aula">
                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                    </button>
                </div>
            </div>
            
            <?php if ($has_video) : ?>
            <div class="nf-video-container">
                <?php echo raz_nf_video_embed($video_url, $video_provider); ?>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Info Bar -->
        <div class="nf-info-bar">
            <div class="nf-breadcrumb">
                <a href="<?php echo home_url('/meus-cursos'); ?>">Meus Cursos</a>
                <span>›</span>
                <?php if ($curso) : ?>
                <a href="<?php echo get_permalink($curso->ID); ?>"><?php echo esc_html($curso->post_title); ?></a>
                <span>›</span>
                <?php endif; ?>
                <?php if ($modulo) : ?>
                <span><?php echo esc_html($modulo->post_title); ?></span>
                <?php endif; ?>
            </div>
            
            <div class="nf-lesson-header">
                <div class="nf-lesson-title">
                    <h1><?php echo esc_html($aula->post_title); ?></h1>
                    <div class="nf-lesson-meta">
                        <span>
                            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                            Aula <?php echo $current_index + 1; ?> de <?php echo $total_aulas; ?>
                        </span>
                        <?php if ($is_completed) : ?>
                        <span style="color: var(--nf-secondary);">
                            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
                            Concluída
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="nf-lesson-actions">
                    <?php if ($prev_aula) : ?>
                    <a href="<?php echo get_permalink($prev_aula->ID); ?>" class="nf-btn nf-btn-outline">
                        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                        Anterior
                    </a>
                    <?php endif; ?>
                    
                    <?php if ($next_aula) : ?>
                    <a href="<?php echo get_permalink($next_aula->ID); ?>" class="nf-btn nf-btn-primary">
                        Próxima
                        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    </a>
                    <?php else : ?>
                    <button class="nf-btn nf-btn-success" onclick="finishCourse()">
                        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
                        Concluir Curso
                    </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Tabs -->
        <div class="nf-tabs-container">
            <div class="nf-tabs">
                <div class="nf-tab active" data-tab="conteudo" onclick="switchTab('conteudo', this)">
                    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    Conteúdo
                </div>
                <?php if ($has_materials) : ?>
                <div class="nf-tab" data-tab="materiais" onclick="switchTab('materiais', this)">
                    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                    Materiais
                    <span class="nf-badge"><?php echo count($materiais); ?></span>
                </div>
                <?php endif; ?>
                <?php if ($comments_enabled) : ?>
                <div class="nf-tab" data-tab="comentarios" onclick="switchTab('comentarios', this)">
                    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                    Discussão
                    <span class="nf-badge" id="comments-count">0</span>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Tab Panels -->
        <div class="nf-tab-panel active" id="panel-conteudo">
            <div class="nf-content">
                <div class="nf-content-text">
                    <?php 
                    $content = get_the_content();
                    if (!empty($content)) {
                        echo apply_filters('the_content', $content);
                    } else {
                        echo '<div class="nf-empty-state"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg><p>Esta aula não possui conteúdo escrito.</p></div>';
                    }
                    ?>
                </div>
            </div>
        </div>
        
        <?php if ($has_materials) : ?>
        <div class="nf-tab-panel" id="panel-materiais">
            <div class="nf-content">
                <div class="nf-materials-grid">
                    <?php foreach ($materiais as $mat) : 
                        $nome = isset($mat['display_name']) ? $mat['display_name'] : (isset($mat['nome']) ? $mat['nome'] : 'Material');
                        $tipo = isset($mat['tipo']) ? strtoupper($mat['tipo']) : 'ARQUIVO';
                        $url = isset($mat['url']) ? $mat['url'] : '#';
                    ?>
                    <a href="<?php echo esc_url($url); ?>" class="nf-material-card" target="_blank" download>
                        <div class="nf-material-icon">
                            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                        </div>
                        <div class="nf-material-info">
                            <strong><?php echo esc_html($nome); ?></strong>
                            <span><?php echo esc_html($tipo); ?></span>
                        </div>
                        <div class="nf-material-download">
                            <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($comments_enabled) : ?>
        <div class="nf-tab-panel" id="panel-comentarios">
            <div class="nf-content">
                <div class="nf-comments-section">
                    <h3>💬 Discussão da Aula</h3>
                    
                    <div class="nf-comment-form">
                        <img src="<?php echo get_avatar_url($user_id, array('size' => 96)); ?>" class="nf-avatar" alt="<?php echo esc_attr($user->display_name); ?>">
                        <div class="nf-comment-input-wrap">
                            <textarea class="nf-comment-textarea" id="comment-input" placeholder="Compartilhe sua opinião ou dúvida sobre esta aula..."></textarea>
                            <button class="nf-comment-submit" id="comment-submit" onclick="submitComment()">Publicar</button>
                        </div>
                    </div>
                    
                    <div class="nf-comments-list" id="comments-list">
                        <div class="nf-empty-state">
                            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                            <p>Seja o primeiro a comentar!</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <?php endif; // end !is_locked ?>
    </main>
    
    <!-- Sidebar -->
    <aside class="nf-sidebar" id="sidebar">
        <div class="nf-sidebar-header">
            <div class="nf-sidebar-title">
                <small>Conteúdo do Curso</small>
                <strong><?php echo $curso ? esc_html($curso->post_title) : 'Curso'; ?></strong>
            </div>
            <button class="nf-sidebar-close" id="sidebar-close" type="button">
                <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 6 6 18M6 6l12 12"/></svg>
            </button>
        </div>
        
        <div class="nf-course-progress">
            <div class="nf-progress-header">
                <span>Seu progresso</span>
                <strong><?php echo $course_progress; ?>%</strong>
            </div>
            <div class="nf-progress-bar">
                <div class="nf-progress-fill" style="width: <?php echo $course_progress; ?>%;"></div>
            </div>
        </div>
        
        <div class="nf-sidebar-content">
            <?php 
            $circumference = 2 * 3.14159 * 18;
            
            foreach ($modulos as $mod) :
                $mod_aulas = function_exists('raz_lms_get_aulas') ? raz_lms_get_aulas($mod->ID) : array();
                $mod_total = count($mod_aulas);
                $mod_completed = 0;
                
                foreach ($mod_aulas as $ma) {
                    if (function_exists('raz_lms_is_lesson_completed') && raz_lms_is_lesson_completed($user_id, $ma->ID)) {
                        $mod_completed++;
                    }
                }
                
                $mod_percent = $mod_total > 0 ? round(($mod_completed / $mod_total) * 100) : 0;
                $is_current_module = $modulo && $mod->ID == $modulo->ID;
                $dashoffset = $circumference - ($mod_percent / 100 * $circumference);
            ?>
            <div class="nf-module <?php echo $is_current_module ? 'open' : ''; ?>">
                <div class="nf-module-header" onclick="this.parentElement.classList.toggle('open')">
                    <div class="nf-circle-progress <?php echo $mod_percent == 100 ? 'completed' : ''; ?>">
                        <svg viewBox="0 0 40 40">
                            <circle class="track" cx="20" cy="20" r="18"/>
                            <circle class="progress" cx="20" cy="20" r="18" stroke-dasharray="<?php echo $circumference; ?>" stroke-dashoffset="<?php echo $dashoffset; ?>"/>
                        </svg>
                        <span class="value"><?php echo $mod_percent == 100 ? '✓' : $mod_percent . '%'; ?></span>
                    </div>
                    <div class="nf-module-info">
                        <strong><?php echo esc_html($mod->post_title); ?></strong>
                        <small><?php echo $mod_completed; ?>/<?php echo $mod_total; ?> aulas</small>
                    </div>
                    <svg class="nf-module-chevron" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg>
                </div>
                
                <div class="nf-lessons-list">
                    <?php foreach ($mod_aulas as $lesson) :
                        $lesson_completed = function_exists('raz_lms_is_lesson_completed') ? raz_lms_is_lesson_completed($user_id, $lesson->ID) : false;
                        $is_current = $lesson->ID == $aula_id;
                        $lesson_lock = function_exists('raz_lms_check_routine_access') ? raz_lms_check_routine_access($user_id, $lesson->ID) : array('locked' => false);
                        $is_lesson_locked = isset($lesson_lock['locked']) ? $lesson_lock['locked'] : false;
                    ?>
                    <div class="nf-lesson <?php echo $is_current ? 'active' : ''; ?> <?php echo $is_lesson_locked ? 'locked' : ''; ?>">
                        <?php if ($is_lesson_locked) : ?>
                        <span class="nf-lesson-check">🔒</span>
                        <span style="flex:1;color:var(--nf-text-muted);font-size:13px;"><?php echo esc_html($lesson->post_title); ?></span>
                        <?php else : ?>
                        <span class="nf-lesson-check <?php echo $lesson_completed ? 'done' : ''; ?>" data-id="<?php echo $lesson->ID; ?>" onclick="toggleComplete(this, event)">
                            <?php echo $lesson_completed ? '✓' : ''; ?>
                        </span>
                        <a href="<?php echo get_permalink($lesson->ID); ?>"><?php echo esc_html($lesson->post_title); ?></a>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </aside>
</div>

<!-- Overlay -->
<div class="nf-overlay" id="overlay"></div>

<!-- Search Modal -->
<div class="nf-search-modal" id="search-modal">
    <div class="nf-search-container">
        <div class="nf-search-input-wrap">
            <svg class="nf-search-icon" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            <input type="text" class="nf-search-input" id="search-input" placeholder="Buscar aula..." autocomplete="off">
            <button class="nf-search-close" onclick="closeSearch()">
                <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 6 6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="nf-search-results" id="search-results"></div>
    </div>
</div>

<!-- Sidebar Toggle -->
<button class="nf-sidebar-toggle" id="sidebar-toggle">
    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
    <span>Aulas</span>
</button>

<script>
// Variables
var aulaId = <?php echo $aula_id; ?>;
var cursoId = <?php echo $curso ? $curso->ID : 0; ?>;
var nextUrl = <?php echo $next_aula ? "'" . esc_url(get_permalink($next_aula->ID)) . "'" : 'null'; ?>;
var videoEnded = false;
var commentsEnabled = <?php echo $comments_enabled ? 'true' : 'false'; ?>;

// All lessons for search
var allLessons = <?php 
$lessons_data = array();
foreach ($modulos as $mod) {
    $mod_aulas = function_exists('raz_lms_get_aulas') ? raz_lms_get_aulas($mod->ID) : array();
    foreach ($mod_aulas as $lesson) {
        $lessons_data[] = array(
            'id' => $lesson->ID,
            'title' => $lesson->post_title,
            'module' => $mod->post_title,
            'url' => get_permalink($lesson->ID)
        );
    }
}
echo json_encode($lessons_data);
?>;

// Hide loading
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        document.getElementById('loading').classList.add('hide');
    }, 500);
});

// Tabs
function switchTab(tabId, el) {
    document.querySelectorAll('.nf-tab').forEach(function(t) { t.classList.remove('active'); });
    document.querySelectorAll('.nf-tab-panel').forEach(function(p) { p.classList.remove('active'); });
    el.classList.add('active');
    document.getElementById('panel-' + tabId).classList.add('active');
}

// Sidebar
function openSidebar() {
    document.getElementById('sidebar').classList.add('open');
    document.getElementById('overlay').classList.add('show');
    document.body.style.overflow = 'hidden';
}

function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('overlay').classList.remove('show');
    document.body.style.overflow = '';
}

document.getElementById('sidebar-toggle').addEventListener('click', openSidebar);
document.getElementById('sidebar-close').addEventListener('click', closeSidebar);
document.getElementById('overlay').addEventListener('click', closeSidebar);

// Search
function openSearch() {
    document.getElementById('search-modal').classList.add('active');
    document.getElementById('search-input').focus();
    document.body.style.overflow = 'hidden';
}

function closeSearch() {
    document.getElementById('search-modal').classList.remove('active');
    document.getElementById('search-input').value = '';
    document.getElementById('search-results').innerHTML = '';
    document.body.style.overflow = '';
}

document.getElementById('search-input').addEventListener('input', function() {
    var query = this.value.toLowerCase().trim();
    var results = document.getElementById('search-results');
    
    if (query.length < 2) {
        results.innerHTML = '';
        return;
    }
    
    var filtered = allLessons.filter(function(l) {
        return l.title.toLowerCase().indexOf(query) !== -1 || l.module.toLowerCase().indexOf(query) !== -1;
    });
    
    if (filtered.length === 0) {
        results.innerHTML = '<div class="nf-empty-state"><p>Nenhuma aula encontrada</p></div>';
        return;
    }
    
    var html = '';
    filtered.forEach(function(l) {
        html += '<a href="' + l.url + '" class="nf-search-result">' +
            '<div class="nf-search-result-icon"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg></div>' +
            '<div class="nf-search-result-info"><div class="nf-search-result-title">' + l.title + '</div><div class="nf-search-result-module">' + l.module + '</div></div>' +
        '</a>';
    });
    results.innerHTML = html;
});

// Complete lesson
function toggleComplete(el, e) {
    e.preventDefault();
    e.stopPropagation();
    
    var lessonId = el.getAttribute('data-id');
    if (!lessonId || el.classList.contains('done')) return;
    
    el.classList.add('done');
    el.textContent = '✓';
    
    var fd = new FormData();
    fd.append('action', 'raz_complete_lesson');
    fd.append('nonce', razNetflix.nonce);
    fd.append('aula_id', lessonId);
    
    fetch(razNetflix.ajaxurl, { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (!data.success) {
                el.classList.remove('done');
                el.textContent = '';
            }
        })
        .catch(function() {
            el.classList.remove('done');
            el.textContent = '';
        });
}

function markCurrentComplete() {
    var fd = new FormData();
    fd.append('action', 'raz_complete_lesson');
    fd.append('nonce', razNetflix.nonce);
    fd.append('aula_id', aulaId);
    
    fetch(razNetflix.ajaxurl, { method: 'POST', body: fd });
    
    var check = document.querySelector('.nf-lesson-check[data-id="' + aulaId + '"]');
    if (check && !check.classList.contains('done')) {
        check.classList.add('done');
        check.textContent = '✓';
    }
}

function finishCourse() {
    markCurrentComplete();
    alert('🎉 Parabéns! Você concluiu o curso!');
    window.location.reload();
}

function onVideoEnd() {
    if (videoEnded) return;
    videoEnded = true;
    markCurrentComplete();
    if (nextUrl) {
        setTimeout(function() { window.location.href = nextUrl; }, 1500);
    }
}

// YouTube API
var ytPlayer;
function onYouTubeIframeAPIReady() {
    var iframe = document.querySelector('#raz-video-iframe[data-provider="youtube"]');
    if (iframe) {
        ytPlayer = new YT.Player(iframe, {
            events: {
                'onStateChange': function(e) {
                    if (e.data === YT.PlayerState.ENDED) onVideoEnd();
                }
            }
        });
    }
}

if (document.querySelector('[data-provider="youtube"]')) {
    var tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    document.head.appendChild(tag);
}

// Vimeo
var vimeoIframe = document.querySelector('#raz-video-iframe[data-provider="vimeo"]');
if (vimeoIframe && typeof Vimeo !== 'undefined') {
    new Vimeo.Player(vimeoIframe).on('ended', onVideoEnd);
}

// HTML5 Video
var videoEl = document.getElementById('raz-video-element');
if (videoEl) {
    videoEl.addEventListener('ended', onVideoEnd);
}

// Panda/Bunny
window.addEventListener('message', function(e) {
    if (e.data && (e.data.message === 'panda_ended' || e.data.event === 'ended')) {
        onVideoEnd();
    }
});

// Comments
if (commentsEnabled) {
    loadComments();
}

function loadComments() {
    var fd = new FormData();
    fd.append('action', 'raz_netflix_get_comments');
    fd.append('nonce', razNetflix.nonce);
    fd.append('aula_id', aulaId);
    
    fetch(razNetflix.ajaxurl, { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) renderComments(d.data);
        });
}

function renderComments(comments) {
    var list = document.getElementById('comments-list');
    var badge = document.getElementById('comments-count');
    
    if (badge) badge.textContent = comments.length;
    
    if (comments.length === 0) {
        list.innerHTML = '<div class="nf-empty-state"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg><p>Seja o primeiro a comentar!</p></div>';
        return;
    }
    
    var html = '';
    comments.forEach(function(c) {
        html += '<div class="nf-comment">' +
            '<img src="' + c.user_avatar + '" class="nf-avatar" alt="">' +
            '<div class="nf-comment-body">' +
                '<div class="nf-comment-header">' +
                    '<span class="nf-comment-author">' + c.user_name + '</span>' +
                    '<span class="nf-comment-time">' + c.time_ago + '</span>' +
                '</div>' +
                '<p class="nf-comment-text">' + c.comment_text.replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</p>' +
                (c.can_delete ? '<button class="nf-comment-delete" onclick="deleteComment(' + c.id + ')">Excluir</button>' : '') +
            '</div>' +
        '</div>';
    });
    list.innerHTML = html;
}

function submitComment() {
    var input = document.getElementById('comment-input');
    var btn = document.getElementById('comment-submit');
    var text = input.value.trim();
    
    if (!text) return;
    
    btn.disabled = true;
    btn.textContent = 'Enviando...';
    
    var fd = new FormData();
    fd.append('action', 'raz_netflix_save_comment');
    fd.append('nonce', razNetflix.nonce);
    fd.append('aula_id', aulaId);
    fd.append('comment_text', text);
    
    fetch(razNetflix.ajaxurl, { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            btn.disabled = false;
            btn.textContent = 'Publicar';
            if (d.success) {
                input.value = '';
                loadComments();
            }
        });
}

function deleteComment(id) {
    if (!confirm('Excluir este comentário?')) return;
    
    var fd = new FormData();
    fd.append('action', 'raz_netflix_delete_comment');
    fd.append('nonce', razNetflix.nonce);
    fd.append('comment_id', id);
    
    fetch(razNetflix.ajaxurl, { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) loadComments();
        });
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeSidebar();
        closeSearch();
    }
});
</script>

<?php wp_footer(); ?>
</body>
</html>
