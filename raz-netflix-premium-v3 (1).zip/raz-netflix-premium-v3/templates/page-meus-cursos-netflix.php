<?php
/**
 * Template: Meus Cursos - Netflix Premium Experience v3
 * @package RazNetflixPremium
 */

if (!is_user_logged_in()) { wp_redirect(home_url('/login')); exit; }

$user_id = get_current_user_id();
$user = wp_get_current_user();
$cursos = function_exists('raz_lms_get_user_courses') ? raz_lms_get_user_courses($user_id) : array();

$last_course_id = get_user_meta($user_id, '_raz_last_curso', true);
$last_lesson_id = $last_course_id ? get_user_meta($user_id, '_raz_last_aula_' . $last_course_id, true) : 0;
$featured_course = null;
$resume_data = null;

if ($last_course_id && $last_lesson_id) {
    $last_course = get_post($last_course_id);
    $last_lesson = get_post($last_lesson_id);
    if ($last_course && $last_lesson && function_exists('raz_lms_user_has_access') && raz_lms_user_has_access($user_id, $last_course_id)) {
        $featured_course = $last_course;
        $progress = function_exists('raz_lms_get_course_progress') ? raz_lms_get_course_progress($user_id, $last_course_id) : array('percent' => 0);
        $resume_data = array(
            'course' => $last_course,
            'lesson' => $last_lesson,
            'progress' => $progress,
            'thumb' => get_the_post_thumbnail_url($last_course_id, 'full') ?: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1920&q=80'
        );
    }
}

if (!$featured_course && !empty($cursos)) {
    $featured_course = $cursos[0];
    $thumb = get_the_post_thumbnail_url($featured_course->ID, 'full');
    $resume_data = array(
        'course' => $featured_course,
        'lesson' => null,
        'progress' => array('percent' => 0),
        'thumb' => $thumb ?: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1920&q=80'
    );
}

$cursos_em_andamento = array();
$cursos_novos = array();
$cursos_concluidos = array();

foreach ($cursos as $curso) {
    $prog = isset($curso->progresso) ? $curso->progresso : array('percent' => 0);
    $percent = $prog['percent'];
    if ($percent == 100) $cursos_concluidos[] = $curso;
    elseif ($percent > 0) $cursos_em_andamento[] = $curso;
    else $cursos_novos[] = $curso;
}

$hour = (int) current_time('G');
$greeting = $hour < 12 ? 'Bom dia' : ($hour < 18 ? 'Boa tarde' : 'Boa noite');

// Cores e hero
$accent = get_option('raz_netflix_accent_color', '#e50914');
$secondary = get_option('raz_netflix_secondary_color', '#46d369');
$bg_color = get_option('raz_netflix_bg_color', '#0a0a0a');
$surface_color = get_option('raz_netflix_surface_color', '#141414');
$hero_url = get_option('raz_netflix_meus_cursos_hero', '');
$hero_type = get_option('raz_netflix_meus_cursos_hero_type', 'image');
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> data-theme="dark">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Meus Cursos - <?php bloginfo('name'); ?></title>
<?php wp_head(); ?>
<style>
:root{--nf-accent:<?php echo esc_attr($accent); ?>;--nf-secondary:<?php echo esc_attr($secondary); ?>;--nf-bg:<?php echo esc_attr($bg_color); ?>;--nf-surface:<?php echo esc_attr($surface_color); ?>;--nf-surface-2:#1f1f1f;--nf-surface-3:#2a2a2a;--nf-text:#fff;--nf-text-secondary:#a0a0a0;--nf-text-muted:#6b6b6b;--nf-border:#333}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',-apple-system,sans-serif;background:var(--nf-bg);color:var(--nf-text);min-height:100vh;overflow-x:hidden}

.nf-header{position:fixed;top:0;left:0;right:0;z-index:100;padding:16px 5%;display:flex;align-items:center;justify-content:space-between;transition:all 0.3s}
.nf-header.scrolled{background:rgba(10,10,10,0.95);backdrop-filter:blur(20px)}
.nf-header-left{display:flex;align-items:center;gap:40px}
.nf-logo{font-size:26px;font-weight:800;color:var(--nf-accent);text-decoration:none}
.nf-logo img{height:36px}
.nf-header-right{display:flex;align-items:center;gap:20px}
.nf-user-menu{display:flex;align-items:center;gap:12px;cursor:pointer;padding:8px 16px;border-radius:8px;transition:background 0.2s}
.nf-user-menu:hover{background:rgba(255,255,255,0.1)}
.nf-user-avatar{width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid var(--nf-accent)}
.nf-user-name{font-size:14px;font-weight:500}

<?php if ($hero_url) : ?>
.nf-hero-banner{position:relative;width:100%;height:50vh;min-height:300px;overflow:hidden}
.nf-hero-banner::after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,rgba(10,10,10,0.3) 0%,var(--nf-bg) 100%)}
.nf-hero-banner img,.nf-hero-banner video{width:100%;height:100%;object-fit:cover}
<?php endif; ?>

.nf-welcome{padding:<?php echo $hero_url ? '40px' : '120px'; ?> 5% 40px;text-align:center}
.nf-welcome h1{font-size:2.5rem;font-weight:300;margin-bottom:8px}
.nf-welcome h1 strong{font-weight:700}
.nf-welcome p{color:var(--nf-text-secondary);font-size:1.1rem}

.nf-content{padding:0 5% 60px}

.nf-section{margin-bottom:50px}
.nf-section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
.nf-section-title{font-size:1.4rem;font-weight:700;display:flex;align-items:center;gap:12px}
.nf-section-title svg{width:24px;height:24px;color:var(--nf-accent)}

.nf-courses-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:24px}

.nf-course-card{background:var(--nf-surface);border-radius:12px;overflow:hidden;border:1px solid var(--nf-border);transition:all 0.3s;position:relative}
.nf-course-card:hover{border-color:var(--nf-accent);transform:translateY(-8px);box-shadow:0 20px 40px rgba(0,0,0,0.4)}
.nf-course-thumb{position:relative;aspect-ratio:16/9;overflow:hidden}
.nf-course-thumb img{width:100%;height:100%;object-fit:cover;transition:transform 0.5s}
.nf-course-card:hover .nf-course-thumb img{transform:scale(1.1)}
.nf-course-overlay{position:absolute;inset:0;background:linear-gradient(180deg,transparent 50%,rgba(0,0,0,0.8) 100%);opacity:0;transition:opacity 0.3s;display:flex;align-items:flex-end;justify-content:center;padding:20px}
.nf-course-card:hover .nf-course-overlay{opacity:1}
.nf-course-play{width:60px;height:60px;background:var(--nf-accent);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;transform:translateY(20px);transition:transform 0.3s}
.nf-course-card:hover .nf-course-play{transform:translateY(0)}
.nf-course-play svg{width:28px;height:28px;margin-left:4px}
.nf-course-info{padding:20px}
.nf-course-title{font-size:1rem;font-weight:700;margin-bottom:8px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.nf-course-title a{color:var(--nf-text);text-decoration:none}
.nf-course-title a:hover{color:var(--nf-accent)}
.nf-course-meta{display:flex;gap:16px;font-size:12px;color:var(--nf-text-muted);margin-bottom:12px}
.nf-course-progress{height:4px;background:var(--nf-surface-3);border-radius:2px;overflow:hidden}
.nf-course-progress-bar{height:100%;background:var(--nf-accent);border-radius:2px;transition:width 0.5s}
.nf-course-progress-text{font-size:12px;color:var(--nf-text-muted);margin-top:8px;text-align:right}
.nf-badge-completed{position:absolute;top:12px;right:12px;background:var(--nf-secondary);color:#fff;font-size:11px;font-weight:700;padding:4px 10px;border-radius:4px;text-transform:uppercase}

.nf-empty{text-align:center;padding:60px 20px;background:var(--nf-surface);border-radius:16px;border:1px solid var(--nf-border)}
.nf-empty svg{width:64px;height:64px;color:var(--nf-text-muted);margin-bottom:20px}
.nf-empty h3{font-size:1.25rem;margin-bottom:8px}
.nf-empty p{color:var(--nf-text-secondary)}

@media(max-width:768px){
    .nf-header{padding:12px 16px}
    .nf-header-left{gap:20px}
    .nf-logo{font-size:20px}
    .nf-user-name{display:none}
    .nf-welcome{padding:100px 20px 30px}
    .nf-welcome h1{font-size:1.75rem}
    .nf-content{padding:0 16px 40px}
    .nf-courses-grid{grid-template-columns:1fr}
}
</style>
</head>
<body>

<header class="nf-header" id="header">
    <div class="nf-header-left">
        <a href="<?php echo home_url('/meus-cursos'); ?>" class="nf-logo">
            <?php 
            $logo = get_option('raz_lms_login_logo', '');
            if ($logo) : ?>
            <img src="<?php echo esc_url($logo); ?>" alt="<?php bloginfo('name'); ?>">
            <?php else : ?>
            <?php bloginfo('name'); ?>
            <?php endif; ?>
        </a>
    </div>
    <div class="nf-header-right">
        <div class="nf-user-menu">
            <img src="<?php echo get_avatar_url($user_id, array('size' => 72)); ?>" class="nf-user-avatar" alt="">
            <span class="nf-user-name"><?php echo esc_html($user->display_name); ?></span>
        </div>
    </div>
</header>

<?php if ($hero_url) : ?>
<div class="nf-hero-banner">
    <?php if ($hero_type === 'video') : ?>
    <video src="<?php echo esc_url($hero_url); ?>" autoplay muted loop playsinline></video>
    <?php else : ?>
    <img src="<?php echo esc_url($hero_url); ?>" alt="">
    <?php endif; ?>
</div>
<?php endif; ?>

<div class="nf-welcome">
    <h1><?php echo $greeting; ?>, <strong><?php echo esc_html($user->display_name); ?></strong></h1>
    <p>Que bom ter você de volta! Continue sua jornada de aprendizado.</p>
</div>

<div class="nf-content">
    <?php if (!empty($cursos_em_andamento)) : ?>
    <section class="nf-section">
        <div class="nf-section-header">
            <h2 class="nf-section-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                Continuar Assistindo
            </h2>
        </div>
        <div class="nf-courses-grid">
            <?php foreach ($cursos_em_andamento as $curso) : 
                $thumb = get_the_post_thumbnail_url($curso->ID, 'large') ?: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&q=80';
                $prog = isset($curso->progresso) ? $curso->progresso : array('percent' => 0, 'completed' => 0, 'total' => 0);
                $last_aula = get_user_meta($user_id, '_raz_last_aula_' . $curso->ID, true);
                $link = $last_aula ? get_permalink($last_aula) : get_permalink($curso->ID);
            ?>
            <div class="nf-course-card">
                <div class="nf-course-thumb">
                    <img src="<?php echo esc_url($thumb); ?>" alt="">
                    <div class="nf-course-overlay">
                        <a href="<?php echo esc_url($link); ?>" class="nf-course-play">
                            <svg viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                        </a>
                    </div>
                </div>
                <div class="nf-course-info">
                    <h3 class="nf-course-title"><a href="<?php echo get_permalink($curso->ID); ?>"><?php echo esc_html($curso->post_title); ?></a></h3>
                    <div class="nf-course-meta">
                        <span><?php echo $prog['completed']; ?>/<?php echo $prog['total']; ?> aulas</span>
                    </div>
                    <div class="nf-course-progress"><div class="nf-course-progress-bar" style="width:<?php echo $prog['percent']; ?>%"></div></div>
                    <div class="nf-course-progress-text"><?php echo $prog['percent']; ?>% concluído</div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($cursos_novos)) : ?>
    <section class="nf-section">
        <div class="nf-section-header">
            <h2 class="nf-section-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
                Novos para Você
            </h2>
        </div>
        <div class="nf-courses-grid">
            <?php foreach ($cursos_novos as $curso) : 
                $thumb = get_the_post_thumbnail_url($curso->ID, 'large') ?: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&q=80';
            ?>
            <div class="nf-course-card">
                <div class="nf-course-thumb">
                    <img src="<?php echo esc_url($thumb); ?>" alt="">
                    <div class="nf-course-overlay">
                        <a href="<?php echo get_permalink($curso->ID); ?>" class="nf-course-play">
                            <svg viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                        </a>
                    </div>
                </div>
                <div class="nf-course-info">
                    <h3 class="nf-course-title"><a href="<?php echo get_permalink($curso->ID); ?>"><?php echo esc_html($curso->post_title); ?></a></h3>
                    <div class="nf-course-meta">
                        <?php 
                        $modulos = function_exists('raz_lms_get_modulos') ? raz_lms_get_modulos($curso->ID) : array();
                        $total = 0;
                        foreach ($modulos as $m) {
                            $aulas = function_exists('raz_lms_get_aulas') ? raz_lms_get_aulas($m->ID) : array();
                            $total += count($aulas);
                        }
                        ?>
                        <span><?php echo count($modulos); ?> módulos</span>
                        <span><?php echo $total; ?> aulas</span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($cursos_concluidos)) : ?>
    <section class="nf-section">
        <div class="nf-section-header">
            <h2 class="nf-section-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                Concluídos
            </h2>
        </div>
        <div class="nf-courses-grid">
            <?php foreach ($cursos_concluidos as $curso) : 
                $thumb = get_the_post_thumbnail_url($curso->ID, 'large') ?: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&q=80';
            ?>
            <div class="nf-course-card">
                <span class="nf-badge-completed">✓ Concluído</span>
                <div class="nf-course-thumb">
                    <img src="<?php echo esc_url($thumb); ?>" alt="">
                    <div class="nf-course-overlay">
                        <a href="<?php echo get_permalink($curso->ID); ?>" class="nf-course-play">
                            <svg viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                        </a>
                    </div>
                </div>
                <div class="nf-course-info">
                    <h3 class="nf-course-title"><a href="<?php echo get_permalink($curso->ID); ?>"><?php echo esc_html($curso->post_title); ?></a></h3>
                    <div class="nf-course-progress"><div class="nf-course-progress-bar" style="width:100%;background:var(--nf-secondary)"></div></div>
                    <div class="nf-course-progress-text" style="color:var(--nf-secondary)">100% concluído</div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if (empty($cursos)) : ?>
    <div class="nf-empty">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
        <h3>Nenhum curso disponível</h3>
        <p>Você ainda não tem acesso a nenhum curso. Entre em contato para começar sua jornada!</p>
    </div>
    <?php endif; ?>
</div>

<script>
window.addEventListener('scroll',function(){
    var header=document.getElementById('header');
    if(window.scrollY>50){header.classList.add('scrolled')}else{header.classList.remove('scrolled')}
});
</script>
<?php wp_footer(); ?>
</body>
</html>
