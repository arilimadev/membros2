<?php
/**
 * Template: Esqueci Senha - Netflix Premium
 * @package RazNetflixPremium
 */
if (is_user_logged_in()) { wp_redirect(home_url('/meus-cursos/')); exit; }

$accent = get_option('raz_netflix_accent_color', '#e50914');
$bg = get_option('raz_netflix_bg_color', '#0a0a0a');
$login_logo = get_option('raz_lms_login_logo', '');
$message = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_login'])) {
    $user = get_user_by('email', sanitize_text_field($_POST['user_login'])) ?: get_user_by('login', sanitize_text_field($_POST['user_login']));
    if (!$user) { $error = 'Usuário ou e-mail não encontrado.'; }
    else {
        $key = get_password_reset_key($user);
        if (is_wp_error($key)) { $error = 'Erro ao gerar link. Tente novamente.'; }
        else {
            $msg = "Redefinição de senha solicitada.\n\nClique no link: ".network_site_url("wp-login.php?action=rp&key=$key&login=".rawurlencode($user->user_login), 'login');
            if (wp_mail($user->user_email, 'Redefinição de Senha', $msg)) { $message = 'Link enviado! Verifique seu email.'; }
            else { $error = 'Erro ao enviar email.'; }
        }
    }
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recuperar Senha - <?php bloginfo('name'); ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',-apple-system,sans-serif;min-height:100vh;display:flex;background:<?php echo esc_attr($bg); ?>;position:relative;overflow:hidden}
body::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,rgba(229,9,20,0.1) 0%,transparent 50%,rgba(70,211,105,0.05) 100%);pointer-events:none}
.login-container{flex:1;display:flex;align-items:center;justify-content:center;padding:20px;position:relative;z-index:1}
.login-box{background:rgba(20,20,20,0.95);backdrop-filter:blur(20px);border-radius:16px;padding:48px 40px;width:100%;max-width:420px;box-shadow:0 25px 80px rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.1)}
.login-logo{text-align:center;margin-bottom:32px}
.login-logo img{max-height:60px;max-width:200px}
.login-logo h1{font-size:28px;font-weight:700;color:#fff}
.icon-wrapper{text-align:center;margin-bottom:24px}
.icon-wrapper svg{width:64px;height:64px;color:<?php echo esc_attr($accent); ?>}
.login-title{text-align:center;margin-bottom:8px;font-size:24px;font-weight:600;color:#fff}
.login-subtitle{text-align:center;margin-bottom:32px;color:#a0a0a0;font-size:14px;line-height:1.5}
.form-group{margin-bottom:24px}
.form-group label{display:block;margin-bottom:8px;font-weight:500;font-size:14px;color:#e5e5e5}
.form-group input{width:100%;padding:16px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:12px;font-size:16px;color:#fff;transition:all 0.2s}
.form-group input:focus{outline:none;border-color:<?php echo esc_attr($accent); ?>;background:rgba(255,255,255,0.08)}
.btn-login{width:100%;padding:16px;background:<?php echo esc_attr($accent); ?>;color:#fff;border:none;border-radius:12px;font-size:16px;font-weight:600;cursor:pointer;transition:all 0.2s}
.btn-login:hover{filter:brightness(1.1);transform:translateY(-1px)}
.error-message{background:rgba(239,68,68,0.1);color:#ef4444;padding:14px 16px;border-radius:10px;margin-bottom:24px;font-size:14px;text-align:center;border:1px solid rgba(239,68,68,0.2)}
.success-message{background:rgba(70,211,105,0.1);color:#46d369;padding:14px 16px;border-radius:10px;margin-bottom:24px;font-size:14px;text-align:center;border:1px solid rgba(70,211,105,0.2)}
.login-footer{text-align:center;margin-top:24px;font-size:14px;color:#6b6b6b}
.login-footer a{color:<?php echo esc_attr($accent); ?>;text-decoration:none;font-weight:500}
.login-footer a:hover{text-decoration:underline}
@media(max-width:480px){.login-box{padding:32px 24px}}
</style>
</head>
<body>
<div class="login-container">
    <div class="login-box">
        <div class="login-logo">
            <?php if ($login_logo) : ?><img src="<?php echo esc_url($login_logo); ?>" alt="">
            <?php else : ?><h1><?php bloginfo('name'); ?></h1><?php endif; ?>
        </div>
        <div class="icon-wrapper">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M15 7a2 2 0 0 1 2 2m4 0a6 6 0 0 1-7.743 5.743L11 17H9v2H7v2H4a1 1 0 0 1-1-1v-2.586a1 1 0 0 1 .293-.707l5.964-5.964A6 6 0 1 1 21 9z"/></svg>
        </div>
        <h2 class="login-title">Recuperar senha</h2>
        <p class="login-subtitle">Digite seu email e enviaremos um link para criar uma nova senha.</p>
        <?php if ($error) : ?><div class="error-message"><?php echo esc_html($error); ?></div><?php endif; ?>
        <?php if ($message) : ?><div class="success-message"><?php echo esc_html($message); ?></div><?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label>Email</label>
                <input type="text" name="user_login" placeholder="seu@email.com" required autofocus>
            </div>
            <button type="submit" class="btn-login">Enviar link</button>
        </form>
        <div class="login-footer">
            <a href="<?php echo home_url('/login'); ?>">← Voltar para o login</a>
        </div>
    </div>
</div>
<?php wp_footer(); ?>
</body>
</html>
