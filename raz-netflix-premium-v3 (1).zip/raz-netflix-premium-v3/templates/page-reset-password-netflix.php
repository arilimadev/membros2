<?php
/**
 * Template: Nova Senha - Netflix Premium
 * @package RazNetflixPremium
 */
if (is_user_logged_in()) { wp_redirect(home_url('/meus-cursos')); exit; }

$accent = get_option('raz_netflix_accent_color', '#e50914');
$bg = get_option('raz_netflix_bg_color', '#0a0a0a');
$login_logo = get_option('raz_lms_login_logo', '');
$message = '';
$message_type = '';
$valid_key = false;
$key = isset($_GET['key']) ? sanitize_text_field($_GET['key']) : '';
$login = isset($_GET['login']) ? sanitize_text_field($_GET['login']) : '';

if ($key && $login) {
    $user = check_password_reset_key($key, $login);
    if (!is_wp_error($user)) $valid_key = true;
    else { $message = 'Link inválido ou expirado.'; $message_type = 'error'; }
}

if (isset($_POST['reset_submit']) && $valid_key) {
    $pass1 = $_POST['pass1'];
    $pass2 = $_POST['pass2'];
    if (empty($pass1) || empty($pass2)) { $message = 'Preencha os dois campos.'; $message_type = 'error'; }
    elseif ($pass1 !== $pass2) { $message = 'As senhas não coincidem.'; $message_type = 'error'; }
    elseif (strlen($pass1) < 6) { $message = 'Mínimo 6 caracteres.'; $message_type = 'error'; }
    else {
        reset_password($user, $pass1);
        $message = 'Senha alterada! Redirecionando...';
        $message_type = 'success';
        echo '<script>setTimeout(function(){location.href="'.home_url('/login').'";},2000);</script>';
    }
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Nova Senha - <?php bloginfo('name'); ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',-apple-system,sans-serif;min-height:100vh;display:flex;background:<?php echo esc_attr($bg); ?>;position:relative}
body::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,rgba(229,9,20,0.1) 0%,transparent 50%,rgba(70,211,105,0.05) 100%);pointer-events:none}
.login-container{flex:1;display:flex;align-items:center;justify-content:center;padding:20px;position:relative;z-index:1}
.login-box{background:rgba(20,20,20,0.95);backdrop-filter:blur(20px);border-radius:16px;padding:48px 40px;width:100%;max-width:420px;box-shadow:0 25px 80px rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.1)}
.login-logo{text-align:center;margin-bottom:32px}
.login-logo img{max-height:60px;max-width:200px}
.login-logo h1{font-size:28px;font-weight:700;color:#fff}
.icon-wrapper{text-align:center;margin-bottom:24px}
.icon-wrapper svg{width:64px;height:64px;color:<?php echo esc_attr($accent); ?>}
.login-title{text-align:center;margin-bottom:8px;font-size:24px;font-weight:600;color:#fff}
.login-subtitle{text-align:center;margin-bottom:32px;color:#a0a0a0;font-size:14px}
.form-group{margin-bottom:24px}
.form-group label{display:block;margin-bottom:8px;font-weight:500;font-size:14px;color:#e5e5e5}
.form-group input{width:100%;padding:16px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:12px;font-size:16px;color:#fff;transition:all 0.2s}
.form-group input:focus{outline:none;border-color:<?php echo esc_attr($accent); ?>;background:rgba(255,255,255,0.08)}
.form-group small{font-size:12px;color:#6b6b6b;margin-top:6px;display:block}
.btn-login{width:100%;padding:16px;background:<?php echo esc_attr($accent); ?>;color:#fff;border:none;border-radius:12px;font-size:16px;font-weight:600;cursor:pointer;transition:all 0.2s;text-decoration:none;display:block;text-align:center}
.btn-login:hover{filter:brightness(1.1);transform:translateY(-1px)}
.message{padding:14px 16px;border-radius:10px;margin-bottom:24px;font-size:14px;text-align:center}
.message.error{background:rgba(239,68,68,0.1);color:#ef4444;border:1px solid rgba(239,68,68,0.2)}
.message.success{background:rgba(70,211,105,0.1);color:#46d369;border:1px solid rgba(70,211,105,0.2)}
.login-footer{text-align:center;margin-top:24px;font-size:14px;color:#6b6b6b}
.login-footer a{color:<?php echo esc_attr($accent); ?>;text-decoration:none}
@media(max-width:480px){.login-box{padding:32px 24px}}
</style>
</head>
<body>
<div class="login-container">
    <div class="login-box">
        <div class="login-logo">
            <?php if ($login_logo) : ?><img src="<?php echo esc_url($login_logo); ?>" alt="">
            <?php else : ?><h1><?php bloginfo('name'); ?></h1><?php endif; ?>
        </div>
        <div class="icon-wrapper">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        </div>
        <h2 class="login-title">Criar nova senha</h2>
        <p class="login-subtitle">Digite sua nova senha abaixo</p>
        <?php if ($message) : ?><div class="message <?php echo esc_attr($message_type); ?>"><?php echo esc_html($message); ?></div><?php endif; ?>
        <?php if ($valid_key) : ?>
        <form method="post">
            <div class="form-group">
                <label>Nova senha</label>
                <input type="password" name="pass1" placeholder="••••••••" required autofocus>
                <small>Mínimo 6 caracteres</small>
            </div>
            <div class="form-group">
                <label>Confirmar senha</label>
                <input type="password" name="pass2" placeholder="••••••••" required>
            </div>
            <button type="submit" name="reset_submit" class="btn-login">Salvar nova senha</button>
        </form>
        <?php else : ?>
        <a href="<?php echo home_url('/esqueci-senha'); ?>" class="btn-login">Solicitar novo link</a>
        <?php endif; ?>
        <div class="login-footer">
            <a href="<?php echo home_url('/login'); ?>">← Voltar para o login</a>
        </div>
    </div>
</div>
<?php wp_footer(); ?>
</body>
</html>
