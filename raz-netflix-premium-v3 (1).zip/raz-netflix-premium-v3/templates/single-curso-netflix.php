<?php
/**
 * Template: Single Curso - Netflix Premium Experience v3
 * @package RazNetflixPremium
 */

if (function_exists('raz_validate_access_or_redirect')) {
    if (!raz_validate_access_or_redirect('curso')) return;
}

$curso = get_post();
$user_id = get_current_user_id();
$has_access = is_user_logged_in() && function_exists('raz_lms_user_has_access') && raz_lms_user_has_access($user_id, $curso->ID);

$all_modulos = function_exists('raz_lms_get_modulos') ? raz_lms_get_modulos($curso->ID) : array();
$modulos = array();

if ($has_access && function_exists('raz_user_can_access_modulo')) {
    foreach ($all_modulos as $mod) {
        if (raz_user_can_access_modulo($user_id, $mod->ID, $curso->ID)) {
            $modulos[] = $mod;
        }
    }
} else {
    $modulos = $all_modulos;
}

$total_aulas = 0;
$completed_aulas = 0;
foreach ($modulos as $mod) {
    $aulas_mod = function_exists('raz_lms_get_aulas') ? raz_lms_get_aulas($mod->ID) : array();
    $total_aulas += count($aulas_mod);
    if ($has_access && function_exists('raz_lms_is_lesson_completed')) {
        foreach ($aulas_mod as $aula) {
            if (raz_lms_is_lesson_completed($user_id, $aula->ID)) $completed_aulas++;
        }
    }
}
$percent = $total_aulas > 0 ? round(($completed_aulas / $total_aulas) * 100) : 0;

$thumbnail = get_the_post_thumbnail_url($curso->ID, 'full') ?: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1920&q=80';

$aula_destino = null;
$texto_botao = 'Começar';
if ($has_access && !empty($modulos)) {
    $last_aula_id = get_user_meta($user_id, '_raz_last_aula_' . $curso->ID, true);
    if ($last_aula_id && function_exists('raz_user_can_access_aula') && raz_user_can_access_aula($user_id, $last_aula_id)) {
        $aula_destino = get_post($last_aula_id);
        $texto_botao = 'Continuar';
    }
    if (!$aula_destino && function_exists('raz_lms_get_aulas')) {
        $aulas_primeiro = raz_lms_get_aulas($modulos[0]->ID);
        if (!empty($aulas_primeiro)) $aula_destino = $aulas_primeiro[0];
    }
}

// Cores do sistema
$accent = get_option('raz_netflix_accent_color', '#e50914');
$secondary = get_option('raz_netflix_secondary_color', '#46d369');
$bg_color = get_option('raz_netflix_bg_color', '#0a0a0a');
$surface_color = get_option('raz_netflix_surface_color', '#141414');

// Descrição truncada
$desc_full = $curso->post_content;
$desc_short = wp_trim_words(strip_tags($desc_full), 30, '...');
$has_long_desc = str_word_count(strip_tags($desc_full)) > 30;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> data-theme="dark">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo esc_html($curso->post_title); ?> - <?php bloginfo('name'); ?></title>
<?php wp_head(); ?>
<style>
:root{--nf-accent:<?php echo esc_attr($accent); ?>;--nf-secondary:<?php echo esc_attr($secondary); ?>;--nf-bg:<?php echo esc_attr($bg_color); ?>;--nf-surface:<?php echo esc_attr($surface_color); ?>;--nf-surface-2:#1f1f1f;--nf-surface-3:#2a2a2a;--nf-text:#fff;--nf-text-secondary:#a0a0a0;--nf-text-muted:#6b6b6b;--nf-border:#333}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',-apple-system,sans-serif;background:var(--nf-bg);color:var(--nf-text);min-height:100vh;overflow-x:hidden}

.nf-hero{position:relative;height:85vh;min-height:600px;display:flex;align-items:flex-end;overflow:hidden}
.nf-hero-bg{position:absolute;inset:0;z-index:1}
.nf-hero-bg img{width:100%;height:100%;object-fit:cover;filter:brightness(0.6)}
.nf-hero-overlay{position:absolute;inset:0;background:linear-gradient(90deg,rgba(0,0,0,0.9) 0%,rgba(0,0,0,0.4) 50%,transparent 100%),linear-gradient(180deg,transparent 0%,transparent 40%,var(--nf-bg) 100%);z-index:2}
.nf-hero-vignette{position:absolute;inset:0;box-shadow:inset 0 0 200px rgba(0,0,0,0.8);z-index:3;pointer-events:none}
.nf-hero-content{position:relative;z-index:10;max-width:650px;padding:0 5% 8%}
.nf-course-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,0.1);backdrop-filter:blur(10px);padding:8px 16px;border-radius:4px;font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:2px;margin-bottom:20px;border:1px solid rgba(255,255,255,0.1)}
.nf-course-badge svg{width:16px;height:16px;color:var(--nf-accent)}
.nf-hero-title{font-size:clamp(2rem,6vw,4rem);font-weight:800;line-height:1.1;margin-bottom:20px;text-shadow:0 4px 30px rgba(0,0,0,0.5);word-wrap:break-word;overflow-wrap:break-word}
.nf-hero-description{font-size:1rem;line-height:1.6;color:var(--nf-text-secondary);margin-bottom:24px;max-width:500px}
.nf-hero-description.truncated{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.nf-read-more{color:var(--nf-accent);background:none;border:none;cursor:pointer;font-size:14px;font-weight:600;padding:0;margin-top:8px}
.nf-read-more:hover{text-decoration:underline}
.nf-hero-meta{display:flex;flex-wrap:wrap;gap:20px;margin-bottom:30px}
.nf-meta-item{display:flex;align-items:center;gap:8px;font-size:14px;color:var(--nf-text-secondary)}
.nf-meta-item svg{width:18px;height:18px;color:var(--nf-accent)}
.nf-meta-item strong{color:var(--nf-text)}
.nf-progress-ring{display:flex;align-items:center;gap:12px;margin-bottom:30px}
.nf-ring-container{position:relative;width:60px;height:60px}
.nf-ring-bg,.nf-ring-progress{position:absolute;inset:0;border-radius:50%}
.nf-ring-bg{border:4px solid var(--nf-surface-2)}
.nf-ring-progress{border:4px solid transparent;border-top-color:var(--nf-accent);transform:rotate(-90deg);transition:all 1s cubic-bezier(0.4,0,0.2,1)}
.nf-ring-text{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700}
.nf-progress-label{font-size:14px;color:var(--nf-text-secondary)}
.nf-progress-label strong{display:block;font-size:16px;color:var(--nf-text)}
.nf-hero-actions{display:flex;gap:12px;flex-wrap:wrap}
.nf-btn{display:inline-flex;align-items:center;justify-content:center;gap:10px;padding:16px 32px;font-size:16px;font-weight:700;text-transform:uppercase;letter-spacing:1px;border-radius:4px;text-decoration:none;transition:all 0.3s;cursor:pointer;border:none}
.nf-btn svg{width:22px;height:22px}
.nf-btn-primary{background:var(--nf-text);color:var(--nf-bg)}
.nf-btn-primary:hover{background:rgba(255,255,255,0.8);transform:scale(1.05)}
.nf-btn-secondary{background:rgba(109,109,110,0.7);color:var(--nf-text)}
.nf-btn-secondary:hover{background:rgba(109,109,110,0.5)}
.nf-btn-back{position:fixed;top:20px;left:20px;z-index:100;width:50px;height:50px;background:rgba(0,0,0,0.6);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,0.1);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;transition:all 0.3s}
.nf-btn-back:hover{background:var(--nf-accent);transform:scale(1.1)}
.nf-btn-back svg{width:24px;height:24px}

.nf-content{max-width:1400px;margin:0 auto;padding:60px 5%}
.nf-section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:30px}
.nf-section-title{font-size:1.5rem;font-weight:700;display:flex;align-items:center;gap:12px}
.nf-section-title svg{width:24px;height:24px;color:var(--nf-accent)}

.nf-modules-grid{display:grid;gap:24px}
.nf-module-card{background:var(--nf-surface);border-radius:12px;overflow:hidden;border:1px solid var(--nf-border);transition:all 0.3s}
.nf-module-card:hover{border-color:var(--nf-accent);transform:translateY(-4px);box-shadow:0 20px 40px rgba(0,0,0,0.3)}
.nf-module-header{display:flex;gap:20px;padding:24px;cursor:pointer}
.nf-module-cover{width:160px;height:90px;background:linear-gradient(135deg,var(--nf-surface-2),var(--nf-surface-3));border-radius:8px;overflow:hidden;flex-shrink:0;display:flex;align-items:center;justify-content:center}
.nf-module-cover img{width:100%;height:100%;object-fit:cover}
.nf-module-cover svg{width:40px;height:40px;color:var(--nf-accent);opacity:0.5}
.nf-module-info{flex:1;min-width:0}
.nf-module-number{font-size:12px;color:var(--nf-accent);font-weight:600;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px}
.nf-module-title{font-size:1.1rem;font-weight:700;margin-bottom:8px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.nf-module-meta{display:flex;gap:16px;font-size:13px;color:var(--nf-text-muted)}
.nf-module-progress{width:100%;height:4px;background:var(--nf-surface-3);border-radius:2px;margin-top:12px;overflow:hidden}
.nf-module-progress-bar{height:100%;background:var(--nf-accent);border-radius:2px;transition:width 0.5s}
.nf-module-toggle{display:flex;align-items:center;justify-content:center;width:40px;color:var(--nf-text-muted);transition:transform 0.3s}
.nf-module-card.open .nf-module-toggle{transform:rotate(180deg)}
.nf-lessons-list{max-height:0;overflow:hidden;transition:max-height 0.4s ease;background:var(--nf-bg)}
.nf-module-card.open .nf-lessons-list{max-height:2000px}
.nf-lesson-item{display:flex;align-items:center;gap:16px;padding:16px 24px;border-top:1px solid var(--nf-border);transition:background 0.2s}
.nf-lesson-item:hover{background:var(--nf-surface)}
.nf-lesson-check{width:28px;height:28px;border:2px solid var(--nf-border);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all 0.2s}
.nf-lesson-check.done{background:var(--nf-accent);border-color:var(--nf-accent)}
.nf-lesson-check svg{width:14px;height:14px}
.nf-lesson-info{flex:1;min-width:0}
.nf-lesson-title{font-size:14px;font-weight:500;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.nf-lesson-title a{color:var(--nf-text);text-decoration:none}
.nf-lesson-title a:hover{color:var(--nf-accent)}
.nf-lesson-duration{font-size:12px;color:var(--nf-text-muted)}
.nf-lesson-item.locked{opacity:0.5}
.nf-lesson-item.locked .nf-lesson-title a{pointer-events:none}

.nf-desc-modal{display:none;position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,0.9);backdrop-filter:blur(10px);align-items:center;justify-content:center;padding:20px}
.nf-desc-modal.active{display:flex}
.nf-desc-content{background:var(--nf-surface);border-radius:16px;max-width:600px;width:100%;max-height:80vh;overflow-y:auto;padding:32px}
.nf-desc-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}
.nf-desc-header h3{font-size:1.25rem}
.nf-desc-close{background:none;border:none;color:var(--nf-text-muted);cursor:pointer;padding:8px}
.nf-desc-text{color:var(--nf-text-secondary);line-height:1.8}

@media(max-width:768px){
    .nf-hero{min-height:500px;height:auto;padding-top:60px}
    .nf-hero-content{padding:0 20px 40px}
    .nf-hero-title{font-size:1.75rem}
    .nf-btn{padding:14px 24px;font-size:14px}
    .nf-btn-back{top:10px;left:10px;width:44px;height:44px}
    .nf-module-header{flex-direction:column;gap:16px}
    .nf-module-cover{width:100%;height:120px}
    .nf-content{padding:40px 20px}
}
</style>
</head>
<body>

<a href="<?php echo home_url('/meus-cursos'); ?>" class="nf-btn-back" title="Voltar para Meus Cursos">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
</a>

<div class="nf-hero">
    <div class="nf-hero-bg"><img src="<?php echo esc_url($thumbnail); ?>" alt=""></div>
    <div class="nf-hero-overlay"></div>
    <div class="nf-hero-vignette"></div>
    <div class="nf-hero-content">
        <div class="nf-course-badge">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            Curso
        </div>
        <h1 class="nf-hero-title"><?php echo esc_html($curso->post_title); ?></h1>
        <?php if ($desc_short) : ?>
        <div class="nf-hero-description <?php echo $has_long_desc ? 'truncated' : ''; ?>" id="desc-short">
            <?php echo esc_html($desc_short); ?>
        </div>
        <?php if ($has_long_desc) : ?>
        <button class="nf-read-more" onclick="openDescModal()">Saiba mais</button>
        <?php endif; ?>
        <?php endif; ?>
        <div class="nf-hero-meta">
            <div class="nf-meta-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
                <strong><?php echo count($modulos); ?></strong> módulos
            </div>
            <div class="nf-meta-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                <strong><?php echo $total_aulas; ?></strong> aulas
            </div>
        </div>
        <?php if ($has_access && $percent > 0) : ?>
        <div class="nf-progress-ring">
            <div class="nf-ring-container">
                <div class="nf-ring-bg"></div>
                <div class="nf-ring-progress" style="transform:rotate(<?php echo -90 + ($percent * 3.6); ?>deg)"></div>
                <div class="nf-ring-text"><?php echo $percent; ?>%</div>
            </div>
            <div class="nf-progress-label">
                <strong><?php echo $completed_aulas; ?> de <?php echo $total_aulas; ?></strong>
                aulas concluídas
            </div>
        </div>
        <?php endif; ?>
        <div class="nf-hero-actions">
            <?php if ($has_access && $aula_destino) : ?>
            <a href="<?php echo get_permalink($aula_destino->ID); ?>" class="nf-btn nf-btn-primary">
                <svg viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                <?php echo $texto_botao; ?>
            </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="nf-content">
    <div class="nf-section-header">
        <h2 class="nf-section-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
            Módulos do Curso
        </h2>
    </div>
    <div class="nf-modules-grid">
        <?php foreach ($modulos as $index => $mod) :
            $mod_aulas = function_exists('raz_lms_get_aulas') ? raz_lms_get_aulas($mod->ID) : array();
            $mod_completed = 0;
            if ($has_access && function_exists('raz_lms_is_lesson_completed')) {
                foreach ($mod_aulas as $a) {
                    if (raz_lms_is_lesson_completed($user_id, $a->ID)) $mod_completed++;
                }
            }
            $mod_percent = count($mod_aulas) > 0 ? round(($mod_completed / count($mod_aulas)) * 100) : 0;
            $mod_cover = get_post_meta($mod->ID, '_raz_modulo_cover', true);
        ?>
        <div class="nf-module-card" data-module="<?php echo $mod->ID; ?>">
            <div class="nf-module-header" onclick="this.parentElement.classList.toggle('open')">
                <div class="nf-module-cover">
                    <?php if ($mod_cover) : ?>
                    <img src="<?php echo esc_url($mod_cover); ?>" alt="">
                    <?php else : ?>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                    <?php endif; ?>
                </div>
                <div class="nf-module-info">
                    <div class="nf-module-number">Módulo <?php echo $index + 1; ?></div>
                    <div class="nf-module-title"><?php echo esc_html($mod->post_title); ?></div>
                    <div class="nf-module-meta">
                        <span><?php echo count($mod_aulas); ?> aulas</span>
                        <?php if ($has_access) : ?><span><?php echo $mod_completed; ?>/<?php echo count($mod_aulas); ?> concluídas</span><?php endif; ?>
                    </div>
                    <?php if ($has_access) : ?>
                    <div class="nf-module-progress"><div class="nf-module-progress-bar" style="width:<?php echo $mod_percent; ?>%"></div></div>
                    <?php endif; ?>
                </div>
                <div class="nf-module-toggle">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><polyline points="6 9 12 15 18 9"/></svg>
                </div>
            </div>
            <div class="nf-lessons-list">
                <?php foreach ($mod_aulas as $aula) :
                    $is_done = $has_access && function_exists('raz_lms_is_lesson_completed') && raz_lms_is_lesson_completed($user_id, $aula->ID);
                    $lock = function_exists('raz_lms_check_routine_access') ? raz_lms_check_routine_access($user_id, $aula->ID) : array('locked' => false);
                    $is_locked = $lock['locked'];
                ?>
                <div class="nf-lesson-item <?php echo $is_locked ? 'locked' : ''; ?>">
                    <div class="nf-lesson-check <?php echo $is_done ? 'done' : ''; ?>">
                        <?php if ($is_locked) : ?>🔒<?php elseif ($is_done) : ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg><?php endif; ?>
                    </div>
                    <div class="nf-lesson-info">
                        <div class="nf-lesson-title">
                            <?php if (!$is_locked && $has_access) : ?>
                            <a href="<?php echo get_permalink($aula->ID); ?>"><?php echo esc_html($aula->post_title); ?></a>
                            <?php else : ?>
                            <?php echo esc_html($aula->post_title); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php if ($has_long_desc) : ?>
<div class="nf-desc-modal" id="desc-modal">
    <div class="nf-desc-content">
        <div class="nf-desc-header">
            <h3>Sobre o Curso</h3>
            <button class="nf-desc-close" onclick="closeDescModal()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><path d="M18 6 6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="nf-desc-text"><?php echo wpautop(esc_html($desc_full)); ?></div>
    </div>
</div>
<?php endif; ?>

<script>
function openDescModal(){document.getElementById('desc-modal').classList.add('active');document.body.style.overflow='hidden'}
function closeDescModal(){document.getElementById('desc-modal').classList.remove('active');document.body.style.overflow=''}
document.addEventListener('keydown',function(e){if(e.key==='Escape')closeDescModal()});
</script>
<?php wp_footer(); ?>
</body>
</html>
