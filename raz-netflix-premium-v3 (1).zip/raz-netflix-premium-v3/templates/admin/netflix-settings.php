<?php
/**
 * Admin: Configurações Netflix Premium
 * Para incluir no painel frontend do tema
 * @package RazNetflixPremium
 */
defined('ABSPATH') || exit;

if (!current_user_can('manage_options')) return;

// Opções atuais
$accent = get_option('raz_netflix_accent_color', '#e50914');
$secondary = get_option('raz_netflix_secondary_color', '#46d369');
$bg_color = get_option('raz_netflix_bg_color', '#0a0a0a');
$surface = get_option('raz_netflix_surface_color', '#141414');
$text_color = get_option('raz_netflix_text_color', '#ffffff');
$particles = get_option('raz_netflix_enable_particles', '1');
$comments = get_option('raz_netflix_enable_comments', '1');
$hero_url = get_option('raz_netflix_meus_cursos_hero', '');
$hero_type = get_option('raz_netflix_meus_cursos_hero_type', 'image');
?>

<style>
.nf-settings-card{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:24px;margin-bottom:24px}
.nf-settings-card h3{margin:0 0 20px;font-size:16px;font-weight:600;display:flex;align-items:center;gap:8px;padding-bottom:12px;border-bottom:1px solid #f1f5f9}
.nf-color-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px}
.nf-color-item{display:flex;flex-direction:column;gap:8px}
.nf-color-item label{font-size:13px;font-weight:500;color:#374151}
.nf-color-picker{display:flex;align-items:center;gap:10px;background:#f8fafc;padding:8px;border:1px solid #e2e8f0;border-radius:8px}
.nf-color-picker input[type="color"]{width:40px;height:32px;padding:0;border:none;background:none;cursor:pointer;border-radius:4px}
.nf-color-picker input[type="text"]{flex:1;border:none;background:transparent;font-family:monospace;font-size:13px;text-transform:uppercase}
.nf-toggle-row{display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid #f1f5f9}
.nf-toggle-row:last-child{border-bottom:none}
.nf-toggle-info{flex:1}
.nf-toggle-info strong{display:block;font-size:14px;color:#1e293b}
.nf-toggle-info small{font-size:12px;color:#64748b}
.nf-toggle{position:relative;width:48px;height:26px}
.nf-toggle input{opacity:0;width:0;height:0}
.nf-toggle-slider{position:absolute;cursor:pointer;inset:0;background:#cbd5e1;border-radius:13px;transition:0.3s}
.nf-toggle-slider:before{position:absolute;content:"";height:20px;width:20px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:0.3s}
.nf-toggle input:checked+.nf-toggle-slider{background:#0891b2}
.nf-toggle input:checked+.nf-toggle-slider:before{transform:translateX(22px)}
.nf-hero-upload{display:flex;gap:16px;align-items:flex-start}
.nf-hero-preview{width:200px;height:112px;background:#f1f5f9;border:2px dashed #cbd5e1;border-radius:8px;display:flex;align-items:center;justify-content:center;overflow:hidden}
.nf-hero-preview img,.nf-hero-preview video{width:100%;height:100%;object-fit:cover}
.nf-hero-preview.has-media{border-style:solid;border-color:#e2e8f0}
.nf-hero-actions{display:flex;flex-direction:column;gap:8px}
.nf-hero-type{display:flex;gap:8px;margin-bottom:8px}
.nf-hero-type label{display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer}
.nf-btn-save{display:inline-flex;align-items:center;gap:8px;padding:12px 24px;background:#0891b2;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;transition:all 0.2s}
.nf-btn-save:hover{background:#0e7490;transform:translateY(-1px)}
.nf-btn-secondary{padding:10px 16px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;font-size:13px;font-weight:500;cursor:pointer;transition:all 0.2s}
.nf-btn-secondary:hover{background:#f8fafc;border-color:#cbd5e1}
.nf-btn-text-danger{background:none;border:none;color:#dc2626;font-size:13px;cursor:pointer}
.nf-btn-text-danger:hover{text-decoration:underline}
.nf-presets{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px}
.nf-preset{width:32px;height:32px;border-radius:6px;cursor:pointer;border:2px solid transparent;transition:all 0.2s}
.nf-preset:hover{transform:scale(1.1)}
.nf-preset.active{border-color:#0891b2;box-shadow:0 0 0 2px rgba(8,145,178,0.2)}
</style>

<div class="nf-settings-card">
    <h3>🎨 Paleta de Cores do Plugin</h3>
    <p style="font-size:13px;color:#64748b;margin-bottom:20px;">Personalize as cores da experiência Netflix Premium. Estas cores substituem o vermelho/verde/preto padrão.</p>
    
    <div class="nf-color-grid">
        <div class="nf-color-item">
            <label>Cor Principal (Accent)</label>
            <div class="nf-color-picker">
                <input type="color" id="nf_accent" value="<?php echo esc_attr($accent); ?>">
                <input type="text" id="nf_accent_hex" value="<?php echo esc_attr($accent); ?>">
            </div>
        </div>
        <div class="nf-color-item">
            <label>Cor Secundária (Sucesso)</label>
            <div class="nf-color-picker">
                <input type="color" id="nf_secondary" value="<?php echo esc_attr($secondary); ?>">
                <input type="text" id="nf_secondary_hex" value="<?php echo esc_attr($secondary); ?>">
            </div>
        </div>
        <div class="nf-color-item">
            <label>Cor de Fundo</label>
            <div class="nf-color-picker">
                <input type="color" id="nf_bg" value="<?php echo esc_attr($bg_color); ?>">
                <input type="text" id="nf_bg_hex" value="<?php echo esc_attr($bg_color); ?>">
            </div>
        </div>
        <div class="nf-color-item">
            <label>Cor das Superfícies</label>
            <div class="nf-color-picker">
                <input type="color" id="nf_surface" value="<?php echo esc_attr($surface); ?>">
                <input type="text" id="nf_surface_hex" value="<?php echo esc_attr($surface); ?>">
            </div>
        </div>
        <div class="nf-color-item">
            <label>Cor do Texto</label>
            <div class="nf-color-picker">
                <input type="color" id="nf_text" value="<?php echo esc_attr($text_color); ?>">
                <input type="text" id="nf_text_hex" value="<?php echo esc_attr($text_color); ?>">
            </div>
        </div>
    </div>
    
    <div style="margin-top:20px;">
        <label style="font-size:13px;font-weight:500;color:#374151;">Temas Prontos:</label>
        <div class="nf-presets">
            <div class="nf-preset" style="background:linear-gradient(135deg,#e50914,#0a0a0a)" title="Netflix" onclick="applyPreset('#e50914','#46d369','#0a0a0a','#141414','#ffffff')"></div>
            <div class="nf-preset" style="background:linear-gradient(135deg,#0071eb,#0a0a0a)" title="Disney+" onclick="applyPreset('#0071eb','#00d4aa','#0a0a0a','#1a1d29','#ffffff')"></div>
            <div class="nf-preset" style="background:linear-gradient(135deg,#00d4aa,#0a0a0a)" title="Spotify" onclick="applyPreset('#1db954','#1ed760','#121212','#181818','#ffffff')"></div>
            <div class="nf-preset" style="background:linear-gradient(135deg,#ff6b35,#0a0a0a)" title="Fire" onclick="applyPreset('#ff6b35','#ffc107','#1a1a2e','#16213e','#ffffff')"></div>
            <div class="nf-preset" style="background:linear-gradient(135deg,#667eea,#764ba2)" title="Purple" onclick="applyPreset('#667eea','#764ba2','#0f0f1a','#1a1a2e','#ffffff')"></div>
            <div class="nf-preset" style="background:linear-gradient(135deg,#0891b2,#f8fafc)" title="Light" onclick="applyPreset('#0891b2','#10b981','#f8fafc','#ffffff','#1e293b')"></div>
        </div>
    </div>
</div>

<div class="nf-settings-card">
    <h3>⚙️ Funcionalidades</h3>
    
    <div class="nf-toggle-row">
        <div class="nf-toggle-info">
            <strong>Partículas de Fundo</strong>
            <small>Efeito visual de partículas flutuantes nas páginas</small>
        </div>
        <label class="nf-toggle">
            <input type="checkbox" id="nf_particles" <?php checked($particles, '1'); ?>>
            <span class="nf-toggle-slider"></span>
        </label>
    </div>
    
    <div class="nf-toggle-row">
        <div class="nf-toggle-info">
            <strong>Sistema de Comentários</strong>
            <small>Permite alunos comentarem nas aulas (configurável por curso)</small>
        </div>
        <label class="nf-toggle">
            <input type="checkbox" id="nf_comments" <?php checked($comments, '1'); ?>>
            <span class="nf-toggle-slider"></span>
        </label>
    </div>
</div>

<div class="nf-settings-card">
    <h3>🖼️ Hero da Página "Meus Cursos"</h3>
    <p style="font-size:13px;color:#64748b;margin-bottom:16px;">Adicione uma imagem ou vídeo de capa no topo da página de cursos do aluno.</p>
    
    <div class="nf-hero-upload">
        <div class="nf-hero-preview <?php echo $hero_url ? 'has-media' : ''; ?>" id="hero-preview">
            <?php if ($hero_url) : ?>
                <?php if ($hero_type === 'video') : ?>
                    <video src="<?php echo esc_url($hero_url); ?>" muted autoplay loop></video>
                <?php else : ?>
                    <img src="<?php echo esc_url($hero_url); ?>">
                <?php endif; ?>
            <?php else : ?>
                <span style="color:#94a3b8;font-size:12px;">Sem mídia</span>
            <?php endif; ?>
        </div>
        <div class="nf-hero-actions">
            <div class="nf-hero-type">
                <label><input type="radio" name="hero_type" value="image" <?php checked($hero_type, 'image'); ?>> Imagem</label>
                <label><input type="radio" name="hero_type" value="video" <?php checked($hero_type, 'video'); ?>> Vídeo</label>
            </div>
            <input type="hidden" id="nf_hero_url" value="<?php echo esc_url($hero_url); ?>">
            <button type="button" class="nf-btn-secondary" onclick="selectHeroMedia()">Selecionar Mídia</button>
            <?php if ($hero_url) : ?>
            <button type="button" class="nf-btn-text-danger" onclick="removeHeroMedia()">Remover</button>
            <?php endif; ?>
        </div>
    </div>
</div>

<div style="text-align:right;margin-top:24px;">
    <button type="button" class="nf-btn-save" onclick="saveNetflixSettings()">
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
        Salvar Configurações
    </button>
</div>

<script>
// Sincronizar color pickers
['accent','secondary','bg','surface','text'].forEach(function(id){
    var color = document.getElementById('nf_'+id);
    var hex = document.getElementById('nf_'+id+'_hex');
    color.addEventListener('input', function(){ hex.value = this.value; });
    hex.addEventListener('input', function(){ color.value = this.value; });
});

// Presets
function applyPreset(accent, secondary, bg, surface, text) {
    document.getElementById('nf_accent').value = accent;
    document.getElementById('nf_accent_hex').value = accent;
    document.getElementById('nf_secondary').value = secondary;
    document.getElementById('nf_secondary_hex').value = secondary;
    document.getElementById('nf_bg').value = bg;
    document.getElementById('nf_bg_hex').value = bg;
    document.getElementById('nf_surface').value = surface;
    document.getElementById('nf_surface_hex').value = surface;
    document.getElementById('nf_text').value = text;
    document.getElementById('nf_text_hex').value = text;
}

// Hero Media
var heroFrame;
function selectHeroMedia() {
    if (!heroFrame) {
        heroFrame = wp.media({
            title: 'Selecionar Mídia do Hero',
            button: { text: 'Usar esta mídia' },
            multiple: false
        });
        heroFrame.on('select', function() {
            var att = heroFrame.state().get('selection').first().toJSON();
            document.getElementById('nf_hero_url').value = att.url;
            var preview = document.getElementById('hero-preview');
            var type = document.querySelector('input[name="hero_type"]:checked').value;
            if (type === 'video') {
                preview.innerHTML = '<video src="'+att.url+'" muted autoplay loop></video>';
            } else {
                preview.innerHTML = '<img src="'+att.url+'">';
            }
            preview.classList.add('has-media');
        });
    }
    heroFrame.open();
}

function removeHeroMedia() {
    document.getElementById('nf_hero_url').value = '';
    var preview = document.getElementById('hero-preview');
    preview.innerHTML = '<span style="color:#94a3b8;font-size:12px;">Sem mídia</span>';
    preview.classList.remove('has-media');
}

// Save
function saveNetflixSettings() {
    var fd = new FormData();
    fd.append('action', 'raz_netflix_save_plugin_settings');
    fd.append('nonce', razNetflix.nonce);
    fd.append('accent_color', document.getElementById('nf_accent').value);
    fd.append('secondary_color', document.getElementById('nf_secondary').value);
    fd.append('bg_color', document.getElementById('nf_bg').value);
    fd.append('surface_color', document.getElementById('nf_surface').value);
    fd.append('text_color', document.getElementById('nf_text').value);
    fd.append('enable_particles', document.getElementById('nf_particles').checked ? '1' : '0');
    fd.append('enable_comments', document.getElementById('nf_comments').checked ? '1' : '0');
    
    fetch(razNetflix.ajaxurl, { method: 'POST', body: fd })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                // Salvar hero também
                var fd2 = new FormData();
                fd2.append('action', 'raz_netflix_save_hero_media');
                fd2.append('nonce', razNetflix.nonce);
                fd2.append('hero_url', document.getElementById('nf_hero_url').value);
                fd2.append('hero_type', document.querySelector('input[name="hero_type"]:checked').value);
                fetch(razNetflix.ajaxurl, { method: 'POST', body: fd2 });
                
                alert('Configurações salvas com sucesso!');
            }
        });
}
</script>
