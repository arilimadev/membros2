<?php
/**
 * Campo de Capa do Módulo - Para incluir no modal de edição de módulo
 * @package RazNetflixPremium
 */
defined('ABSPATH') || exit;

// Este arquivo deve ser incluído no modal de edição de módulo do tema
// Adiciona um campo para upload de imagem de capa do módulo
?>

<div class="form-section" style="margin-top:20px;">
    <label class="form-label">Imagem de Capa do Módulo</label>
    <p style="font-size:12px;color:#64748b;margin-bottom:12px;">Esta imagem aparece no card do módulo na página do curso (estilo Netflix).</p>
    
    <div style="display:flex;gap:16px;align-items:flex-start;">
        <div id="modulo-cover-preview" style="width:160px;height:90px;background:#f1f5f9;border:2px dashed #cbd5e1;border-radius:8px;display:flex;align-items:center;justify-content:center;overflow:hidden;">
            <span style="color:#94a3b8;font-size:11px;">Sem capa</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;">
            <input type="hidden" name="modulo_cover" id="modulo_cover" value="">
            <button type="button" class="btn btn-secondary btn-sm" onclick="selectModuloCover()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                Selecionar
            </button>
            <button type="button" class="btn-text-danger" onclick="removeModuloCover()" style="font-size:12px;background:none;border:none;color:#dc2626;cursor:pointer;display:none;" id="remove-cover-btn">
                Remover
            </button>
        </div>
    </div>
</div>

<script>
var moduloCoverFrame;

function selectModuloCover() {
    if (!moduloCoverFrame) {
        moduloCoverFrame = wp.media({
            title: 'Selecionar Capa do Módulo',
            button: { text: 'Usar esta imagem' },
            multiple: false,
            library: { type: 'image' }
        });
        
        moduloCoverFrame.on('select', function() {
            var att = moduloCoverFrame.state().get('selection').first().toJSON();
            document.getElementById('modulo_cover').value = att.url;
            
            var preview = document.getElementById('modulo-cover-preview');
            preview.innerHTML = '<img src="' + att.url + '" style="width:100%;height:100%;object-fit:cover;">';
            preview.style.borderStyle = 'solid';
            preview.style.borderColor = '#e2e8f0';
            
            document.getElementById('remove-cover-btn').style.display = 'block';
        });
    }
    
    moduloCoverFrame.open();
}

function removeModuloCover() {
    document.getElementById('modulo_cover').value = '';
    
    var preview = document.getElementById('modulo-cover-preview');
    preview.innerHTML = '<span style="color:#94a3b8;font-size:11px;">Sem capa</span>';
    preview.style.borderStyle = 'dashed';
    preview.style.borderColor = '#cbd5e1';
    
    document.getElementById('remove-cover-btn').style.display = 'none';
}

// Carregar capa existente ao abrir modal de edição
function loadModuloCover(coverUrl) {
    if (coverUrl) {
        document.getElementById('modulo_cover').value = coverUrl;
        
        var preview = document.getElementById('modulo-cover-preview');
        preview.innerHTML = '<img src="' + coverUrl + '" style="width:100%;height:100%;object-fit:cover;">';
        preview.style.borderStyle = 'solid';
        preview.style.borderColor = '#e2e8f0';
        
        document.getElementById('remove-cover-btn').style.display = 'block';
    }
}
</script>
