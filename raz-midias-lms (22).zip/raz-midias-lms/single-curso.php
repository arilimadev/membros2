<?php
/**
 * Template: Single Curso - Header Global Automático
 * @package RazMidiasLMS
 */

if (!raz_validate_access_or_redirect('curso')) {
    return; // Para a execução se não tiver acesso
}

get_header(); // AGORA O HEADER JÁ TRAZ O MENU HAMBÚRGUER AUTOMATICAMENTE

$curso = get_post();
$user_id = get_current_user_id();
$has_access = is_user_logged_in() && raz_lms_user_has_access($user_id, $curso->ID);

// 1. Busca todos os módulos do banco
$all_modulos = raz_lms_get_modulos($curso->ID);

// 2. Filtra apenas os módulos que o usuário pode ver (Baseado no Grupo de Acesso)
$modulos = array();
if ($has_access) {
    foreach ($all_modulos as $mod) {
        if (raz_user_can_access_modulo($user_id, $mod->ID, $curso->ID)) {
            $modulos[] = $mod;
        }
    }
} else {
    $modulos = $all_modulos;
}

// 3. Recalcula o total de aulas e progresso
$total_aulas = 0;
$completed_aulas = 0;

foreach ($modulos as $mod) {
    $aulas_mod = raz_lms_get_aulas($mod->ID);
    $total_aulas += count($aulas_mod);
    
    if ($has_access) {
        foreach ($aulas_mod as $aula) {
            if (raz_lms_is_lesson_completed($user_id, $aula->ID)) {
                $completed_aulas++;
            }
        }
    }
}

// 4. Progresso
if ($has_access) {
    $percent = $total_aulas > 0 ? round(($completed_aulas / $total_aulas) * 100) : 0;
    $progress = array('total' => $total_aulas, 'completed' => $completed_aulas, 'percent' => $percent);
} else {
    $progress = null;
}

// Cor do header (dinâmica)
$cor_header = get_post_meta($curso->ID, '_raz_curso_cor_header', true);
if (!$cor_header) $cor_header = '#667eea';

// --- LÓGICA INTELIGENTE DO BOTÃO ---
$aula_destino = null;
$texto_botao = 'Começar Curso';

if ($has_access && !empty($modulos)) {
    $last_aula_id = get_user_meta($user_id, '_raz_last_aula_' . $curso->ID, true);
    if ($last_aula_id && raz_user_can_access_aula($user_id, $last_aula_id)) {
        $aula_destino = get_post($last_aula_id);
        $texto_botao = 'Continuar Curso';
    }
    
    if (!$aula_destino) {
        $aulas_primeiro_modulo = raz_lms_get_aulas($modulos[0]->ID);
        if (!empty($aulas_primeiro_modulo)) {
            $aula_destino = $aulas_primeiro_modulo[0];
            if ($progress['completed'] > 0) $texto_botao = 'Continuar Curso';
        }
    }
}
?>

<style>
.raz-course-header { background: <?php echo esc_attr($cor_header); ?> !important; }
</style>

<div class="raz-course-page">
    <header class="raz-course-header">
        <div class="raz-course-header-content">
            <h1 class="raz-course-title"><?php the_title(); ?></h1>
            <?php if (has_excerpt()) : ?>
            <p class="raz-course-description"><?php echo get_the_excerpt(); ?></p>
            <?php endif; ?>
            
            <div class="raz-course-stats">
                <div class="raz-course-stat">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
                    <span><?php echo count($modulos); ?> módulos</span>
                </div>
                <div class="raz-course-stat">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                    <span><?php echo $total_aulas; ?> aulas</span>
                </div>
            </div>
            
            <?php if ($has_access && $aula_destino) : ?>
            <div style="margin-top:1.5rem;">
                <a href="<?php echo get_permalink($aula_destino->ID); ?>" class="raz-btn" style="background:#fff;color:<?php echo esc_attr($cor_header); ?>;padding:1rem 2rem;font-weight:600;">
                    <?php echo esc_html($texto_botao); ?>
                </a>
            </div>
            <?php elseif (!is_user_logged_in()) : ?>
            <div style="margin-top:1.5rem;">
                <a href="<?php echo wp_login_url(get_permalink()); ?>" class="raz-btn" style="background:#fff;color:<?php echo esc_attr($cor_header); ?>;padding:1rem 2rem;font-weight:600;">Fazer Login</a>
            </div>
            <?php endif; ?>
        </div>
    </header>
    
    <div class="raz-course-content">
        <?php if ($has_access && $progress) : ?>
        <div class="raz-course-progress">
            <div class="raz-course-progress-header">
                <span class="raz-course-progress-text"><?php echo $progress['completed']; ?> de <?php echo $progress['total']; ?> aulas concluídas</span>
                <span class="raz-course-progress-percent"><?php echo $progress['percent']; ?>%</span>
            </div>
            <div class="raz-course-progress-bar">
                <div class="raz-course-progress-fill" style="width:<?php echo $progress['percent']; ?>%;"></div>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if (get_the_content()) : ?>
        <div class="raz-lesson-content" style="margin-bottom:2rem;">
            <?php the_content(); ?>
        </div>
        <?php endif; ?>
        
        <h2 class="raz-course-section-title">Conteúdo do Curso</h2>
        
        <div class="raz-course-modules" style="display:flex;flex-direction:column;gap:1rem;">
            <?php 
            if (empty($modulos)) : ?>
                <p style="text-align:center; color: var(--text-secondary); padding: 20px;">Nenhum conteúdo disponível para o seu grupo de acesso.</p>
            <?php else :
                foreach ($modulos as $index => $modulo) :
                    $modulo_aulas = raz_lms_get_aulas($modulo->ID);
                    $modulo_progress = $has_access ? raz_lms_get_module_progress($user_id, $modulo->ID) : null;
                    $modulo_completed = $modulo_progress && $modulo_progress['percent'] == 100;
                ?>
                <div class="raz-course-module <?php echo $index === 0 ? 'open' : ''; ?> <?php echo $modulo_completed ? 'completed' : ''; ?>" style="background:var(--bg-primary);border:1px solid var(--border);border-radius:12px;overflow:hidden;">
                    <div class="raz-course-module-header" onclick="this.parentElement.classList.toggle('open')" style="display:flex;align-items:center;gap:1rem;padding:1.25rem;cursor:pointer;">
                        <div class="raz-course-module-number" style="display:flex;align-items:center;justify-content:center;width:40px;height:40px;min-width:40px;background:<?php echo $modulo_completed ? 'var(--success)' : 'var(--bg-tertiary)'; ?>;border-radius:8px;font-weight:600;color:<?php echo $modulo_completed ? 'var(--text-white)' : 'var(--text-secondary)'; ?>;">
                            <?php if ($modulo_completed) : ?>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><polyline points="20 6 9 17 4 12"/></svg>
                            <?php else : ?>
                                <?php echo str_pad($index + 1, 2, '0', STR_PAD_LEFT); ?>
                            <?php endif; ?>
                        </div>
                        <div class="raz-course-module-info" style="flex:1;min-width:0;">
                            <h3 style="font-size:1rem;font-weight:600;margin:0 0 .25rem;"><?php echo esc_html($modulo->post_title); ?></h3>
                            <span style="font-size:.8125rem;color:var(--text-secondary);">
                                <?php echo count($modulo_aulas); ?> aulas
                                <?php if ($modulo_progress) : ?> • <?php echo $modulo_progress['completed']; ?>/<?php echo $modulo_progress['total']; ?> concluídas<?php endif; ?>
                            </span>
                        </div>
                        <div class="raz-course-module-toggle" style="width:32px;height:32px;display:flex;align-items:center;justify-content:center;color:var(--text-secondary);transition:transform .15s;">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><polyline points="6 9 12 15 18 9"/></svg>
                        </div>
                    </div>
                    
                    <div class="raz-course-module-lessons" style="display:none;border-top:1px solid var(--border);">
                        <?php foreach ($modulo_aulas as $aula) :
                            $aula_completed = $has_access && raz_lms_is_lesson_completed($user_id, $aula->ID);
                            $aula_tipo = get_post_meta($aula->ID, '_raz_aula_tipo', true) ?: 'video';
                            $aula_duracao = get_post_meta($aula->ID, '_raz_aula_duracao', true);
                        ?>
                        <a href="<?php echo $has_access ? get_permalink($aula->ID) : 'javascript:void(0)'; ?>" class="raz-course-lesson <?php echo $aula_completed ? 'completed' : ''; ?>" style="display:flex;align-items:center;gap:1rem;padding:1rem 1.25rem;border-bottom:1px solid var(--border-light);text-decoration:none;transition:background 0.15s;<?php echo $has_access ? 'cursor:pointer;' : 'cursor:default;'; ?>" <?php if ($has_access) echo 'onmouseover="this.style.background=\'#f8fafc\'" onmouseout="this.style.background=\'transparent\'"'; ?>>
                            <div style="display:flex;align-items:center;justify-content:center;width:24px;height:24px;min-width:24px;border:2px solid <?php echo $aula_completed ? 'var(--success)' : 'var(--border)'; ?>;border-radius:4px;background:<?php echo $aula_completed ? 'var(--success)' : 'transparent'; ?>;">
                                <?php if ($aula_completed) : ?>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" width="14" height="14"><polyline points="20 6 9 17 4 12"/></svg>
                                <?php endif; ?>
                            </div>
                            <div style="flex:1;min-width:0;">
                                <span style="font-size:.9375rem;color:<?php echo $aula_completed ? 'var(--text-secondary)' : 'var(--text-primary)'; ?>;"><?php echo esc_html($aula->post_title); ?></span>
                                <div style="display:flex;align-items:center;gap:.25rem;font-size:.75rem;color:var(--text-muted);margin-top:.25rem;">
                                    <?php if ($aula_tipo === 'video') : ?>
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polygon points="5 3 19 12 5 21 5 3"/></svg> Vídeo
                                    <?php elseif ($aula_tipo === 'audio') : ?>
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg> Áudio
                                    <?php else : ?>
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg> Texto
                                    <?php endif; ?>
                                    <?php if ($aula_duracao) echo ' • ' . esc_html($aula_duracao); ?>
                                </div>
                            </div>
                            <?php if ($has_access) : ?>
                            <div style="display:flex;align-items:center;justify-content:center;width:36px;height:36px;background:var(--primary);border-radius:8px;color:var(--text-white);">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                            </div>
                            <?php endif; ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; 
            endif; ?>
        </div>
        
        <?php if (!$has_access && !is_user_logged_in()) : ?>
        <div class="raz-access-blocked" style="margin-top:2rem;background:var(--bg-secondary);border-radius:12px;padding:3rem;">
            <div class="raz-access-blocked-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            </div>
            <h3 class="raz-access-blocked-title">Conteúdo Exclusivo</h3>
            <p class="raz-access-blocked-message">Faça login ou adquira o curso para ter acesso completo.</p>
            <a href="<?php echo wp_login_url(get_permalink()); ?>" class="raz-access-blocked-btn">Fazer Login</a>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.raz-course-module.open .raz-course-module-toggle { transform: rotate(180deg); }
.raz-course-module.open .raz-course-module-lessons { display: block !important; }
.raz-course-lesson:last-child { border-bottom: none; }
.raz-course-lesson:hover { background: var(--bg-secondary); }
</style>

<?php get_footer(); ?>