<?php
/**
 * AJAX Handlers para Sistema de Alunos
 * Adicionar este arquivo em: /wp-content/themes/raz-midias-lms/inc/ajax-handlers-alunos.php
 * 
 * NO functions.php adicionar:
 * require_once get_template_directory() . '/inc/ajax-handlers-alunos.php';
 */

if (!defined('ABSPATH')) exit;

// ============================================================================
// AJAX: Buscar dados do usuário para edição
// ============================================================================
add_action('wp_ajax_raz_get_user', 'raz_ajax_get_user_handler');
function raz_ajax_get_user_handler() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Sem permissão']);
    }
    
    $user_id = intval($_GET['user_id'] ?? 0);
    
    if (!$user_id) {
        wp_send_json_error(['message' => 'ID inválido']);
    }
    
    $user = get_userdata($user_id);
    
    if (!$user) {
        wp_send_json_error(['message' => 'Usuário não encontrado']);
    }
    
    // Busca cursos do usuário
    global $wpdb;
    $cursos_meta = $wpdb->get_results($wpdb->prepare(
        "SELECT meta_key FROM {$wpdb->usermeta} 
         WHERE user_id = %d 
         AND meta_key LIKE '_raz_curso_acesso_%'",
        $user_id
    ));
    
    $cursos = [];
    foreach ($cursos_meta as $meta) {
        $curso_id = str_replace('_raz_curso_acesso_', '', $meta->meta_key);
        $cursos[] = intval($curso_id);
    }
    
    // Busca telefone
    $telefone = get_user_meta($user_id, '_raz_user_telefone', true);
    
    // Busca tipo de acesso
    $acesso_tipo = get_user_meta($user_id, '_raz_acesso_tipo', true) ?: 'dias';
    
    // Busca dias de acesso
    $dias_acesso = get_user_meta($user_id, '_raz_dias_acesso', true) ?: 365;
    
    wp_send_json_success([
        'name' => $user->display_name,
        'email' => $user->user_email,
        'telefone' => $telefone,
        'cursos' => $cursos,
        'acesso_tipo' => $acesso_tipo,
        'dias_acesso' => $dias_acesso
    ]);
}

// ============================================================================
// AJAX: Salvar/Criar usuário
// ============================================================================
add_action('wp_ajax_raz_save_user', 'raz_ajax_save_user_handler');
function raz_ajax_save_user_handler() {
    try {
        check_ajax_referer('raz_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Sem permissão']);
        }
        
        $user_id = intval($_POST['user_id'] ?? 0);
        
        // IMPORTANTE: Pegar valores antes de sanitizar para debug
        $name_raw = $_POST['user_name'] ?? '';
        $email_raw = $_POST['user_email'] ?? '';
        
        // Sanitizar
        $name = sanitize_text_field($name_raw);
        $email = sanitize_email($email_raw);
        $telefone = sanitize_text_field($_POST['user_telefone'] ?? '');
        $password = $_POST['user_password'] ?? '';
        $cursos = isset($_POST['user_cursos']) && is_array($_POST['user_cursos']) 
            ? array_map('intval', $_POST['user_cursos']) 
            : [];
        $acesso_tipo = sanitize_text_field($_POST['acesso_tipo'] ?? 'dias');
        $dias_acesso = intval($_POST['dias_acesso'] ?? 365);
        $user_grupos = isset($_POST['user_grupos']) && is_array($_POST['user_grupos']) 
            ? $_POST['user_grupos'] 
            : [];
        
        // Validação com trim
        $name = trim($name);
        $email = trim($email);
        
        if (strlen($name) === 0 || strlen($email) === 0) {
            wp_send_json_error([
                'message' => 'Nome e email são obrigatórios',
                'debug' => [
                    'name_raw' => $name_raw,
                    'email_raw' => $email_raw,
                    'name_sanitized' => $name,
                    'email_sanitized' => $email,
                    'name_length' => strlen($name),
                    'email_length' => strlen($email),
                    'post_keys' => array_keys($_POST),
                    'isset_user_name' => isset($_POST['user_name']),
                    'isset_user_email' => isset($_POST['user_email'])
                ]
            ]);
            return;
        }
    
    // Validar email
    if (!is_email($email)) {
        wp_send_json_error(['message' => 'Email inválido']);
    }
    
    // Criar ou atualizar usuário
    if ($user_id) {
        // Editar existente
        $user_data = [
            'ID' => $user_id,
            'display_name' => $name,
            'user_email' => $email
        ];
        
        // Só atualiza senha se fornecida
        if (!empty($password)) {
            if (strlen($password) < 6) {
                wp_send_json_error(['message' => 'Senha deve ter no mínimo 6 caracteres']);
            }
            $user_data['user_pass'] = $password;
        }
        
        $result = wp_update_user($user_data);
        
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }
    } else {
        // Criar novo
        
        // Verificar se email já existe
        if (email_exists($email)) {
            wp_send_json_error(['message' => 'Este email já está cadastrado']);
        }
        
        // Gera senha se não fornecida
        if (empty($password)) {
            $password = wp_generate_password(12, false);
        } elseif (strlen($password) < 6) {
            wp_send_json_error(['message' => 'Senha deve ter no mínimo 6 caracteres']);
        }
        
        $user_data = [
            'user_login' => $email,
            'user_email' => $email,
            'display_name' => $name,
            'user_pass' => $password,
            'role' => 'subscriber'
        ];
        
        $user_id = wp_insert_user($user_data);
        
        if (is_wp_error($user_id)) {
            wp_send_json_error(['message' => $user_id->get_error_message()]);
        }
    }
    
    // Salvar telefone
    update_user_meta($user_id, '_raz_user_telefone', $telefone);
    
    // Salvar tipo de acesso
    update_user_meta($user_id, '_raz_acesso_tipo', $acesso_tipo);
    update_user_meta($user_id, '_raz_dias_acesso', $dias_acesso);
    
    // Limpar cursos antigos
    global $wpdb;
    $wpdb->query($wpdb->prepare(
        "DELETE FROM {$wpdb->usermeta} 
         WHERE user_id = %d 
         AND meta_key LIKE '_raz_curso_acesso_%'",
        $user_id
    ));
    
    // Adicionar novos cursos
    foreach ($cursos as $curso_id) {
        if (!$curso_id) continue;
        
        $data_inicio = current_time('mysql');
        
        // Calcular data de expiração
        if ($acesso_tipo === 'vitalicio') {
            $data_expiracao = null;
            $vitalicio = true;
        } else {
            $data_expiracao = date('Y-m-d H:i:s', strtotime('+' . $dias_acesso . ' days'));
            $vitalicio = false;
        }
        
        $acesso_data = [
            'inicio' => $data_inicio,
            'expiracao' => $data_expiracao,
            'vitalicio' => $vitalicio,
            'origem' => 'manual'
        ];
        
        update_user_meta($user_id, '_raz_curso_acesso_' . $curso_id, $acesso_data);
    }
    
    // Salvar grupos de acesso (se função existir)
    if (function_exists('raz_save_aluno_grupos') && !empty($user_grupos)) {
        raz_save_aluno_grupos($user_id, $user_grupos);
    }
    
    wp_send_json_success([
        'message' => 'Aluno salvo com sucesso',
        'user_id' => $user_id
    ]);
    
    } catch (Exception $e) {
        wp_send_json_error([
            'message' => 'Erro ao salvar: ' . $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
    }
}

// ============================================================================
// AJAX: Deletar usuário
// ============================================================================
add_action('wp_ajax_raz_delete_user', 'raz_ajax_delete_user_handler');
function raz_ajax_delete_user_handler() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Sem permissão']);
    }
    
    $user_id = intval($_POST['user_id'] ?? 0);
    
    if (!$user_id) {
        wp_send_json_error(['message' => 'ID inválido']);
    }
    
    // Não permitir deletar o próprio usuário
    if ($user_id === get_current_user_id()) {
        wp_send_json_error(['message' => 'Você não pode deletar seu próprio usuário']);
    }
    
    // Não permitir deletar admin
    $user = get_userdata($user_id);
    if ($user && in_array('administrator', $user->roles)) {
        wp_send_json_error(['message' => 'Não é possível deletar administradores']);
    }
    
    require_once(ABSPATH . 'wp-admin/includes/user.php');
    $result = wp_delete_user($user_id);
    
    if ($result) {
        wp_send_json_success(['message' => 'Usuário deletado com sucesso']);
    } else {
        wp_send_json_error(['message' => 'Erro ao deletar usuário']);
    }
}

// ============================================================================
// AJAX: Buscar cursos do usuário
// ============================================================================
add_action('wp_ajax_raz_get_user_cursos', 'raz_ajax_get_user_cursos_handler');
function raz_ajax_get_user_cursos_handler() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Sem permissão']);
    }
    
    $user_id = intval($_GET['user_id'] ?? 0);
    
    if (!$user_id) {
        wp_send_json_error(['message' => 'ID inválido']);
    }
    
    global $wpdb;
    $cursos_meta = $wpdb->get_results($wpdb->prepare(
        "SELECT meta_key, meta_value FROM {$wpdb->usermeta} 
         WHERE user_id = %d 
         AND meta_key LIKE '_raz_curso_acesso_%'",
        $user_id
    ));
    
    $cursos_data = [];
    
    foreach ($cursos_meta as $meta) {
        $curso_id = str_replace('_raz_curso_acesso_', '', $meta->meta_key);
        $curso = get_post($curso_id);
        
        if (!$curso) continue;
        
        $data = maybe_unserialize($meta->meta_value);
        
        $vitalicio = isset($data['vitalicio']) && $data['vitalicio'];
        $expiracao = isset($data['expiracao']) ? $data['expiracao'] : null;
        $expirado = false;
        
        if (!$vitalicio && $expiracao) {
            $expirado = strtotime($expiracao) < time();
        }
        
        $cursos_data[] = [
            'id' => $curso_id,
            'nome' => $curso->post_title,
            'vitalicio' => $vitalicio,
            'expiracao' => $expiracao ? date('d/m/Y', strtotime($expiracao)) : null,
            'expirado' => $expirado
        ];
    }
    
    wp_send_json_success($cursos_data);
}

// ============================================================================
// AJAX: Buscar auditoria do usuário
// ============================================================================
add_action('wp_ajax_raz_get_user_audit', 'raz_ajax_get_user_audit_handler');
function raz_ajax_get_user_audit_handler() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Sem permissão']);
    }
    
    $user_id = intval($_GET['user_id'] ?? 0);
    $page = intval($_GET['page'] ?? 1);
    $per_page = 10;
    
    if (!$user_id) {
        wp_send_json_error(['message' => 'ID inválido']);
    }
    
    $user = get_userdata($user_id);
    
    if (!$user) {
        wp_send_json_error(['message' => 'Usuário não encontrado']);
    }
    
    // Último acesso
    $ultimo_acesso = get_user_meta($user_id, '_raz_ultimo_acesso', true);
    $last_access_date = $ultimo_acesso ? date('d/m/Y H:i', is_numeric($ultimo_acesso) ? $ultimo_acesso : strtotime($ultimo_acesso)) : 'Nunca';
    $dias_sem_acesso = $ultimo_acesso ? floor((time() - (is_numeric($ultimo_acesso) ? $ultimo_acesso : strtotime($ultimo_acesso))) / 86400) : null;
    
    // Buscar histórico de acessos (se existir tabela)
    global $wpdb;
    $table_tracking = $wpdb->prefix . 'raz_tracking';
    
    $history = [];
    $total_acessos = 0;
    $total_pages = 1;
    
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_tracking'") == $table_tracking) {
        $total_acessos = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_tracking WHERE user_id = %d",
            $user_id
        ));
        
        $total_pages = ceil($total_acessos / $per_page);
        $offset = ($page - 1) * $per_page;
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_tracking 
             WHERE user_id = %d 
             ORDER BY created_at DESC 
             LIMIT %d OFFSET %d",
            $user_id,
            $per_page,
            $offset
        ));
        
        foreach ($results as $row) {
            $history[] = [
                'date' => date('d/m/Y H:i', strtotime($row->created_at)),
                'curso' => get_the_title($row->curso_id) ?: '-',
                'modulo' => get_the_title($row->modulo_id) ?: '-',
                'aula' => get_the_title($row->aula_id) ?: '-',
                'ip' => $row->ip_address ?: '-'
            ];
        }
    }
    
    $data = [
        'last_access' => [
            'date' => $last_access_date,
            'dias_sem_acesso' => $dias_sem_acesso,
            'curso' => '-',
            'aula' => '-',
            'browser' => '-',
            'os' => '-',
            'ip' => '-'
        ],
        'posicao' => [
            'modulo' => '-',
            'aula' => '-',
            'progresso' => '0%'
        ],
        'user' => [
            'registered' => date('d/m/Y', strtotime($user->user_registered)),
            'origem' => get_user_meta($user_id, '_raz_user_origem', true) ?: 'manual'
        ],
        'total_acessos' => $total_acessos,
        'history' => $history,
        'total_pages' => $total_pages
    ];
    
    wp_send_json_success($data);
}

// ============================================================================
// AJAX: Buscar grupos do usuário
// ============================================================================
add_action('wp_ajax_raz_get_user_grupos_data', 'raz_ajax_get_user_grupos_data_handler');
function raz_ajax_get_user_grupos_data_handler() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Sem permissão']);
    }
    
    $user_id = intval($_GET['user_id'] ?? 0);
    
    if (!$user_id) {
        wp_send_json_error(['message' => 'ID inválido']);
    }
    
    $user_grupos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos)) {
        $user_grupos = [];
    }
    
    wp_send_json_success($user_grupos);
}

// ============================================================================
// DEBUG: Verificar se handlers estão registrados
// ============================================================================
// Descomente as linhas abaixo para debug:
// add_action('admin_footer', function() {
//     if (current_user_can('manage_options')) {
//         echo '<script>console.log("AJAX Handlers Alunos: CARREGADOS");</script>';
//     }
// });