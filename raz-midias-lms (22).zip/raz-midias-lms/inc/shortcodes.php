<?php
/**
 * Shortcodes
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * [raz_meus_cursos] - Lista cursos do usuário logado
 */
function raz_lms_shortcode_meus_cursos($atts) {
    if (!is_user_logged_in()) {
        return '<div class="raz-alert">Você precisa estar logado para ver seus cursos. <a href="' . wp_login_url(get_permalink()) . '">Fazer login</a></div>';
    }
    
    $user_id = get_current_user_id();
    $cursos = raz_lms_get_user_courses($user_id);
    
    if (empty($cursos)) {
        return '<div class="raz-alert">Você ainda não possui cursos. <a href="' . home_url('/cursos/') . '">Ver cursos disponíveis</a></div>';
    }
    
    ob_start();
    ?>
    <div class="raz-dashboard-courses">
        <?php foreach ($cursos as $curso) :
            $expiracao = raz_lms_get_access_expiration($user_id, $curso->ID);
            $expired = $expiracao && $expiracao !== 'vitalicio' && strtotime($expiracao) < time();
            $primeira_aula = null;
            $modulos = raz_lms_get_modulos($curso->ID);
            if (!empty($modulos)) {
                $aulas = raz_lms_get_aulas($modulos[0]->ID);
                if (!empty($aulas)) $primeira_aula = $aulas[0];
            }
        ?>
        <div class="raz-course-card <?php echo $expired ? 'expired' : ''; ?>">
            <?php if (has_post_thumbnail($curso->ID)) : ?>
            <div class="raz-course-card-image">
                <?php echo get_the_post_thumbnail($curso->ID, 'raz-course-card'); ?>
            </div>
            <?php endif; ?>
            
            <div class="raz-course-card-content">
                <?php if ($expired) : ?>
                <div class="raz-course-card-expired-badge">Acesso expirado</div>
                <?php endif; ?>
                
                <h3 class="raz-course-card-title"><?php echo esc_html($curso->post_title); ?></h3>
                
                <div class="raz-course-card-meta">
                    <span><?php echo raz_lms_count_aulas($curso->ID); ?> aulas</span>
                </div>
                
                <div class="raz-course-card-progress">
                    <div class="raz-course-card-progress-header">
                        <span>Progresso</span>
                        <span><?php echo $curso->progresso['percent']; ?>%</span>
                    </div>
                    <div class="raz-course-card-progress-bar">
                        <div class="raz-course-card-progress-fill" style="width: <?php echo $curso->progresso['percent']; ?>%;"></div>
                    </div>
                </div>
                
                <?php if (!$expired && $primeira_aula) : ?>
                <a href="<?php echo get_permalink($primeira_aula->ID); ?>" class="raz-course-card-action">
                    <?php echo $curso->progresso['completed'] > 0 ? 'Continuar' : 'Começar'; ?>
                </a>
                <?php else : ?>
                <span class="raz-course-card-action" style="background:#94a3b8;cursor:not-allowed;">Acesso Expirado</span>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('raz_meus_cursos', 'raz_lms_shortcode_meus_cursos');

/**
 * [raz_lista_cursos] - Lista todos os cursos
 */
function raz_lms_shortcode_lista_cursos($atts) {
    $atts = shortcode_atts(array(
        'limit' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
    ), $atts);
    
    $cursos = get_posts(array(
        'post_type' => 'curso',
        'posts_per_page' => intval($atts['limit']),
        'orderby' => sanitize_text_field($atts['orderby']),
        'order' => sanitize_text_field($atts['order']),
    ));
    
    if (empty($cursos)) {
        return '<p>Nenhum curso disponível no momento.</p>';
    }
    
    ob_start();
    ?>
    <div class="raz-dashboard-courses">
        <?php foreach ($cursos as $curso) : ?>
        <div class="raz-course-card">
            <?php if (has_post_thumbnail($curso->ID)) : ?>
            <div class="raz-course-card-image">
                <a href="<?php echo get_permalink($curso->ID); ?>">
                    <?php echo get_the_post_thumbnail($curso->ID, 'raz-course-card'); ?>
                </a>
            </div>
            <?php endif; ?>
            
            <div class="raz-course-card-content">
                <h3 class="raz-course-card-title">
                    <a href="<?php echo get_permalink($curso->ID); ?>"><?php echo esc_html($curso->post_title); ?></a>
                </h3>
                
                <div class="raz-course-card-meta">
                    <span><?php echo raz_lms_count_aulas($curso->ID); ?> aulas</span>
                    <span><?php echo count(raz_lms_get_modulos($curso->ID)); ?> módulos</span>
                </div>
                
                <?php if (has_excerpt($curso->ID)) : ?>
                <p style="color:var(--text-secondary);font-size:.875rem;margin-bottom:1rem;"><?php echo wp_trim_words(get_the_excerpt($curso->ID), 15); ?></p>
                <?php endif; ?>
                
                <a href="<?php echo get_permalink($curso->ID); ?>" class="raz-course-card-action">Ver Curso</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('raz_lista_cursos', 'raz_lms_shortcode_lista_cursos');

/**
 * [raz_progresso_curso id="123"] - Mostra progresso de um curso específico
 */
function raz_lms_shortcode_progresso_curso($atts) {
    if (!is_user_logged_in()) {
        return '';
    }
    
    $atts = shortcode_atts(array(
        'id' => 0,
    ), $atts);
    
    $curso_id = intval($atts['id']);
    if (!$curso_id) {
        return '';
    }
    
    $user_id = get_current_user_id();
    
    if (!raz_lms_user_has_access($user_id, $curso_id)) {
        return '';
    }
    
    $progress = raz_lms_get_course_progress($user_id, $curso_id);
    
    ob_start();
    ?>
    <div class="raz-course-progress" style="margin:1rem 0;">
        <div class="raz-course-progress-header">
            <span class="raz-course-progress-text">
                <?php echo $progress['completed']; ?> de <?php echo $progress['total']; ?> aulas concluídas
            </span>
            <span class="raz-course-progress-percent"><?php echo $progress['percent']; ?>%</span>
        </div>
        <div class="raz-course-progress-bar">
            <div class="raz-course-progress-fill" style="width: <?php echo $progress['percent']; ?>%;"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('raz_progresso_curso', 'raz_lms_shortcode_progresso_curso');

/**
 * [raz_login_form] - Formulário de login personalizado
 */
function raz_lms_shortcode_login_form($atts) {
    if (is_user_logged_in()) {
        $user = wp_get_current_user();
        return '<div class="raz-alert">Olá, ' . esc_html($user->display_name) . '! <a href="' . home_url('/meus-cursos/') . '">Ver meus cursos</a> | <a href="' . wp_logout_url(home_url()) . '">Sair</a></div>';
    }
    
    $atts = shortcode_atts(array(
        'redirect' => home_url('/meus-cursos/'),
    ), $atts);
    
    return wp_login_form(array(
        'echo' => false,
        'redirect' => $atts['redirect'],
        'form_id' => 'raz-login-form',
        'label_username' => 'Email ou Usuário',
        'label_password' => 'Senha',
        'label_remember' => 'Lembrar-me',
        'label_log_in' => 'Entrar',
        'remember' => true,
    ));
}
add_shortcode('raz_login_form', 'raz_lms_shortcode_login_form');
