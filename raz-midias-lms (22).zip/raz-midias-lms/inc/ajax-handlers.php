<?php
/**
 * AJAX Handlers Adicionais
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * Toggle lesson complete (para checkbox clicável na sidebar)
 */
function raz_lms_ajax_toggle_lesson() {
    check_ajax_referer('raz_lms_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Não autorizado'));
    }
    
    $aula_id = isset($_POST['aula_id']) ? intval($_POST['aula_id']) : 0;
    $completed = isset($_POST['completed']) ? $_POST['completed'] === '1' : true;
    $user_id = get_current_user_id();
    
    if (!$aula_id || get_post_type($aula_id) !== 'aula') {
        wp_send_json_error(array('message' => 'Aula inválida'));
    }
    
    $lessons = get_user_meta($user_id, '_raz_completed_lessons', true) ?: array();
    
    if ($completed && !in_array($aula_id, $lessons)) {
        $lessons[] = $aula_id;
    } elseif (!$completed && in_array($aula_id, $lessons)) {
        $lessons = array_diff($lessons, array($aula_id));
    }
    
    update_user_meta($user_id, '_raz_completed_lessons', array_values($lessons));
    
    // Retornar progresso do módulo atualizado
    $modulo_id = get_post_meta($aula_id, '_raz_aula_modulo', true);
    $module_progress = $modulo_id ? raz_lms_get_module_progress($user_id, $modulo_id) : null;
    
    wp_send_json_success(array(
        'completed' => $completed,
        'module_progress' => $module_progress
    ));
}
add_action('wp_ajax_raz_toggle_lesson', 'raz_lms_ajax_toggle_lesson');
