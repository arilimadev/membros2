<?php
/**
 * Sistema de Grupos de Acesso v2.1 (CORRIGIDO)
 * Controle de acesso por MÓDULOS dentro de cada curso
 * * Correção: Ajuste das meta_keys para o padrão do tema (_raz_*)
 * * @package RazMidiasLMS
 * @version 2.1.0
 */

defined('ABSPATH') || exit;

// ============================================================================
// 1. FUNÇÕES PRINCIPAIS DE VALIDAÇÃO DE ACESSO
// ============================================================================

/**
 * Verifica se o usuário tem acesso a um módulo específico
 * * @param int $user_id ID do usuário
 * @param int $modulo_id ID do módulo
 * @param int $curso_id ID do curso
 * @return bool True se tem acesso
 */
function raz_user_can_access_modulo($user_id, $modulo_id, $curso_id) {
    // Admin sempre tem acesso
    if (user_can($user_id, 'manage_options')) {
        return true;
    }
    
    // Busca grupos do usuário neste curso
    $user_grupos = raz_get_user_grupos_in_curso($user_id, $curso_id);
    
    if (empty($user_grupos)) {
        return false;
    }
    
    // Busca configuração de grupos do curso
    $curso_grupos = raz_get_curso_grupos_config($curso_id);
    
    // Verifica se algum grupo do usuário libera este módulo
    foreach ($user_grupos as $grupo_slug) {
        if (isset($curso_grupos[$grupo_slug])) {
            $modulos_liberados = $curso_grupos[$grupo_slug]['modulos'] ?? [];
            
            // Verifica se o módulo está no array de liberados
            // (Converte para int para garantir comparação correta)
            if (in_array(intval($modulo_id), array_map('intval', $modulos_liberados))) {
                return true;
            }
        }
    }
    
    return false;
}

/**
 * Verifica se o usuário tem acesso a uma aula
 * * @param int $user_id ID do usuário
 * @param int $aula_id ID da aula
 * @return bool True se tem acesso
 */
function raz_user_can_access_aula($user_id, $aula_id) {
    // Admin sempre tem acesso
    if (user_can($user_id, 'manage_options')) {
        return true;
    }
    
    // 1. Busca o módulo da aula (CORRIGIDO: usa a chave _raz_aula_modulo)
    $modulo_id = get_post_meta($aula_id, '_raz_aula_modulo', true);
    
    if (!$modulo_id) {
        // Se não tem módulo, tenta buscar pelo curso diretamente (Fallback)
        // (Isso é raro na estrutura atual, mas mantido por segurança)
        $curso_id = get_post_meta($aula_id, '_raz_aula_curso', true); // Corrigido chave também
        if ($curso_id) {
            return raz_user_can_access_curso($user_id, $curso_id);
        }
        return false;
    }
    
    // 2. Busca o curso do módulo (CORRIGIDO: usa a chave _raz_modulo_curso)
    $curso_id = get_post_meta($modulo_id, '_raz_modulo_curso', true);
    
    if (!$curso_id) {
        return false;
    }
    
    // 3. Valida se o usuário tem acesso a esse módulo específico nesse curso
    return raz_user_can_access_modulo($user_id, $modulo_id, $curso_id);
}

/**
 * Verifica se o usuário tem acesso ao curso
 * * @param int $user_id ID do usuário
 * @param int $curso_id ID do curso
 * @return bool True se tem acesso
 */
function raz_user_can_access_curso($user_id, $curso_id) {
    // Admin sempre tem acesso
    if (user_can($user_id, 'manage_options')) {
        return true;
    }
    
    // Verifica se tem algum grupo no curso
    $user_grupos = raz_get_user_grupos_in_curso($user_id, $curso_id);
    
    // Se tiver qualquer grupo atribuído, considera que tem acesso "ao curso"
    // (O acesso às aulas será filtrado depois)
    return !empty($user_grupos);
}

// ============================================================================
// 2. FUNÇÕES DE GERENCIAMENTO DE GRUPOS DO CURSO
// ============================================================================

/**
 * Busca configuração de grupos de um curso
 * * @param int $curso_id ID do curso
 * @return array Configuração dos grupos
 */
function raz_get_curso_grupos_config($curso_id) {
    $grupos = get_post_meta($curso_id, '_raz_curso_grupos', true);
    
    if (!is_array($grupos) || empty($grupos)) {
        // Cria grupo padrão se não existir
        $grupos = [
            'padrao' => [
                'nome' => 'Padrão',
                'modulos' => [],
                'is_default' => true
            ]
        ];
        // Não salvamos automaticamente aqui para não poluir o banco em leituras
    }
    
    return $grupos;
}

/**
 * Salva configuração de grupos do curso
 * * @param int $curso_id ID do curso
 * @param array $grupos Configuração dos grupos
 * @return bool True se salvou com sucesso
 */
function raz_save_curso_grupos_config($curso_id, $grupos) {
    if (!is_array($grupos)) {
        return false;
    }
    
    return update_post_meta($curso_id, '_raz_curso_grupos', $grupos);
}

/**
 * Adiciona um novo grupo ao curso
 */
function raz_add_grupo_to_curso($curso_id, $slug, $nome, $modulos = [], $is_default = false) {
    $grupos = raz_get_curso_grupos_config($curso_id);
    
    if (isset($grupos[$slug])) {
        return false;
    }
    
    if ($is_default) {
        foreach ($grupos as $key => $grupo) {
            $grupos[$key]['is_default'] = false;
        }
    }
    
    $grupos[$slug] = [
        'nome' => $nome,
        'modulos' => $modulos,
        'is_default' => $is_default
    ];
    
    return raz_save_curso_grupos_config($curso_id, $grupos);
}

/**
 * Remove um grupo do curso
 */
function raz_remove_grupo_from_curso($curso_id, $slug) {
    $grupos = raz_get_curso_grupos_config($curso_id);
    
    if (!isset($grupos[$slug])) {
        return false;
    }
    
    unset($grupos[$slug]);
    
    return raz_save_curso_grupos_config($curso_id, $grupos);
}

// ============================================================================
// 3. FUNÇÕES DE GERENCIAMENTO DE GRUPOS DO USUÁRIO
// ============================================================================

/**
 * Busca grupos de um usuário em um curso específico
 * * @param int $user_id ID do usuário
 * @param int $curso_id ID do curso
 * @return array Array de slugs de grupos
 */
function raz_get_user_grupos_in_curso($user_id, $curso_id) {
    // Cache simples em memória para evitar múltiplas chamadas na mesma página
    static $cache = [];
    $cache_key = $user_id . '_' . $curso_id;
    
    if (isset($cache[$cache_key])) {
        return $cache[$cache_key];
    }
    
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos)) {
        $user_grupos_cursos = [];
    }
    
    $curso_key = 'curso_' . $curso_id;
    $grupos = isset($user_grupos_cursos[$curso_key]) && is_array($user_grupos_cursos[$curso_key]) 
        ? $user_grupos_cursos[$curso_key] 
        : [];
    
    $cache[$cache_key] = $grupos;
    
    return $grupos;
}

/**
 * Adiciona usuário a um grupo de um curso
 */
function raz_add_user_to_curso_grupo($user_id, $curso_id, $grupo_slug) {
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos)) {
        $user_grupos_cursos = [];
    }
    
    $curso_key = 'curso_' . $curso_id;
    
    if (!isset($user_grupos_cursos[$curso_key])) {
        $user_grupos_cursos[$curso_key] = [];
    }
    
    if (!in_array($grupo_slug, $user_grupos_cursos[$curso_key])) {
        $user_grupos_cursos[$curso_key][] = $grupo_slug;
        return update_user_meta($user_id, '_raz_user_grupos_cursos', $user_grupos_cursos);
    }
    
    return false;
}

/**
 * Remove usuário de um grupo de um curso
 */
function raz_remove_user_from_curso_grupo($user_id, $curso_id, $grupo_slug) {
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos)) {
        return false;
    }
    
    $curso_key = 'curso_' . $curso_id;
    
    if (!isset($user_grupos_cursos[$curso_key])) {
        return false;
    }
    
    $key = array_search($grupo_slug, $user_grupos_cursos[$curso_key]);
    
    if ($key !== false) {
        unset($user_grupos_cursos[$curso_key][$key]);
        // Reindexa array
        $user_grupos_cursos[$curso_key] = array_values($user_grupos_cursos[$curso_key]);
        return update_user_meta($user_id, '_raz_user_grupos_cursos', $user_grupos_cursos);
    }
    
    return false;
}

/**
 * Define grupos do usuário em um curso (substitui todos)
 */
function raz_set_user_grupos_in_curso($user_id, $curso_id, $grupos_slugs) {
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos)) {
        $user_grupos_cursos = [];
    }
    
    $curso_key = 'curso_' . $curso_id;
    $user_grupos_cursos[$curso_key] = is_array($grupos_slugs) ? $grupos_slugs : [];
    
    return update_user_meta($user_id, '_raz_user_grupos_cursos', $user_grupos_cursos);
}

// ============================================================================
// 4. INTEGRAÇÃO COM TEMPLATES
// ============================================================================

/**
 * Valida acesso ou redireciona para página de bloqueio
 */
function raz_validate_access_or_redirect($tipo = 'curso') {
    if (!is_user_logged_in()) {
        wp_redirect(home_url('/login'));
        exit;
    }
    
    $user_id = get_current_user_id();
    $post_id = get_the_ID();
    
    $has_access = false;
    
    if ($tipo === 'curso') {
        $has_access = raz_user_can_access_curso($user_id, $post_id);
    } elseif ($tipo === 'aula') {
        $has_access = raz_user_can_access_aula($user_id, $post_id);
    }
    
    if (!$has_access) {
        raz_display_access_blocked($tipo);
        return false;
    }
    
    return true;
}

/**
 * Exibe mensagem de acesso bloqueado
 */
function raz_display_access_blocked($tipo = 'curso') {
    // Carrega o template específico se existir
    if (file_exists(RAZ_LMS_DIR . '/templates/access-blocked.php')) {
        include(RAZ_LMS_DIR . '/templates/access-blocked.php');
        exit;
    }
    
    // Fallback simples
    get_header();
    ?>
    <div class="raz-access-blocked" style="max-width: 600px; margin: 80px auto; text-align: center; padding: 40px;">
        <div style="font-size: 64px; margin-bottom: 20px;">🔒</div>
        <h1 style="font-size: 32px; margin-bottom: 16px; color: #1e293b;">Acesso Restrito</h1>
        <p style="color: #64748b; font-size: 16px; margin-bottom: 32px; line-height: 1.6;">
            Você não tem permissão para acessar <?php echo $tipo === 'curso' ? 'este curso' : 'esta aula'; ?>.
        </p>
        <a href="<?php echo home_url('/meus-cursos'); ?>" style="display: inline-block; background: #0284c7; color: #fff; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600;">
            Ver Meus Cursos
        </a>
    </div>
    <?php
    get_footer();
    exit;
}

// ============================================================================
// 5. FILTROS E HOOKS
// ============================================================================

/**
 * Adiciona usuário ao grupo padrão quando registrado
 */
add_action('user_register', 'raz_add_new_user_to_default_grupos', 10, 1);
function raz_add_new_user_to_default_grupos($user_id) {
    $cursos = get_posts([
        'post_type' => 'curso',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ]);
    
    foreach ($cursos as $curso_id) {
        $grupos = raz_get_curso_grupos_config($curso_id);
        
        foreach ($grupos as $slug => $data) {
            if (!empty($data['is_default'])) {
                raz_add_user_to_curso_grupo($user_id, $curso_id, $slug);
                break;
            }
        }
    }
}

// ============================================================================
// 6. AJAX HANDLERS
// ============================================================================

add_action('wp_ajax_raz_save_curso_grupos', 'raz_ajax_save_curso_grupos');
function raz_ajax_save_curso_grupos() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Sem permissão']);
    
    $curso_id = intval($_POST['curso_id'] ?? 0);
    $grupos = json_decode(stripslashes($_POST['grupos'] ?? '{}'), true);
    
    if (raz_save_curso_grupos_config($curso_id, $grupos)) {
        wp_send_json_success(['message' => 'Grupos salvos']);
    } else {
        wp_send_json_error(['message' => 'Erro ao salvar']);
    }
}

add_action('wp_ajax_raz_get_curso_grupos', 'raz_ajax_get_curso_grupos');
function raz_ajax_get_curso_grupos() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Sem permissão']);
    
    $curso_id = intval($_GET['curso_id'] ?? 0);
    wp_send_json_success(['grupos' => raz_get_curso_grupos_config($curso_id)]);
}

add_action('wp_ajax_raz_save_aluno_grupos', 'raz_ajax_save_aluno_grupos');
function raz_ajax_save_aluno_grupos() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Sem permissão']);
    
    $user_id = intval($_POST['user_id'] ?? 0);
    $grupos = $_POST['grupos'] ?? [];
    
    if (raz_save_aluno_grupos($user_id, $grupos)) {
        wp_send_json_success(['message' => 'Salvo com sucesso']);
    } else {
        wp_send_json_error(['message' => 'Erro ao salvar']);
    }
}

function raz_save_aluno_grupos($user_id, $grupos_data) {
    if (!is_array($grupos_data)) return false;
    
    $user_grupos_cursos = [];
    foreach ($grupos_data as $curso_id => $grupos) {
        if (!empty($grupos) && is_array($grupos)) {
            $curso_key = 'curso_' . intval($curso_id);
            $user_grupos_cursos[$curso_key] = array_values($grupos);
        }
    }
    return update_user_meta($user_id, '_raz_user_grupos_cursos', $user_grupos_cursos);
}