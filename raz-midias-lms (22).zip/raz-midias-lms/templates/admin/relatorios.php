<?php
/**
 * Admin: Relatórios - Foco em Progresso do Aluno (10 itens por página)
 * Removido Avatar e Negrito no nome.
 */
global $wpdb;

// 1. Configurações Iniciais e Filtros
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));
$curso_id = isset($_GET['curso']) ? intval($_GET['curso']) : ($cursos[0]->ID ?? 0);
$curso = get_post($curso_id);

$s_aluno = isset($_GET['s_aluno']) ? sanitize_text_field($_GET['s_aluno']) : '';
$current_page_slug = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : 'gestao-cursos';

// 2. Paginação Configurada para 10 itens
$per_page = 10; 
$current_paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$offset = ($current_paged - 1) * $per_page;

if ($curso) {
    // 3. Lógica de Busca de Alunos
    $user_search_query = "";
    if (!empty($s_aluno)) {
        $user_ids_found = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->users} WHERE user_email LIKE %s OR display_name LIKE %s",
            '%' . $s_aluno . '%', '%' . $s_aluno . '%'
        ));
        if (!empty($user_ids_found)) {
            $user_search_query = " AND user_id IN (" . implode(',', array_map('intval', $user_ids_found)) . ")";
        } else {
            $user_search_query = " AND user_id = 0";
        }
    }

    // 4. Contagem Total para Paginação
    $total_alunos = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key = %s $user_search_query",
        '_raz_curso_acesso_' . $curso_id
    ));

    // 5. Busca Paginada
    $alunos_query = $wpdb->get_results($wpdb->prepare(
        "SELECT DISTINCT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s $user_search_query ORDER BY user_id DESC LIMIT %d OFFSET %d",
        '_raz_curso_acesso_' . $curso_id,
        $per_page,
        $offset
    ));

    $total_pages = ceil($total_alunos / $per_page);
}
?>

<style>
    .report-header-flex {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;
        flex-wrap: wrap;
        gap: 15px;
    }
    .search-input-group {
        display: flex;
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .search-input-group input {
        border: none !important;
        padding: 8px 15px !important;
        width: 220px;
        font-size: 13px;
    }
    .search-input-group button {
        background: #f8fafc;
        border: none;
        border-left: 1px solid #ddd;
        padding: 0 15px;
        cursor: pointer;
    }
    .data-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
    }
    .data-table th {
        background: #f8fafc;
        color: #64748b;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 11px;
        letter-spacing: 0.05em;
        padding: 12px 20px;
        border-bottom: 2px solid #edf2f7;
    }
    .data-table td {
        padding: 12px 20px;
        border-bottom: 1px solid #f1f5f9;
        vertical-align: middle;
        font-weight: 400; /* Garante que o texto não fique em negrito */
    }
    .data-table tr:hover td { background-color: #fcfdfe; }
    
    .progress-bar-container {
        flex: 1; height: 8px; background: #e2e8f0;
        border-radius: 10px; overflow: hidden; min-width: 120px;
    }
    .progress-bar-fill {
        height: 100%; background: #4f46e5;
        border-radius: 10px; transition: width 0.6s ease;
    }
    .progress-bar-fill.completed { background: #10b981; }

    .badge-status {
        font-size: 10px; padding: 2px 8px;
        border-radius: 20px; font-weight: 600;
    }
    .badge-completed { background: #ecfdf5; color: #059669; }
    .badge-progress { background: #f5f3ff; color: #7c3aed; }

    .raz-pagination {
        display: flex;
        justify-content: center;
        margin-top: 30px;
        gap: 5px;
    }
    .raz-pagination .page-numbers {
        padding: 6px 12px;
        border-radius: 6px;
        text-decoration: none;
        color: #475569;
        background: #fff;
        border: 1px solid #e2e8f0;
        font-size: 13px;
    }
    .raz-pagination .current {
        background: #4f46e5;
        color: #fff;
        border-color: #4f46e5;
    }
</style>

<div class="admin-header report-header-flex">
    <div>
        <h2>👨‍🎓 Relatório de Alunos</h2>
        <p style="color: #64748b; margin: 0; font-size: 13px;">Exibindo <?php echo count($alunos_query); ?> de <?php echo $total_alunos; ?> alunos matriculados.</p>
    </div>
    
    <div style="display:flex; gap:10px; align-items: center;">
        <form method="get" class="search-input-group">
            <input type="hidden" name="page" value="<?php echo esc_attr($current_page_slug); ?>">
            <input type="hidden" name="tab" value="relatorios">
            <input type="hidden" name="curso" value="<?php echo intval($curso_id); ?>">
            <input type="text" name="s_aluno" placeholder="E-mail ou nome..." value="<?php echo esc_attr($s_aluno); ?>">
            <button type="submit">🔍</button>
        </form>

        <select onchange="location.href='?page=<?php echo esc_attr($current_page_slug); ?>&tab=relatorios&curso='+this.value" style="padding:8px 12px; border-radius:8px; border:1px solid #ddd; min-width:200px;">
            <?php foreach ($cursos as $c) : ?>
            <option value="<?php echo $c->ID; ?>" <?php selected($curso_id, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>

<?php if ($curso) : ?>
    <div class="form-card" style="padding: 0; overflow: hidden; border-radius: 10px;">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Aluno</th>
                    <th>E-mail</th>
                    <th style="text-align: center;">Status</th>
                    <th>Progresso no Curso</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($alunos_query)) : foreach ($alunos_query as $row) :
                    $user = get_userdata($row->user_id);
                    if (!$user) continue;
                    
                    $progress = raz_lms_get_course_progress($row->user_id, $curso_id);
                ?>
                <tr>
                    <td style="font-weight: 400;"><?php echo esc_html($user->display_name); ?></td>
                    <td><code style="background: transparent; color: #64748b; border: none;"><?php echo esc_html($user->user_email); ?></code></td>
                    <td style="text-align: center;">
                        <?php if ($progress['percent'] >= 100) : ?>
                            <span class="badge-status badge-completed">CONCLUÍDO</span>
                        <?php else : ?>
                            <span class="badge-status badge-progress">EM CURSO</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div style="display:flex; align-items:center; gap:12px;">
                            <div class="progress-bar-container">
                                <div class="progress-bar-fill <?php echo ($progress['percent'] >= 100) ? 'completed' : ''; ?>" style="width: <?php echo $progress['percent']; ?>%;"></div>
                            </div>
                            <span style="font-weight: 700; font-size: 12px; min-width: 35px;"><?php echo $progress['percent']; ?>%</span>
                            <small style="color: #94a3b8; font-size: 10px;">(<?php echo $progress['completed']; ?>/<?php echo $progress['total']; ?>)</small>
                        </div>
                    </td>
                </tr>
                <?php endforeach; else : ?>
                <tr><td colspan="4" style="text-align: center; padding: 60px; color: #94a3b8;">Nenhum aluno encontrado.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="raz-pagination">
        <?php 
            echo paginate_links(array(
                'base'      => add_query_arg('paged', '%#%'),
                'format'    => '',
                'prev_text' => __('« Anterior'),
                'next_text' => __('Próxima »'),
                'total'     => $total_pages,
                'current'   => $current_paged,
                'type'      => 'plain'
            ));
        ?>
    </div>
<?php endif; ?>