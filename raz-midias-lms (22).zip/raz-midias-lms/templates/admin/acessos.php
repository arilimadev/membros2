<?php
/**
 * Admin: Acessos com filtros e paginação
 * @package RazMidiasLMS
 */

// Verifica permissão básica
if (!current_user_can('manage_options')) {
    wp_die('Acesso negado.');
}

// URL Base Limpa (Para redirecionamentos e links)
global $wp;
$current_url = home_url(add_query_arg(array(), $wp->request));
// Se estiver em uma subpasta/slug, pegamos a URI atual sem parâmetros
$base_url = strtok($_SERVER["REQUEST_URI"], '?');

// ==============================================================================
// 1. LÓGICA DE PROCESSAMENTO (SALVAR E REVOGAR)
// ==============================================================================

$mensagem_feedback = '';

// --- A. ADICIONAR ACESSO (LIBERAR) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['raz_action']) && $_POST['raz_action'] == 'add_access_manual') {
    
    if (isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'raz_grant_access_manual')) {
        
        $email_user = sanitize_email($_POST['user_email']); 
        $curso_id = intval($_POST['curso_id']);
        $tipo_acesso = sanitize_text_field($_POST['tipo']);
        $dias = intval($_POST['dias']);
        
        $user = get_user_by('email', $email_user);
        
        if ($user && $curso_id) {
            // 1. Salvar o Acesso ao Curso
            $cursos_atuais = get_user_meta($user->ID, '_raz_user_cursos', true);
            if (!is_array($cursos_atuais)) $cursos_atuais = array();
            
            if (!in_array($curso_id, $cursos_atuais)) {
                $cursos_atuais[] = $curso_id;
                update_user_meta($user->ID, '_raz_user_cursos', $cursos_atuais);
            }

            // 2. Salvar Detalhes
            $dados_acesso = [
                'inicio' => current_time('mysql'),
                'tipo' => $tipo_acesso,
                'vitalicio' => ($tipo_acesso === 'vitalicio')
            ];
            
            if ($tipo_acesso !== 'vitalicio') {
                $dados_acesso['expiracao'] = date('Y-m-d H:i:s', strtotime("+$dias days"));
            }
            update_user_meta($user->ID, '_raz_curso_acesso_' . $curso_id, $dados_acesso);

            // 3. Salvar Grupos
            if (isset($_POST['grupos_selecionados']) && is_array($_POST['grupos_selecionados'])) {
                $grupos_keys = array_map('sanitize_text_field', $_POST['grupos_selecionados']);
                update_user_meta($user->ID, '_raz_user_grupos_' . $curso_id, $grupos_keys);
            } else {
                delete_user_meta($user->ID, '_raz_user_grupos_' . $curso_id);
            }

            $mensagem_feedback = '<div class="notice notice-success is-dismissible" style="margin-left:0; margin-bottom:20px; background:#dcfce7; border:1px solid #22c55e; color:#14532d; padding:10px;"><p>✅ Acesso liberado com sucesso para <strong>' . esc_html($user->display_name) . '</strong>!</p></div>';
        } else {
            $mensagem_feedback = '<div class="notice notice-error is-dismissible" style="margin-left:0; margin-bottom:20px; background:#fee2e2; border:1px solid #ef4444; color:#7f1d1d; padding:10px;"><p>❌ Erro: Usuário não encontrado ou curso inválido.</p></div>';
        }
    }
}

// --- B. REVOGAR ACESSO (CORRIGIDO) ---
if (isset($_GET['action']) && $_GET['action'] == 'revoke' && isset($_GET['user']) && isset($_GET['curso'])) {
    
    if (isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'revoke_access')) {
        $r_user_id = intval($_GET['user']);
        $r_curso_id = intval($_GET['curso']);
        
        $cursos_atuais = get_user_meta($r_user_id, '_raz_user_cursos', true);
        
        // Remove do array de cursos
        if (is_array($cursos_atuais)) {
            $pos = array_search($r_curso_id, $cursos_atuais);
            if ($pos !== false) {
                unset($cursos_atuais[$pos]);
                update_user_meta($r_user_id, '_raz_user_cursos', array_values($cursos_atuais));
            }
        }
        
        // Remove metadados específicos
        delete_user_meta($r_user_id, '_raz_curso_acesso_' . $r_curso_id);
        delete_user_meta($r_user_id, '_raz_user_grupos_' . $r_curso_id);
        
        // Força um redirect via JS para limpar a URL e evitar loop ou erro
        echo '<script>window.location.href="' . esc_url($base_url) . '?status=revogado";</script>';
        exit;
    }
}

if (isset($_GET['status']) && $_GET['status'] == 'revogado') {
    $mensagem_feedback = '<div class="notice notice-success is-dismissible" style="margin-left:0; margin-bottom:20px; background:#dcfce7; border:1px solid #22c55e; color:#14532d; padding:10px;"><p>✅ Acesso revogado com sucesso.</p></div>';
}

// ==============================================================================
// 2. PREPARAÇÃO DE DADOS 
// ==============================================================================

$per_page = 10;
$current_page = isset($_GET['pag']) ? max(1, intval($_GET['pag'])) : 1;
$filter_status = isset($_GET['status_filter']) ? sanitize_text_field($_GET['status_filter']) : 'todos'; // Mudei nome para evitar conflito com msg de sucesso
$search_term = isset($_GET['s_acesso']) ? sanitize_text_field($_GET['s_acesso']) : '';
$offset = ($current_page - 1) * $per_page;

$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));

// --- MAPA DE GRUPOS ---
$mapa_cursos_grupos = [];
foreach ($cursos as $curso) {
    $grupos_meta = get_post_meta($curso->ID, '_raz_curso_grupos', true);
    $grupos_meta = maybe_unserialize($grupos_meta);

    if (!empty($grupos_meta) && is_array($grupos_meta)) {
        foreach ($grupos_meta as $key => $data) {
            $nome_grupo = isset($data['nome']) ? $data['nome'] : ucfirst($key);
            $mapa_cursos_grupos[$curso->ID][] = [
                'id' => $key,
                'nome' => $nome_grupo
            ];
        }
    }
}

$all_users = get_users(array('orderby' => 'display_name', 'order' => 'ASC', 'number' => 500));
?>

<style>
    .access-tabs { display: flex; gap: 20px; margin-bottom: 20px; border-bottom: 1px solid #e2e8f0; }
    .access-tab-btn { padding: 10px 16px; cursor: pointer; font-weight: 500; color: var(--muted); border-bottom: 2px solid transparent; transition: all 0.2s; }
    .access-tab-btn.active { color: var(--primary); border-bottom-color: var(--primary); }
    .access-tab-content { display: none; }
    .access-tab-content.active { display: block; }
    
    .search-user-container { padding: 20px 0; }
    .search-results-list { margin-top: 15px; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; max-height: 300px; overflow-y: auto; }
    .search-result-item { padding: 12px 16px; background: #fff; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
    .search-result-item:last-child { border-bottom: none; }
    
    .table-search-form { margin-bottom: 20px; display: flex; gap: 10px; }
    .table-search-input { flex: 1; padding: 10px 14px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 14px; }
    
    .searchable-select { position: relative; }
    .searchable-dropdown { display: none; position: absolute; top: 100%; left: 0; right: 0; background: #fff; border: 1px solid #e2e8f0; border-radius: 6px; z-index: 100; max-height: 200px; overflow-y: auto; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
    .searchable-dropdown.show { display: block; }
    .searchable-option { padding: 10px 12px; cursor: pointer; border-bottom: 1px solid #f1f5f9; }
    .searchable-option:hover { background: #f8fafc; }
</style>

<div class="admin-header">
    <h2>Gerenciar Acessos</h2>
</div>

<?php echo $mensagem_feedback; ?>

<div class="tabs">
    <a href="?status_filter=todos" class="tab <?php echo $filter_status === 'todos' ? 'active' : ''; ?>">Todos</a>
    <a href="?status_filter=ativos" class="tab <?php echo $filter_status === 'ativos' ? 'active' : ''; ?>">Ativos</a>
    <a href="?status_filter=expirados" class="tab <?php echo $filter_status === 'expirados' ? 'active' : ''; ?>">Expirados</a>
</div>

<div class="form-card" style="max-width:700px;margin-bottom:32px;">
    <div class="access-tabs">
        <div class="access-tab-btn active" onclick="switchAccessTab('liberar')">Liberar Acesso</div>
        <div class="access-tab-btn" onclick="switchAccessTab('pesquisar')">Pesquisar Usuário</div>
    </div>

    <div id="tab-liberar" class="access-tab-content active">
        <h3 style="margin-bottom:20px;">Liberar Acesso Manual</h3>
        
        <form id="form-acesso-manual" method="POST" action="">
            <input type="hidden" name="raz_action" value="add_access_manual">
            <?php wp_nonce_field('raz_grant_access_manual'); ?>

            <div class="form-row">
                <div class="form-group">
                    <label>Aluno *</label>
                    <div class="searchable-select">
                        <input type="text" id="user-search" placeholder="Digite para buscar por email..." autocomplete="off" required>
                        <input type="hidden" name="user_email" id="user_email_input">
                        <div class="searchable-dropdown" id="user-dropdown"></div>
                    </div>
                </div>
                <div class="form-group">
                    <label>Curso *</label>
                    <select name="curso_id" id="select-curso-manual" required onchange="renderizarGruposManual(this.value)">
                        <option value="">Selecione...</option>
                        <?php foreach ($cursos as $c) : ?>
                            <option value="<?php echo $c->ID; ?>"><?php echo esc_html($c->post_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div id="container-grupos-manual" style="margin-bottom: 20px; padding: 15px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; display:none;">
                <label style="font-size:12px; font-weight:700; color:#475569; display:block; margin-bottom:10px;">Selecione os Grupos de Acesso (Opcional):</label>
                <div id="lista-grupos-checkboxes" style="display:flex; flex-direction:column; gap:4px;"></div>
            </div>

            <div class="form-row">
                <div class="form-group" id="group-dias">
                    <label>Dias de Acesso</label>
                    <input type="number" name="dias" id="input-dias" value="365" min="1">
                </div>

                <div class="form-group">
                    <label>Tipo de Acesso</label>
                    <select name="tipo" id="input-tipo" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;background:#fff;">
                        <option value="avulso">Avulso (Dias Corridos)</option>
                        <option value="vitalicio">Vitalício</option>
                        <option value="assinatura">Assinatura (Recorrente)</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Liberar Acesso</button>
        </form>
    </div>

    <div id="tab-pesquisar" class="access-tab-content">
        <h3 style="margin-bottom:20px;">Pesquisar Usuário</h3>
        <div class="search-user-container">
            <div class="form-group">
                <label>E-mail do Usuário</label>
                <input type="text" id="global-user-search" placeholder="Digite o e-mail para buscar..." style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
            </div>
            <div id="global-search-results" class="search-results-list" style="display:none;"></div>
        </div>
    </div>
</div>

<h3 style="margin-bottom:16px;">Lista de Acessos</h3>

<form method="get" class="table-search-form" action="">
    <input type="hidden" name="status_filter" value="<?php echo esc_attr($filter_status); ?>">
    <input type="text" name="s_acesso" class="table-search-input" placeholder="Pesquisar aluno por nome ou e-mail na tabela..." value="<?php echo esc_attr($search_term); ?>">
    <button type="submit" class="btn btn-secondary">Pesquisar</button>
    <?php if ($search_term) : ?>
        <a href="?status_filter=<?php echo $filter_status; ?>" class="btn btn-sm" style="display:flex; align-items:center; color:var(--muted);">Limpar</a>
    <?php endif; ?>
</form>

<?php
// Buscar acessos
global $wpdb;
$acessos_raw = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%' ORDER BY umeta_id DESC LIMIT 500");

$acessos_filtered = array();
foreach ($acessos_raw as $a) {
    $uid = $a->user_id;
    $cid = str_replace('_raz_curso_acesso_', '', $a->meta_key);
    $data = maybe_unserialize($a->meta_value);
    $u = get_userdata($uid);
    $c = get_post($cid);
    if (!$u || !$c) continue;

    if ($search_term) {
        $found_name = stripos($u->display_name, $search_term) !== false;
        $found_email = stripos($u->user_email, $search_term) !== false;
        if (!$found_name && !$found_email) continue;
    }

    $ativo = raz_lms_user_has_access($uid, $cid);

    if ($filter_status === 'ativos' && !$ativo) continue;
    if ($filter_status === 'expirados' && $ativo) continue;

    $acessos_filtered[] = array(
        'user' => $u,
        'curso' => $c,
        'data' => $data,
        'ativo' => $ativo
    );
}

$total_acessos = count($acessos_filtered);
$total_pages = ceil($total_acessos / $per_page);
$acessos_page = array_slice($acessos_filtered, $offset, $per_page);
?>

<?php if (empty($acessos_page)) : ?>
    <div class="empty-state">
        <h3>Nenhum acesso encontrado.</h3>
    </div>
<?php else : ?>
    <table class="data-table">
        <thead>
            <tr>
                <th>Aluno</th>
                <th>Curso</th>
                <th>Início</th>
                <th>Expiração / Tipo</th>
                <th>Status</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($acessos_page as $acesso) :
                $u = $acesso['user'];
                $c = $acesso['curso'];
                $data = $acesso['data'];
                $ativo = $acesso['ativo'];

                $tipo_label = 'Avulso';
                $is_vitalicio = isset($data['vitalicio']) && $data['vitalicio'];
                $is_assinatura = isset($data['tipo']) && $data['tipo'] === 'assinatura';

                if ($is_vitalicio) $tipo_label = 'Vitalício';
                elseif ($is_assinatura) $tipo_label = 'Assinatura';
            ?>
                <tr>
                    <td>
                        <strong><?php echo esc_html($u->display_name); ?></strong>
                        <br><small style="color:var(--muted);"><?php echo esc_html($u->user_email); ?></small>
                    </td>
                    <td>
                        <strong><?php echo esc_html($c->post_title); ?></strong>
                        <?php 
                        $grupos_aluno_keys = get_user_meta($u->ID, '_raz_user_grupos_' . $c->ID, true);
                        $todos_grupos_curso = get_post_meta($c->ID, '_raz_curso_grupos', true);
                        $todos_grupos_curso = maybe_unserialize($todos_grupos_curso);

                        if (!empty($grupos_aluno_keys) && is_array($grupos_aluno_keys) && !empty($todos_grupos_curso)) {
                            $nomes_grupos = [];
                            foreach ($grupos_aluno_keys as $key) {
                                if (isset($todos_grupos_curso[$key]) && isset($todos_grupos_curso[$key]['nome'])) {
                                    $nomes_grupos[] = $todos_grupos_curso[$key]['nome'];
                                } elseif ($key === 'padrao') {
                                    $nomes_grupos[] = 'Padrão';
                                }
                            }
                            if (!empty($nomes_grupos)) {
                                echo '<div style="margin-top:4px; font-size:11px; color:#64748b; line-height:1.2;">';
                                echo '<span style="font-weight:600;">Grupos:</span> ' . implode(', ', $nomes_grupos);
                                echo '</div>';
                            }
                        }
                        ?>
                    </td>
                    <td style="color:var(--muted);"><?php echo isset($data['inicio']) ? date_i18n('d/m/Y', strtotime($data['inicio'])) : '-'; ?></td>
                    <td>
                        <?php if ($is_vitalicio) : ?>
                            <span class="badge badge-success">Vitalício</span>
                        <?php elseif ($is_assinatura) : ?>
                            <span class="badge" style="background:#e0f2fe;color:#0284c7;border:1px solid #bae6fd;">Assinatura</span>
                            <div style="font-size:11px;color:var(--muted);margin-top:2px;">Renova: <?php echo isset($data['expiracao']) ? date_i18n('d/m/Y', strtotime($data['expiracao'])) : '-'; ?></div>
                        <?php else : ?>
                            <?php echo isset($data['expiracao']) ? date_i18n('d/m/Y', strtotime($data['expiracao'])) : '-'; ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge <?php echo $ativo ? 'badge-success' : 'badge-danger'; ?>">
                            <?php echo $ativo ? 'Ativo' : 'Expirado'; ?>
                        </span>
                    </td>
                    <td>
                        <?php 
                        // Gera URL segura baseada na página atual
                        $revoke_url = add_query_arg([
                            'action' => 'revoke',
                            'user' => $u->ID,
                            'curso' => $c->ID,
                            '_wpnonce' => wp_create_nonce('revoke_access')
                        ]);
                        ?>
                        <a href="<?php echo esc_url($revoke_url); ?>" 
                           class="btn btn-sm btn-danger"
                           onclick="return confirm('Tem certeza que deseja revogar o acesso deste aluno?');"
                           style="color:white; text-decoration:none;">
                           Revogar
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if ($total_pages > 1) : ?>
        <div class="pagination">
            <?php if ($current_page > 1) : ?>
                <a href="?pag=<?php echo $current_page - 1; ?>&status_filter=<?php echo $filter_status; ?>&s_acesso=<?php echo $search_term; ?>" class="btn btn-sm btn-secondary">← Anterior</a>
            <?php endif; ?>

            <span class="pagination-info">Página <?php echo $current_page; ?> de <?php echo $total_pages; ?></span>

            <?php if ($current_page < $total_pages) : ?>
                <a href="?pag=<?php echo $current_page + 1; ?>&status_filter=<?php echo $filter_status; ?>&s_acesso=<?php echo $search_term; ?>" class="btn btn-sm btn-secondary">Próxima →</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<script>
    // Dados PHP -> JS
    var mapaCursosGrupos = <?php echo json_encode($mapa_cursos_grupos); ?>;
    var allUsers = <?php echo json_encode(array_map(function($u) {
        return array('id' => $u->ID, 'name' => $u->display_name, 'email' => $u->user_email);
    }, $all_users)); ?>;

    function renderizarGruposManual(cursoId) {
        var container = document.getElementById('container-grupos-manual');
        var lista = document.getElementById('lista-grupos-checkboxes');
        lista.innerHTML = '';

        if (!cursoId || !mapaCursosGrupos || !mapaCursosGrupos[cursoId]) {
            container.style.display = 'none';
            return;
        }

        container.style.display = 'block';

        mapaCursosGrupos[cursoId].forEach(function(grupo) {
            var wrapper = document.createElement('div');
            wrapper.style.display = 'flex';
            wrapper.style.alignItems = 'center';
            wrapper.style.gap = '10px';
            wrapper.style.padding = '6px 0';

            var checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.name = 'grupos_selecionados[]'; 
            checkbox.value = grupo.id;
            checkbox.id = 'grupo_manual_' + grupo.id;
            checkbox.checked = true;
            
            checkbox.style.width = '18px';
            checkbox.style.height = '18px';
            checkbox.style.flexShrink = '0';
            checkbox.style.margin = '0';
            checkbox.style.cursor = 'pointer';
            checkbox.style.accentColor = 'var(--primary)';

            var label = document.createElement('label');
            label.htmlFor = 'grupo_manual_' + grupo.id;
            label.innerText = grupo.nome;
            label.style.fontSize = '14px';
            label.style.color = '#1e293b';
            label.style.lineHeight = '1.3';
            label.style.cursor = 'pointer';

            wrapper.appendChild(checkbox);
            wrapper.appendChild(label);
            lista.appendChild(wrapper);
        });
    }

    function switchAccessTab(tab) {
        document.querySelectorAll('.access-tab-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.access-tab-content').forEach(content => content.classList.remove('active'));

        if (tab === 'liberar') {
            document.querySelector('.access-tab-btn:nth-child(1)').classList.add('active');
            document.getElementById('tab-liberar').classList.add('active');
        } else {
            document.querySelector('.access-tab-btn:nth-child(2)').classList.add('active');
            document.getElementById('tab-pesquisar').classList.add('active');
        }
    }

    var userSearch = document.getElementById('user-search');
    var userDropdown = document.getElementById('user-dropdown');
    var userEmailInput = document.getElementById('user_email_input');

    if(userSearch) {
        userSearch.addEventListener('focus', function() { showUserDropdown(''); });
        userSearch.addEventListener('input', function() { showUserDropdown(this.value.toLowerCase()); });
    }

    var globalUserSearch = document.getElementById('global-user-search');
    var globalSearchResults = document.getElementById('global-search-results');

    if(globalUserSearch) {
        globalUserSearch.addEventListener('input', function() {
            var filter = this.value.toLowerCase();
            if (filter.length < 2) {
                globalSearchResults.style.display = 'none';
                return;
            }
            var html = '';
            var found = 0;
            allUsers.forEach(function(u) {
                if (found >= 10) return;
                if (u.email.toLowerCase().includes(filter) || u.name.toLowerCase().includes(filter)) {
                    html += '<div class="search-result-item">';
                    html += '<div><strong>' + escapeHtml(u.name) + '</strong><br><small>' + escapeHtml(u.email) + '</small></div>';
                    html += '<button type="button" class="btn btn-sm btn-secondary" onclick="selectUserForGrant(\'' + escapeHtml(u.email) + '\', \'' + escapeHtml(u.name) + '\')">Selecionar</button>';
                    html += '</div>';
                    found++;
                }
            });
            if (html) {
                globalSearchResults.innerHTML = html;
                globalSearchResults.style.display = 'block';
            } else {
                globalSearchResults.innerHTML = '<div style="padding:15px;text-align:center;color:var(--muted);">Nenhum usuário encontrado</div>';
                globalSearchResults.style.display = 'block';
            }
        });
    }

    function selectUserForGrant(email, name) {
        selectUser(email, name);
        switchAccessTab('liberar');
        globalUserSearch.value = '';
        globalSearchResults.style.display = 'none';
    }

    document.addEventListener('click', function(e) {
        if (!e.target.closest('.searchable-select')) {
            if(userDropdown) userDropdown.classList.remove('show');
        }
    });

    function showUserDropdown(filter) {
        if(!userDropdown) return;
        var html = '';
        var count = 0;
        allUsers.forEach(function(u) {
            if (count >= 50) return;
            if (filter && !u.email.toLowerCase().includes(filter) && !u.name.toLowerCase().includes(filter)) return;
            html += '<div class="searchable-option" onclick="selectUser(\'' + escapeHtml(u.email) + '\', \'' + escapeHtml(u.name) + '\')">' + escapeHtml(u.name) + ' <small style="color:var(--muted);">(' + escapeHtml(u.email) + ')</small></div>';
            count++;
        });
        if (!html) html = '<div style="padding:10px 16px;color:var(--muted);">Nenhum usuário encontrado</div>';
        userDropdown.innerHTML = html;
        userDropdown.classList.add('show');
    }

    function selectUser(email, name) {
        if(userEmailInput) userEmailInput.value = email;
        if(userSearch) userSearch.value = name + ' (' + email + ')';
        if(userDropdown) userDropdown.classList.remove('show');
    }

    function escapeHtml(str) {
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    var inputTipo = document.getElementById('input-tipo');
    var groupDias = document.getElementById('group-dias');

    if (inputTipo) {
        inputTipo.addEventListener('change', function() {
            if (this.value === 'vitalicio') {
                groupDias.style.display = 'none';
            } else {
                groupDias.style.display = 'block';
            }
        });
    }
</script>