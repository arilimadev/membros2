<?php
/**
 * Header Template
 * @package RazMidiasLMS
 */

// Define cor padr���o para bot���es no header p���blico
$header_btn_color = '#667eea'; 
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php 
/* L���GICA DE EXIBI������O DOS CABE���ALHOS */

if ( is_singular('aula') ) {
    // Cen���rio 1: Player de Aula -> Sem header global
    
} elseif ( is_page_template('page-meus-cursos.php') || is_singular('curso') ) {
    // Cen���rio 2: HEADER DO ALUNO (DASHBOARD)
    $user = wp_get_current_user();
?>
    <div class="raz-dashboard-header">
        <div class="raz-dashboard-header-content">
            <div class="raz-dashboard-logo">
                <?php
                if (has_custom_logo()) {
                    the_custom_logo();
                } else {
                    echo '<a href="' . home_url() . '" class="site-title-link">' . get_bloginfo('name') . '</a>';
                }
                ?>
            </div>

            <button class="raz-menu-toggle" onclick="toggleDashboardMenu()" aria-label="Abrir menu">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
            </button>

            <div class="raz-dashboard-user-wrapper" id="dashboard-menu">
                <div class="raz-dashboard-user-info">
                    <div class="raz-user-details">
                        <span class="raz-user-name"><?php echo esc_html($user->display_name); ?></span>
                        <span class="raz-user-email"><?php echo esc_html($user->user_email); ?></span>
                    </div>
                </div>
                
                <nav class="raz-dashboard-nav">
                    <a href="<?php echo home_url('/meus-cursos'); ?>" class="raz-nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
                        Meus Cursos
                    </a>
                    
                    <a href="<?php echo wp_logout_url(home_url()); ?>" class="raz-logout-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                        Sair
                    </a>
                </nav>
            </div>
        </div>
    </div>

    <script>
        function toggleDashboardMenu() {
            var menu = document.getElementById('dashboard-menu');
            if(menu) menu.classList.toggle('open');
        }
        // Fechar ao clicar fora
        document.addEventListener('click', function(event) {
            var menu = document.getElementById('dashboard-menu');
            var toggle = document.querySelector('.raz-menu-toggle');
            if (menu && menu.classList.contains('open') && !menu.contains(event.target) && !toggle.contains(event.target)) {
                menu.classList.remove('open');
            }
        });
    </script>

    <style>
        /* GERAL */
        .raz-dashboard-header {
            background: #fff;
            border-bottom: 1px solid var(--border);
            padding: 0;
            position: sticky;
            top: 0;
            z-index: 999;
        }

        .raz-dashboard-header-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 70px;
            position: relative;
        }

        .site-title-link {
            font-weight: 700;
            font-size: 1.5rem;
            color: #000 !important;
            text-decoration: none;
            white-space: nowrap;
        }

        .raz-menu-toggle {
            display: none;
            background: none;
            border: none;
            color: #000;
            cursor: pointer;
            padding: 8px;
            margin-right: -8px;
        }

        .raz-dashboard-user-wrapper {
            display: flex;
            align-items: center;
            gap: 24px;
        }

        .raz-dashboard-user-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .raz-user-details {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            line-height: 1.3;
        }

        .raz-user-name {
            font-weight: 600;
            color: #000;
            font-size: 14px;
        }

        .raz-user-email {
            font-size: 11px;
            color: #94a3b8;
            font-weight: 400;
        }

        .raz-dashboard-nav {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .raz-nav-link, .raz-logout-btn {
            display: flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            color: var(--text-secondary);
            transition: all 0.2s;
        }

        /* DESKTOP: Bot���o Azul */
        @media (min-width: 769px) {
            .raz-nav-link {
                background-color: var(--primary, #0891b2);
                color: #fff !important;
                padding: 8px 16px;
                border-radius: 6px;
            }
            .raz-nav-link svg { color: #fff; }
            .raz-nav-link:hover {
                background-color: #0e7490;
                transform: translateY(-1px);
            }
        }

        .raz-logout-btn { color: #ef4444; }
        .raz-logout-btn:hover { color: #dc2626; }

        /* MOBILE: Menu Full Width */
        @media (max-width: 768px) {
            .site-title-link { font-size: 1.15rem; }
            .raz-menu-toggle { display: block; }
            
            .raz-dashboard-user-wrapper {
                display: none;
                position: absolute;
                top: 70px; /* Altura exata do header */
                left: 0;
                right: 0; /* Garante largura total */
                width: 100%; /* For���a 100% */
                background: #fff;
                border-bottom: 1px solid var(--border);
                box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
                flex-direction: column;
                align-items: stretch;
                padding: 20px; /* Espa���amento interno */
                gap: 16px;
                z-index: 1000;
            }

            .raz-dashboard-user-wrapper.open {
                display: flex;
                animation: fadeInMenu 0.2s ease-out;
            }

            @keyframes fadeInMenu {
                from { opacity: 0; transform: translateY(-10px); }
                to { opacity: 1; transform: translateY(0); }
            }

            .raz-dashboard-user-info {
                padding-bottom: 16px;
                border-bottom: 1px solid var(--border);
                margin-bottom: 4px;
                display: block;
                width: 100%;
            }

            .raz-dashboard-nav {
                flex-direction: column;
                align-items: stretch;
                gap: 10px;
                width: 100%;
            }

            .raz-nav-link, .raz-logout-btn {
                padding: 12px;
                border-radius: 6px;
                background: var(--bg-card, #f8fafc);
                color: var(--text-secondary) !important;
                width: 100%; /* Bot���es ocupam largura total */
            }
            
            .raz-nav-link svg { color: currentColor; }
            
            .raz-nav-link:hover, .raz-logout-btn:hover {
                background: #f1f5f9;
            }
        }
    </style>

<?php 
} else { 
    // Cen���rio 3: HEADER PADR���O (SITE P���BLICO)
?>
    <header class="raz-site-header">
        <div class="raz-header-content">
            <div class="raz-header-logo">
                <?php if (has_custom_logo()) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
                <?php endif; ?>
            </div>
            
            <?php if (has_nav_menu('primary')) : ?>
            <nav class="raz-header-nav">
                <?php wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'container' => false,
                    'menu_class' => 'raz-menu',
                )); ?>
            </nav>
            <?php endif; ?>
            
            <div class="raz-header-actions">
                <?php if (is_user_logged_in()) : ?>
                    <a href="<?php echo esc_url(home_url('/meus-cursos/')); ?>" class="raz-header-btn raz-btn-dynamic" style="background:<?php echo esc_attr($header_btn_color); ?>;">Meus Cursos</a>
                    <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="raz-header-btn-outline">Sair</a>
                <?php else : ?>
                    <a href="<?php echo esc_url(wp_login_url()); ?>" class="raz-header-btn raz-btn-dynamic" style="background:<?php echo esc_attr($header_btn_color); ?>;">Entrar</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
<?php 
} 
?>