<?php
/**
 * Admin Dashboard - Premium UX/UI
 */
global $wpdb;

$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'date', 'order' => 'DESC'));
$total_cursos = count($cursos);
$total_modulos = wp_count_posts('modulo')->publish;
$total_aulas = wp_count_posts('aula')->publish;

/**
 * CORREÇÃO: Contagem de alunos
 * Busca todos os usuários cadastrados, excluindo o administrador (ID 1)
 */
$total_alunos = $wpdb->get_var("
    SELECT COUNT(ID) 
    FROM {$wpdb->users} 
    WHERE ID != 1
");

// Alunos com acesso expirando nos próximos 7 dias
$expirando_soon = array();
$all_acessos = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%'");
foreach ($all_acessos as $acesso) {
    $data = maybe_unserialize($acesso->meta_value);
    if (isset($data['vitalicio']) && $data['vitalicio']) {
        continue;
    }
    if (isset($data['expiracao'])) {
        $exp_date = strtotime($data['expiracao']);
        $now = time();
        $diff_days = ($exp_date - $now) / (60 * 60 * 24);
        if ($diff_days > 0 && $diff_days <= 7) {
            $user = get_userdata($acesso->user_id);
            $curso_id = str_replace('_raz_curso_acesso_', '', $acesso->meta_key);
            $curso = get_post($curso_id);
            if ($user && $curso) {
                $expirando_soon[] = array(
                    'user' => $user,
                    'curso' => $curso,
                    'dias' => ceil($diff_days),
                    'expiracao' => $data['expiracao']
                );
            }
        }
    }
}

// Últimas matrículas (apenas as últimas 5)
$ultimas_matriculas = array();
$recent_acessos = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%' ORDER BY umeta_id DESC LIMIT 5");
foreach ($recent_acessos as $acesso) {
    $data = maybe_unserialize($acesso->meta_value);
    $user = get_userdata($acesso->user_id);
    $curso_id = str_replace('_raz_curso_acesso_', '', $acesso->meta_key);
    $curso = get_post($curso_id);
    if ($user && $curso) {
        $ultimas_matriculas[] = array(
            'user' => $user,
            'curso' => $curso,
            'data' => isset($data['inicio']) ? $data['inicio'] : ''
        );
    }
}

/**
 * CORREÇÃO: Dados para gráfico
 * Filtra apenas a primeira matrícula de cada aluno para evitar duplicidade no gráfico diário
 */
$chart_data = array();
for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $chart_data[$date] = 0;
}

$processed_users = array();
// Ordena por ID do metadado para pegar a primeira inserção (matrícula original)
$all_acessos_ordered = $wpdb->get_results("SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%' ORDER BY umeta_id ASC");

foreach ($all_acessos_ordered as $acesso) {
    // Se o aluno já foi contado em algum dia, ignora as outras matrículas dele
    if (in_array($acesso->user_id, $processed_users)) {
        continue;
    }

    $data = maybe_unserialize($acesso->meta_value);
    if (isset($data['inicio'])) {
        $data_inicio = date('Y-m-d', strtotime($data['inicio']));
        if (isset($chart_data[$data_inicio])) {
            $chart_data[$data_inicio]++;
            $processed_users[] = $acesso->user_id;
        }
    }
}

// Cursos mais populares
$cursos_populares = array();
foreach ($cursos as $curso) {
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s",
        '_raz_curso_acesso_' . $curso->ID
    ));
    $cursos_populares[] = array('curso' => $curso, 'alunos' => intval($count));
}
usort($cursos_populares, function ($a, $b) {
    return $b['alunos'] - $a['alunos'];
});
$cursos_populares = array_slice($cursos_populares, 0, 5);
?>

<style>
    :root {
        --raz-primary: #0891b2;
        --raz-primary-hover: #0e7490;
        --raz-bg: #f8fafc;
        --raz-surface: #ffffff;
        --raz-border: #e2e8f0;
        --raz-text: #1e293b;
        --raz-text-muted: #64748b;
        --raz-text-light: #94a3b8;
        --raz-success-bg: #ecfdf5;
        --raz-success-text: #059669;
        --raz-warning-bg: #fffbeb;
        --raz-warning-text: #d97706;
        --raz-radius: 8px;
        --raz-radius-lg: 12px;
        --raz-shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        --raz-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .raz-admin-container {
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        color: var(--raz-text);
        max-width: 1200px;
        margin: 20px auto 60px;
    }

    /* Headings */
    .raz-page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 32px;
        padding-bottom: 20px;
        border-bottom: 1px solid var(--raz-border);
    }
    .raz-page-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--raz-text);
        margin: 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .raz-page-title svg { color: var(--raz-primary); }

    /* Stats Grid */
    .raz-stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
        margin-bottom: 32px;
    }
    
    .raz-stat-card {
        background: var(--raz-surface);
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        padding: 24px;
        display: flex;
        flex-direction: column;
        transition: var(--transition);
        position: relative;
        overflow: hidden;
    }
    .raz-stat-card:hover { transform: translateY(-2px); box-shadow: var(--raz-shadow); }
    
    .raz-stat-label { font-size: 13px; font-weight: 600; color: var(--raz-text-muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px; }
    .raz-stat-value { font-size: 32px; font-weight: 800; color: var(--raz-text); line-height: 1.2; }
    .raz-stat-icon {
        position: absolute; right: 20px; top: 20px;
        width: 48px; height: 48px;
        color: #f1f5f9;
        pointer-events: none;
    }

    /* Cards Layout */
    .raz-card {
        background: var(--raz-surface);
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        padding: 24px;
        box-shadow: var(--raz-shadow-sm);
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .raz-card-header {
        display: flex; justify-content: space-between; align-items: center;
        margin-bottom: 20px; padding-bottom: 12px;
        border-bottom: 1px solid #f1f5f9;
    }
    .raz-card-title { font-size: 16px; font-weight: 700; color: var(--raz-text); display: flex; align-items: center; gap: 8px; margin: 0; }
    .raz-card-link { font-size: 13px; color: var(--raz-primary); text-decoration: none; font-weight: 500; }
    .raz-card-link:hover { text-decoration: underline; }

    /* Alert Box */
    .raz-alert-box {
        background: #fffbeb;
        border: 1px solid #fcd34d;
        border-radius: var(--raz-radius-lg);
        padding: 20px;
        margin-bottom: 32px;
    }
    .raz-alert-header { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; color: #b45309; font-weight: 700; font-size: 15px; }
    .raz-alert-grid { display: flex; flex-wrap: wrap; gap: 12px; }
    .raz-alert-item {
        background: white; padding: 10px 14px;
        border-radius: 8px; border: 1px solid #fde68a;
        font-size: 13px; color: #92400e;
        display: flex; align-items: center; gap: 8px;
        text-decoration: none; transition: var(--transition);
    }
    .raz-alert-item:hover { transform: translateY(-1px); box-shadow: 0 2px 4px rgba(0,0,0,0.05); }

    /* Lists */
    .raz-list { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 12px; }
    .raz-list-item {
        display: flex; align-items: center; justify-content: space-between;
        padding: 12px; background: #f8fafc;
        border-radius: 8px; transition: var(--transition);
    }
    .raz-list-item:hover { background: #f1f5f9; }
    
    .raz-rank-badge {
        width: 24px; height: 24px;
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 12px; font-weight: 700;
        margin-right: 12px;
    }
    .rank-1 { background: #fbbf24; color: white; }
    .rank-2 { background: #94a3b8; color: white; }
    .rank-3 { background: #d97706; color: white; }
    .rank-other { background: #e2e8f0; color: #64748b; }

    /* Buttons */
    .raz-btn {
        display: inline-flex; align-items: center; justify-content: center;
        padding: 10px 20px; font-size: 14px; font-weight: 600;
        border-radius: var(--raz-radius); cursor: pointer;
        border: 1px solid transparent; transition: var(--transition);
        text-decoration: none; gap: 8px;
    }
    .raz-btn-primary { background: var(--raz-primary); color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1); }
    .raz-btn-primary:hover { background: var(--raz-primary-hover); transform: translateY(-1px); }
    
    .raz-btn-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 16px; }
    .raz-action-card {
        padding: 16px; background: #fff; border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius); text-align: left;
        color: var(--raz-text); font-weight: 600; font-size: 14px;
        display: flex; flex-direction: column; gap: 8px;
        text-decoration: none; transition: var(--transition);
    }
    .raz-action-card svg { color: var(--raz-primary); width: 24px; height: 24px; }
    .raz-action-card:hover { border-color: var(--raz-primary); background: #f0f9ff; transform: translateY(-2px); box-shadow: var(--raz-shadow-sm); }

    /* Layout Grids */
    .raz-main-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 24px; margin-bottom: 32px; }
    .raz-secondary-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }

    @media (max-width: 900px) {
        .raz-main-grid, .raz-secondary-grid { grid-template-columns: 1fr; }
    }
</style>

<div class="raz-admin-container">
    
    <div class="raz-page-header">
        <h2 class="raz-page-title">
            <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
            Painel Administrativo
        </h2>
        <a href="<?php echo home_url('/gestao-cursos/curso-editar'); ?>" class="raz-btn raz-btn-primary">
            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
            Novo Curso
        </a>
    </div>

    <div class="raz-stats-grid">
        <div class="raz-stat-card">
            <div class="raz-stat-label">Cursos Ativos</div>
            <div class="raz-stat-value"><?php echo $total_cursos; ?></div>
            <svg class="raz-stat-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
        </div>
        <div class="raz-stat-card">
            <div class="raz-stat-label">Módulos</div>
            <div class="raz-stat-value"><?php echo $total_modulos; ?></div>
            <svg class="raz-stat-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
        </div>
        <div class="raz-stat-card">
            <div class="raz-stat-label">Aulas</div>
            <div class="raz-stat-value"><?php echo $total_aulas; ?></div>
            <svg class="raz-stat-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        </div>
        <div class="raz-stat-card">
            <div class="raz-stat-label">Alunos</div>
            <div class="raz-stat-value"><?php echo $total_alunos ?: 0; ?></div>
            <svg class="raz-stat-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
        </div>
    </div>

    <?php if (!empty($expirando_soon)) : ?>
        <div class="raz-alert-box">
            <div class="raz-alert-header">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                ⚠️ <?php echo count($expirando_soon); ?> aluno(s) com acesso expirando em até 7 dias
            </div>
            <div class="raz-alert-grid">
                <?php foreach (array_slice($expirando_soon, 0, 5) as $item) : ?>
                    <a href="<?php echo home_url('/gestao-cursos/alunos/?s=' . urlencode($item['user']->user_email)); ?>" class="raz-alert-item">
                        <strong><?php echo esc_html($item['user']->display_name); ?></strong>
                        <span style="opacity:0.8;">• <?php echo esc_html($item['curso']->post_title); ?></span>
                        <span style="font-weight:700;">(<?php echo $item['dias']; ?> dias)</span>
                    </a>
                <?php endforeach; ?>
                <?php if (count($expirando_soon) > 5) : ?>
                    <a href="<?php echo home_url('/gestao-cursos/acessos?status=ativos'); ?>" class="raz-alert-item" style="background:#fef3c7;">
                        +<?php echo count($expirando_soon) - 5; ?> ver todos
                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="raz-main-grid">
        <div class="raz-card">
            <div class="raz-card-header">
                <h3 class="raz-card-title">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>
                    Novas Matrículas (30 dias)
                </h3>
            </div>
            <div style="height:250px; position:relative; width:100%;">
                <canvas id="chart-alunos"></canvas>
            </div>
        </div>

        <div class="raz-card">
            <div class="raz-card-header">
                <h3 class="raz-card-title">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path></svg>
                    Cursos Populares
                </h3>
            </div>
            <?php if (empty($cursos_populares)) : ?>
                <p style="color:var(--raz-text-muted); text-align:center; padding:20px;">Nenhum dado ainda.</p>
            <?php else : ?>
                <ul class="raz-list">
                    <?php foreach ($cursos_populares as $index => $item) : 
                        $rank_class = $index === 0 ? 'rank-1' : ($index === 1 ? 'rank-2' : ($index === 2 ? 'rank-3' : 'rank-other'));
                    ?>
                        <li class="raz-list-item">
                            <div style="display:flex; align-items:center;">
                                <div class="raz-rank-badge <?php echo $rank_class; ?>"><?php echo $index + 1; ?></div>
                                <div style="font-weight:600; font-size:14px;"><?php echo esc_html($item['curso']->post_title); ?></div>
                            </div>
                            <div style="font-size:12px; font-weight:600; color:var(--raz-text-muted);"><?php echo $item['alunos']; ?> alunos</div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

    <div class="raz-secondary-grid">
        <div class="raz-card">
            <div class="raz-card-header">
                <h3 class="raz-card-title">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Últimas Matrículas
                </h3>
                <a href="<?php echo home_url('/gestao-cursos/acessos'); ?>" class="raz-card-link">Ver todas →</a>
            </div>
            <?php if (empty($ultimas_matriculas)) : ?>
                <p style="color:var(--raz-text-muted); text-align:center;">Nenhuma matrícula recente.</p>
            <?php else : ?>
                <ul class="raz-list">
                    <?php foreach ($ultimas_matriculas as $item) : ?>
                        <li class="raz-list-item">
                            <div>
                                <div style="font-weight:600; font-size:14px;"><?php echo esc_html($item['user']->display_name); ?></div>
                                <div style="font-size:12px; color:var(--raz-text-muted);"><?php echo esc_html($item['curso']->post_title); ?></div>
                            </div>
                            <div style="font-size:11px; color:var(--raz-text-light);">
                                <?php echo $item['data'] ? date_i18n('d/m', strtotime($item['data'])) : '-'; ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>

        <div class="raz-card">
            <div class="raz-card-header">
                <h3 class="raz-card-title">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                    Ações Rápidas
                </h3>
            </div>
            <div class="raz-btn-grid">
                <a href="<?php echo home_url('/gestao-cursos/curso-editar'); ?>" class="raz-action-card">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>
                    Criar Curso
                </a>
                <a href="<?php echo home_url('/gestao-cursos/acessos'); ?>" class="raz-action-card">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11.536 11l-2.414 4.145A2 2 0 017.382 16H6a2 2 0 01-2-2v-1.382a2 2 0 01.553-1.447l4.145-2.414L9 6.257A6 6 0 1115 7z"></path></svg>
                    Liberar Acesso
                </a>
                <a href="<?php echo home_url('/gestao-cursos/relatorios'); ?>" class="raz-action-card">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                    Relatórios
                </a>
                <a href="<?php echo home_url('/gestao-cursos/emails'); ?>" class="raz-action-card">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                    E-mails
                </a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var ctx = document.getElementById('chart-alunos');
        if (!ctx) return;

        var chartData = <?php echo json_encode(array_values($chart_data)); ?>;
        var chartLabels = <?php echo json_encode(array_map(function($d) {
                                return date_i18n('d/m', strtotime($d));
                            }, array_keys($chart_data))); ?>;

        new Chart(ctx.getContext('2d'), {
            type: 'line',
            data: {
                labels: chartLabels,
                datasets: [{
                    label: 'Novos Alunos',
                    data: chartData,
                    borderColor: '#0891b2', // Cor primária (Cyan-600)
                    backgroundColor: 'rgba(8, 145, 178, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 2,
                    pointHoverRadius: 5,
                    pointBackgroundColor: '#fff',
                    pointBorderColor: '#0891b2'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false, // Importante para caber no card
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#1e293b',
                        padding: 12,
                        cornerRadius: 8,
                        titleFont: { size: 13 },
                        bodyFont: { size: 13, weight: 'bold' }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { borderDash: [2, 4], color: '#f1f5f9' },
                        ticks: { stepSize: 1, font: { size: 11 } },
                        border: { display: false }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { font: { size: 11 }, maxTicksLimit: 10 }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index',
                },
            }
        });
    });
</script>