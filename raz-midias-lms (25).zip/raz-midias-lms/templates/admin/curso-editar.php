<?php
/**
 * Admin: Editar Curso
 *
 * Estrutura:
 * - Edição de Curso
 * - Listagem de Módulos e Aulas
 * - Aba Grupos separada
 * - Configurações
 *
 * @package RazMidiasLMS
 * @version 5.4.0
 */

defined('ABSPATH') || exit;

// 1. Inicialização de Dados
$curso_id = isset($raz_item_id) ? intval($raz_item_id) : 0;
$curso = $curso_id ? get_post($curso_id) : null;

// Garante que a biblioteca de mídia esteja carregada
if (function_exists('wp_enqueue_media')) {
    wp_enqueue_media();
}

// Validação de segurança básica
if ($curso_id && (!$curso || $curso->post_type !== 'curso')) {
    echo '<div class="raz-admin-container"><div class="notice notice-error"><p>Curso não encontrado.</p></div></div>';
    return;
}

// Metas do Curso
$modulos = $curso_id ? raz_lms_get_modulos($curso_id) : array();
$kiwify_id = $curso_id ? get_post_meta($curso_id, '_raz_curso_kiwify_id', true) : '';
$dias_acesso = $curso_id ? (get_post_meta($curso_id, '_raz_curso_dias_acesso', true) ?: 365) : 365;
$vitalicio = $curso_id ? get_post_meta($curso_id, '_raz_curso_vitalicio', true) : '';
$tipo_acesso = $curso_id ? (get_post_meta($curso_id, '_raz_curso_tipo', true) ?: 'avulso') : 'avulso';

// Se vitalicio estava setado no modelo antigo, força tipo visual
if ($vitalicio) {
    $tipo_acesso = 'vitalicio';
}

$thumb_id = $curso_id ? get_post_thumbnail_id($curso_id) : 0;
$thumb_url = $thumb_id ? wp_get_attachment_image_url($thumb_id, 'medium') : '';
$cor_header = $curso_id ? get_post_meta($curso_id, '_raz_curso_cor_header', true) : '#667eea';
$cor_controls = $curso_id ? get_post_meta($curso_id, '_raz_curso_cor_controls', true) : '#1e293b';

if (!$cor_header) { $cor_header = '#667eea'; }
if (!$cor_controls) { $cor_controls = '#1e293b'; }

// Tab ativa (Verifica URL para manter a tab após redirecionamentos)
$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'info';

// Buscar todos os cursos para o modal de duplicação
$all_courses = get_posts(array(
    'post_type'      => 'curso',
    'posts_per_page' => -1,
    'orderby'        => 'title',
    'order'          => 'ASC',
    'post_status'    => 'publish'
));
?>

<style>
/* ========== VARIABLES ========== */
:root {
    --primary: #0284c7;
    --primary-dark: #0369a1;
    --primary-light: #e0f2fe;
    --success: #10b981;
    --warning: #f59e0b;
    --danger: #ef4444;
    --danger-light: #fef2f2;
    --gray-50: #f8fafc;
    --gray-100: #f1f5f9;
    --gray-200: #e2e8f0;
    --gray-300: #cbd5e1;
    --gray-400: #94a3b8;
    --gray-500: #64748b;
    --gray-600: #475569;
    --gray-700: #334155;
    --gray-800: #1e293b;
}

/* ========== HEADER ========== */
.admin-header { 
    display: flex; 
    justify-content: space-between; 
    align-items: center; 
    margin-bottom: 28px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--gray-200);
}
.admin-header h2 { 
    margin: 0; 
    font-size: 24px; 
    font-weight: 700; 
    color: var(--gray-800);
    display: flex;
    align-items: center;
    gap: 12px;
}
.admin-header h2 .curso-status {
    font-size: 12px;
    font-weight: 500;
    padding: 4px 12px;
    border-radius: 20px;
    background: #dcfce7;
    color: #166534;
}
.btn-back {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    background: #fff;
    border: 1px solid var(--gray-200);
    border-radius: 8px;
    color: var(--gray-600);
    font-weight: 500;
    font-size: 14px;
    text-decoration: none;
    transition: all 0.2s;
}
.btn-back:hover {
    background: var(--gray-50);
    border-color: var(--gray-300);
    color: var(--gray-800);
}
.btn-back svg { width: 18px; height: 18px; }

/* ========== TABS ========== */
.tabs { 
    display: flex; 
    gap: 4px; 
    margin-bottom: 24px; 
    background: var(--gray-100);
    padding: 6px;
    border-radius: 12px;
    width: fit-content;
}
.tab { 
    padding: 12px 24px; 
    cursor: pointer; 
    font-weight: 600; 
    font-size: 14px;
    color: var(--gray-500); 
    border-radius: 8px;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    gap: 8px;
}
.tab:hover { color: var(--gray-700); background: rgba(255,255,255,0.5); }
.tab.active { 
    color: var(--primary); 
    background: #fff;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
.tab svg { width: 18px; height: 18px; }
.tab-content { display: none; animation: fadeIn 0.3s ease; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

/* ========== FORM CARD ========== */
.form-card { 
    background: #fff; 
    padding: 32px; 
    border-radius: 16px; 
    border: 1px solid var(--gray-200); 
    margin-bottom: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}
.form-card-header {
    margin-bottom: 28px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--gray-100);
}
.form-card-header h3 {
    margin: 0 0 6px 0;
    font-size: 18px;
    font-weight: 600;
    color: var(--gray-800);
    display: flex;
    align-items: center;
    gap: 10px;
}
.form-card-header p {
    margin: 0;
    font-size: 14px;
    color: var(--gray-500);
}

/* ========== FORM ELEMENTS ========== */
.form-section {
    margin-bottom: 32px;
    padding-bottom: 32px;
    border-bottom: 1px solid var(--gray-100);
}
.form-section:last-child { border-bottom: none; margin-bottom: 0; padding-bottom: 0; }
.form-section-title {
    font-size: 13px;
    font-weight: 600;
    color: var(--gray-500);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.form-section-title svg { width: 16px; height: 16px; color: var(--primary); }

.form-group { margin-bottom: 20px; }
.form-group label { 
    display: block; 
    margin-bottom: 8px; 
    font-weight: 600; 
    font-size: 13px; 
    color: var(--gray-700); 
}
.form-group label .required { color: var(--danger); }
.form-group input[type="text"], 
.form-group input[type="number"],
.form-group select, 
.form-group textarea { 
    width: 100%; 
    padding: 12px 14px; 
    border: 1px solid var(--gray-300); 
    border-radius: 8px; 
    font-size: 14px;
    transition: all 0.2s;
    background: #fff;
}
.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.1);
}
.form-group textarea { min-height: 180px; resize: vertical; line-height: 1.6; }
.form-hint { font-size: 12px; color: var(--gray-400); margin-top: 6px; display: flex; align-items: center; gap: 4px; }
.form-hint svg { width: 14px; height: 14px; }

.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
@media (max-width: 768px) { .form-row { grid-template-columns: 1fr; } }

/* ========== THUMBNAIL UPLOAD ========== */
.thumbnail-upload {
    display: flex;
    gap: 20px;
    align-items: flex-start;
}
.thumbnail-preview {
    width: 220px;
    height: 140px;
    background: linear-gradient(135deg, var(--primary), #7c3aed);
    border-radius: 12px;
    overflow: hidden;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px dashed transparent;
    transition: all 0.2s;
}
.thumbnail-preview:hover { border-color: var(--primary); }
.thumbnail-preview img { width: 100%; height: 100%; object-fit: cover; }
.thumbnail-preview-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    color: rgba(255,255,255,0.8);
}
.thumbnail-preview-empty svg { width: 32px; height: 32px; }
.thumbnail-actions {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

/* ========== COLOR PICKER ========== */
.color-picker-group {
    display: flex;
    align-items: center;
    gap: 12px;
}
.color-picker-group input[type="color"] {
    width: 50px;
    height: 40px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    padding: 0;
}
.color-picker-group input[type="color"]::-webkit-color-swatch-wrapper { padding: 0; }
.color-picker-group input[type="color"]::-webkit-color-swatch { border: 2px solid var(--gray-200); border-radius: 6px; }
.color-preview {
    flex: 1;
    height: 40px;
    border-radius: 8px;
    border: 1px solid var(--gray-200);
}

/* ========== BUTTONS ========== */
.btn { 
    padding: 10px 20px; 
    border-radius: 8px; 
    cursor: pointer; 
    border: none; 
    font-size: 14px; 
    font-weight: 600; 
    text-decoration: none; 
    display: inline-flex; 
    align-items: center; 
    gap: 8px;
    transition: all 0.2s;
}
.btn:disabled { opacity: 0.6; cursor: not-allowed; }
.btn svg { width: 16px; height: 16px; }
.btn-primary { background: var(--primary); color: #fff; }
.btn-primary:hover { background: var(--primary-dark); transform: translateY(-1px); box-shadow: 0 4px 12px rgba(2, 132, 199, 0.3); }
.btn-secondary { background: #fff; border: 1px solid var(--gray-200); color: var(--gray-600); }
.btn-secondary:hover { background: var(--gray-50); border-color: var(--gray-300); }
.btn-success { background: var(--success); color: #fff; }
.btn-danger { background: var(--danger-light); color: var(--danger); border: 1px solid #fecaca; }
.btn-danger:hover { background: var(--danger); color: #fff; }
.btn-warning { background: #fffbeb; border: 1px solid #fde68a; color: #b45309; }
.btn-warning:hover { background: #fef3c7; }
.btn-sm { padding: 6px 12px; font-size: 12px; }
.btn-lg { padding: 14px 28px; font-size: 15px; }

/* ========== CONTENT TAB - MODULES ========== */
.content-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
    flex-wrap: wrap;
    gap: 16px;
}
.content-header h3 {
    margin: 0;
    font-size: 18px;
    font-weight: 600;
    color: var(--gray-800);
    display: flex;
    align-items: center;
    gap: 10px;
}
.content-header h3 .count-badge {
    font-size: 12px;
    font-weight: 500;
    padding: 4px 10px;
    border-radius: 20px;
    background: var(--primary-light);
    color: var(--primary);
}
.content-actions { display: flex; gap: 10px; }

/* ========== MODULES LIST ========== */
.modulo-item { 
    background: #fff; 
    border: 1px solid var(--gray-200); 
    border-radius: 12px; 
    margin-bottom: 16px; 
    overflow: hidden;
    transition: all 0.2s;
}
.modulo-item:hover { border-color: var(--gray-300); box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
.modulo-item.expanded { box-shadow: 0 4px 20px rgba(0,0,0,0.08); }

.item-header { 
    padding: 16px 20px; 
    background: var(--gray-50); 
    display: flex; 
    justify-content: space-between; 
    align-items: center; 
    cursor: pointer; 
    border-bottom: 1px solid transparent;
    transition: all 0.2s;
}
.modulo-item.expanded .item-header { border-bottom-color: var(--gray-200); background: #fff; }
.item-header:hover { background: var(--gray-100); }

.item-header-left {
    display: flex;
    align-items: center;
    gap: 14px;
    flex: 1;
}
.item-drag { 
    cursor: grab; 
    color: var(--gray-400); 
    padding: 4px;
    border-radius: 4px;
    transition: all 0.2s;
}
.item-drag:hover { background: var(--gray-200); color: var(--gray-600); }
.item-drag:active { cursor: grabbing; }

.modulo-icon {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, var(--primary), #7c3aed);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
}
.modulo-icon svg { width: 20px; height: 20px; }

.modulo-info h4 {
    margin: 0 0 4px 0;
    font-size: 15px;
    font-weight: 600;
    color: var(--gray-800);
}
.modulo-meta {
    display: flex;
    align-items: center;
    gap: 12px;
}
.badge { 
    padding: 4px 10px; 
    border-radius: 20px; 
    font-size: 11px; 
    font-weight: 600;
    background: var(--primary-light); 
    color: var(--primary); 
}
.badge-gray { background: var(--gray-100); color: var(--gray-500); }

.item-header-actions {
    display: flex;
    gap: 8px;
    opacity: 0.7;
    transition: opacity 0.2s;
}
.item-header:hover .item-header-actions { opacity: 1; }

.expand-icon {
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--gray-400);
    transition: transform 0.3s;
}
.modulo-item.expanded .expand-icon { transform: rotate(180deg); }

/* ========== AULAS LIST ========== */
.aulas-list { 
    padding: 0;
    background: #fff;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
}
.modulo-item.expanded .aulas-list { max-height: 2000px; }

.item-row { 
    padding: 14px 20px 14px 76px; 
    border-bottom: 1px solid var(--gray-100); 
    display: flex; 
    align-items: center; 
    justify-content: space-between; 
    background: #fff;
    transition: all 0.15s;
}
.item-row:last-child { border-bottom: none; }
.item-row:hover { background: var(--gray-50); }

.item-row-left {
    display: flex;
    align-items: center;
    gap: 14px;
    flex: 1;
}
.aula-icon {
    width: 32px;
    height: 32px;
    background: var(--gray-100);
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--gray-500);
}
.aula-icon svg { width: 16px; height: 16px; }
.aula-title {
    font-size: 14px;
    color: var(--gray-700);
    font-weight: 500;
}

.item-row-actions {
    display: flex;
    gap: 6px;
    opacity: 0;
    transition: opacity 0.2s;
}
.item-row:hover .item-row-actions { opacity: 1; }

.sorting-disabled .item-drag { opacity: 0.3; cursor: not-allowed; }

/* ========== EMPTY STATE ========== */
.empty-state { 
    padding: 60px 40px; 
    text-align: center; 
    background: #fff; 
    border-radius: 12px; 
    border: 2px dashed var(--gray-200);
}
.empty-state-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, var(--primary-light), #ddd6fe);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
}
.empty-state-icon svg { width: 36px; height: 36px; color: var(--primary); }
.empty-state h4 { margin: 0 0 8px 0; font-size: 18px; color: var(--gray-800); }
.empty-state p { margin: 0 0 24px 0; color: var(--gray-500); font-size: 14px; }

/* ========== CONFIG TAB ========== */
.config-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px;
}
@media (max-width: 900px) { .config-grid { grid-template-columns: 1fr; } }

.webhook-tutorial { 
    margin-top: 32px; 
    padding: 24px; 
    background: linear-gradient(135deg, #f0f9ff, #e0f2fe); 
    border-radius: 12px; 
    border: 1px solid #bae6fd; 
}
.webhook-tutorial h4 { 
    color: var(--primary-dark); 
    margin: 0 0 12px 0;
    font-size: 16px;
    display: flex;
    align-items: center;
    gap: 10px;
}
.webhook-tutorial > p { font-size: 14px; color: var(--gray-600); margin-bottom: 16px; }
.webhook-url-box { 
    background: #fff; 
    border: 1px dashed var(--primary); 
    padding: 14px 16px; 
    border-radius: 8px; 
    font-family: 'Monaco', 'Consolas', monospace; 
    font-size: 12px; 
    color: var(--primary-dark); 
    display: flex; 
    justify-content: space-between; 
    align-items: center; 
    gap: 12px;
    margin-bottom: 20px;
}
.webhook-url-box span { word-break: break-all; }
.tutorial-steps { 
    padding-left: 0; 
    margin: 0;
    list-style: none;
}
.tutorial-steps li { 
    font-size: 13px; 
    color: var(--gray-600); 
    margin-bottom: 10px;
    padding-left: 28px;
    position: relative;
}
.tutorial-steps li::before {
    content: attr(data-step);
    position: absolute;
    left: 0;
    width: 20px;
    height: 20px;
    background: var(--primary);
    color: #fff;
    border-radius: 50%;
    font-size: 11px;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
}
.tutorial-steps li strong { color: var(--gray-700); }

/* ========== MODALS ========== */
.modal-overlay { 
    position: fixed; 
    inset: 0; 
    background: rgba(15, 23, 42, 0.6); 
    backdrop-filter: blur(4px);
    display: none; 
    align-items: center; 
    justify-content: center; 
    z-index: 1000;
    padding: 20px;
}
.modal-overlay.open { display: flex; animation: fadeIn 0.2s ease; }
.modal { 
    background: #fff; 
    width: 100%;
    max-width: 480px; 
    border-radius: 16px; 
    box-shadow: 0 25px 50px rgba(0,0,0,0.25);
    animation: slideUp 0.3s ease;
}
@keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
.modal-header { 
    display: flex; 
    justify-content: space-between; 
    align-items: center; 
    padding: 20px 24px;
    border-bottom: 1px solid var(--gray-200);
}
.modal-header h3 {
    margin: 0;
    font-size: 18px;
    font-weight: 600;
    color: var(--gray-800);
    display: flex;
    align-items: center;
    gap: 10px;
}
.modal-close {
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--gray-100);
    border: none;
    border-radius: 8px;
    cursor: pointer;
    color: var(--gray-500);
    font-size: 20px;
    transition: all 0.2s;
}
.modal-close:hover { background: var(--danger-light); color: var(--danger); }
.modal-body { padding: 24px; }
.modal-footer {
    padding: 16px 24px;
    border-top: 1px solid var(--gray-200);
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    background: var(--gray-50);
    border-radius: 0 0 16px 16px;
}

/* ========== TOAST ========== */
#raz-toast-container { z-index: 9999 !important; }

/* ========== ANIMATIONS ========== */
@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

/* ========== RESPONSIVE ========== */
@media (max-width: 768px) {
    .admin-header { flex-direction: column; align-items: flex-start; gap: 16px; }
    .tabs { width: 100%; overflow-x: auto; }
    .form-card { padding: 20px; }
    .content-header { flex-direction: column; align-items: flex-start; }
    .item-header { flex-direction: column; align-items: flex-start; gap: 12px; }
    .item-header-actions { width: 100%; justify-content: flex-end; }
    .item-row { padding-left: 20px; }
    .thumbnail-upload { flex-direction: column; }
    .thumbnail-preview { width: 100%; height: 160px; }
}
</style>

<div class="admin-header">
    <h2>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="28" height="28"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
        <?php echo $curso_id ? esc_html($curso->post_title) : 'Novo Curso'; ?>
        <?php if ($curso_id) : ?>
        <span class="curso-status">Publicado</span>
        <?php endif; ?>
    </h2>
    <a href="<?php echo home_url('/gestao-cursos/cursos'); ?>" class="btn-back">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
        Voltar para Cursos
    </a>
</div>

<div class="tabs">
    <div class="tab <?php echo $active_tab === 'info' ? 'active' : ''; ?>" onclick="showTab('info',this)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
        Informações
    </div>
    <?php if ($curso_id) : ?>
    <div class="tab <?php echo $active_tab === 'conteudo' ? 'active' : ''; ?>" onclick="showTab('conteudo',this)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
        Conteúdo
        <span class="badge"><?php echo count($modulos); ?></span>
    </div>
    <div class="tab <?php echo $active_tab === 'grupos' ? 'active' : ''; ?>" onclick="showTab('grupos',this)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        Grupos
    </div>
    <div class="tab <?php echo $active_tab === 'config' ? 'active' : ''; ?>" onclick="showTab('config',this)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
        Configurações
    </div>
    <?php endif; ?>
</div>

<div id="tab-info" class="tab-content" style="<?php echo $active_tab === 'info' ? 'display:block;' : 'display:none;'; ?>">
    <div class="form-card" style="max-width:860px;">
        <div class="form-card-header">
            <h3>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="22" height="22"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                Informações do Curso
            </h3>
            <p>Preencha os dados básicos do curso</p>
        </div>
        
        <form id="form-curso" enctype="multipart/form-data">
            <input type="hidden" name="curso_id" value="<?php echo $curso_id; ?>">
            <input type="hidden" name="action" value="raz_save_curso">
            <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('raz_admin_nonce'); ?>">
            
            <div class="form-section">
                <div class="form-section-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                    Imagem e Identidade Visual
                </div>
                
                <div class="form-group">
                    <label>Capa do Curso</label>
                    <div class="thumbnail-upload">
                        <div id="thumb-preview" class="thumbnail-preview" style="background:linear-gradient(135deg,<?php echo esc_attr($cor_header); ?>,#7c3aed);">
                            <?php if ($thumb_url) : ?>
                            <img src="<?php echo esc_url($thumb_url); ?>">
                            <?php else : ?>
                            <div class="thumbnail-preview-empty">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                                <span style="font-size:12px;">Sem imagem</span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="thumbnail-actions">
                            <input type="file" name="thumbnail" id="thumbnail-input" accept="image/*" style="display:none;">
                            <input type="hidden" name="thumbnail_id" id="thumbnail_id" value="<?php echo $thumb_id; ?>">
                            <button type="button" class="btn btn-secondary" onclick="document.getElementById('thumbnail-input').click()">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                                Escolher Imagem
                            </button>
                            <p class="form-hint">Recomendado: 800x450px (16:9)</p>
                        </div>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Cor do Header</label>
                        <div class="color-picker-group">
                            <input type="color" name="cor_header" id="cor_header" value="<?php echo esc_attr($cor_header); ?>">
                            <div class="color-preview" style="background:<?php echo esc_attr($cor_header); ?>;"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Cor dos Controles</label>
                        <div class="color-picker-group">
                            <input type="color" name="cor_controls" id="cor_controls" value="<?php echo esc_attr($cor_controls); ?>">
                            <div class="color-preview" style="background:<?php echo esc_attr($cor_controls); ?>;"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="form-section">
                <div class="form-section-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                    Dados do Curso
                </div>
                
                <div class="form-group">
                    <label>Título do Curso <span class="required">*</span></label>
                    <input type="text" name="titulo" value="<?php echo $curso ? esc_attr($curso->post_title) : ''; ?>" required placeholder="Ex: Curso Completo de Marketing Digital">
                </div>
                
                <div class="form-group">
                    <label>Descrição do Curso</label>
                    <textarea name="descricao" id="descricao" rows="8" placeholder="Descreva o que o aluno vai aprender neste curso..."><?php echo $curso ? esc_textarea($curso->post_excerpt) : ''; ?></textarea>
                    <p class="form-hint">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
                        Esta descrição aparece na página do curso
                    </p>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary btn-lg">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                Salvar Curso
            </button>
        </form>
    </div>
</div>

<?php if ($curso_id) : ?>
<div id="tab-conteudo" class="tab-content" style="<?php echo $active_tab === 'conteudo' ? 'display:block;' : 'display:none;'; ?>">
    <div class="content-header">
        <h3>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="22" height="22"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
            Módulos e Aulas
            <span class="count-badge"><?php echo count($modulos); ?> módulo<?php echo count($modulos) != 1 ? 's' : ''; ?></span>
        </h3>
        <div class="content-actions">
            <button type="button" class="btn <?php echo 'btn-warning'; ?>" id="toggle-sorting-btn" onclick="toggleGlobalSorting()">
                <span id="lock-icon">🔒</span> 
                <span id="lock-text">Destravar Ordenação</span>
            </button>
            <button class="btn btn-primary" onclick="openModuloModal()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                Novo Módulo
            </button>
        </div>
    </div>
    
    <div class="item-list sorting-disabled" id="modulos-list">
        <?php if (empty($modulos)) : ?>
        <div class="empty-state">
            <div class="empty-state-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
            </div>
            <h4>Nenhum módulo criado</h4>
            <p>Comece criando o primeiro módulo do seu curso</p>
            <button class="btn btn-primary" onclick="openModuloModal()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                Criar Primeiro Módulo
            </button>
        </div>
        <?php else : 
            foreach ($modulos as $idx => $modulo) : 
                $aulas = raz_lms_get_aulas($modulo->ID); 
        ?>
        <div class="modulo-item sortable-item" data-id="<?php echo $modulo->ID; ?>">
            <div class="item-header" onclick="toggleModuloExpand(this)">
                <div class="item-header-left">
                    <span class="item-drag" onclick="event.stopPropagation();">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                    </span>
                    <div class="modulo-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
                    </div>
                    <div class="modulo-info">
                        <h4><?php echo esc_html($modulo->post_title); ?></h4>
                        <div class="modulo-meta">
                            <span class="badge"><?php echo count($aulas); ?> aula<?php echo count($aulas) != 1 ? 's' : ''; ?></span>
                            <span class="badge badge-gray">Módulo <?php echo $idx + 1; ?></span>
                        </div>
                    </div>
                </div>
                <div class="item-header-actions">
                    <button class="btn btn-sm btn-secondary" onclick="event.stopPropagation();editModulo(<?php echo $modulo->ID; ?>,'<?php echo esc_js($modulo->post_title); ?>')">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        Editar
                    </button>
                    <button class="btn btn-sm btn-secondary" onclick="event.stopPropagation();razOpenDuplicateModule(<?php echo $modulo->ID; ?>)">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                        Duplicar
                    </button>
                    <a href="<?php echo home_url('/gestao-cursos/aula-editar/?modulo=' . $modulo->ID . '&curso=' . $curso_id); ?>" class="btn btn-sm btn-primary" onclick="event.stopPropagation();">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                        Aula
                    </a>
                    <button class="btn btn-sm btn-danger" onclick="event.stopPropagation();deleteItem(<?php echo $modulo->ID; ?>,'modulo',this)">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                    </button>
                </div>
                <div class="expand-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><polyline points="6 9 12 15 18 9"/></svg>
                </div>
            </div>
            <div class="item-content aulas-list" id="aulas-<?php echo $modulo->ID; ?>">
                <?php if (empty($aulas)) : ?>
                <div style="padding:24px;text-align:center;color:#94a3b8;font-size:13px;">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="32" height="32" style="margin-bottom:8px;opacity:0.5;"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                    <p style="margin:0;">Nenhuma aula neste módulo</p>
                </div>
                <?php else : foreach ($aulas as $aula) : ?>
                <div class="item-row sortable-item" data-id="<?php echo $aula->ID; ?>">
                    <div class="item-row-left">
                        <span class="item-drag">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                        </span>
                        <div class="aula-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                        </div>
                        <span class="aula-title"><?php echo esc_html($aula->post_title); ?></span>
                    </div>
                    <div class="item-row-actions">
                        <a href="<?php echo home_url('/gestao-cursos/aula-editar/' . $aula->ID . '?curso=' . $curso_id); ?>" class="btn btn-sm btn-secondary">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                            Editar
                        </a>
                        <button class="btn btn-sm btn-secondary" onclick="razOpenDuplicateLesson(<?php echo $aula->ID; ?>)">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                            Duplicar
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteItem(<?php echo $aula->ID; ?>,'aula',this)">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                        </button>
                    </div>
                </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
        <?php endforeach; endif; ?>
    </div>
</div>

<div id="tab-grupos" class="tab-content" style="<?php echo $active_tab === 'grupos' ? 'display:block;' : 'display:none;'; ?>">
    <?php include get_template_directory() . '/templates/grupos-acesso-component.php'; ?>
</div>

<div id="tab-config" class="tab-content" style="<?php echo $active_tab === 'config' ? 'display:block;' : 'display:none;'; ?>">
    <div class="form-card" style="max-width:800px;">
        <div class="form-card-header">
            <h3>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="22" height="22"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                Configurações do Curso
            </h3>
            <p>Configure integração e tipo de acesso</p>
        </div>
        
        <form id="form-config">
            <input type="hidden" name="curso_id" value="<?php echo $curso_id; ?>">
            
            <div class="form-section">
                <div class="form-section-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                    Integração com Kiwify
                </div>
                
                <div class="form-group">
                    <label>ID do Produto Kiwify</label>
                    <input type="text" name="kiwify_id" value="<?php echo esc_attr($kiwify_id); ?>" placeholder="Ex: P_abc123xyz">
                    <p class="form-hint">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
                        Encontre este ID no painel da Kiwify > Produtos > Configurações
                    </p>
                </div>
            </div>
            
            <div class="form-section">
                <div class="form-section-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                    Tipo de Acesso
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Modelo de Acesso</label>
                        <select name="tipo" id="conf_tipo" onchange="toggleAccessDays()">
                            <option value="avulso" <?php selected($tipo_acesso, 'avulso'); ?>>📦 Avulso (Compra única)</option>
                            <option value="assinatura" <?php selected($tipo_acesso, 'assinatura'); ?>>🔄 Assinatura (Recorrente)</option>
                            <option value="vitalicio" <?php selected($tipo_acesso, 'vitalicio'); ?>>♾️ Vitalício</option>
                        </select>
                    </div>
                    <div class="form-group" id="conf_dias_group">
                        <label>Dias de Acesso</label>
                        <input type="number" name="dias_acesso" value="<?php echo intval($dias_acesso); ?>" min="1">
                        <p class="form-hint">Período de acesso após a compra</p>
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary btn-lg">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                Salvar Configurações
            </button>
        </form>

        <div class="webhook-tutorial">
            <h4>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                Integração Automática via Webhook
            </h4>
            <p>Configure o webhook na Kiwify para criar alunos automaticamente:</p>
            <div class="webhook-url-box">
                <span id="webhook-url-text"><?php echo get_rest_url(null, 'raz-lms/v1/kiwify'); ?></span>
                <button type="button" class="btn btn-sm btn-secondary" onclick="copyWebhookUrl()">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                    Copiar
                </button>
            </div>
            <ul class="tutorial-steps">
                <li data-step="1">No painel <strong>Kiwify</strong>, acesse <strong>Produtos</strong> e selecione este curso</li>
                <li data-step="2">Vá em <strong>Configurações</strong> → seção <strong>Webhooks</strong></li>
                <li data-step="3">Clique em <strong>"Adicionar Webhook"</strong> e cole a URL acima</li>
                <li data-step="4">Selecione os eventos: <strong>Compra aprovada</strong>, <strong>Reembolso</strong> e <strong>Cancelamento</strong></li>
                <li data-step="5">Para assinaturas, adicione também: <strong>Assinatura renovada</strong> e <strong>Assinatura cancelada</strong></li>
                <li data-step="6">Salve as configurações. O sistema agora gerencia alunos automaticamente!</li>
            </ul>
        </div>
    </div>
</div>

<div class="modal-overlay" id="modal-modulo">
    <div class="modal">
        <div class="modal-header">
            <h3 id="modal-modulo-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
                Novo Módulo
            </h3>
            <button type="button" class="modal-close" onclick="closeModal('modal-modulo')">&times;</button>
        </div>
        <div class="modal-body">
            <form id="form-modulo">
                <input type="hidden" name="modulo_id" id="modulo_id">
                <input type="hidden" name="curso_id" value="<?php echo $curso_id; ?>">
                <div class="form-group">
                    <label>Nome do Módulo <span class="required">*</span></label>
                    <input type="text" name="titulo" id="modulo_titulo" required placeholder="Ex: Módulo 1 - Introdução">
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('modal-modulo')">Cancelar</button>
            <button type="submit" form="form-modulo" class="btn btn-primary">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="20 6 9 17 4 12"/></svg>
                Salvar Módulo
            </button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="modal-dup-aula">
    <div class="modal">
        <div class="modal-header">
            <h3>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                Duplicar Aula
            </h3>
            <button type="button" class="modal-close" onclick="closeModal('modal-dup-aula')">&times;</button>
        </div>
        <div class="modal-body">
            <form id="form-dup-aula">
                <input type="hidden" name="source_id" id="dup_aula_source_id">
                <input type="hidden" name="type" value="aula">
                <div class="form-group">
                    <label>Curso Destino</label>
                    <select name="target_course_id" id="dup_aula_course_select" onchange="razLoadModulesForDup(this.value)">
                        <option value="">Selecione um curso...</option>
                        <?php foreach ($all_courses as $c): ?>
                            <option value="<?php echo $c->ID; ?>" <?php selected($c->ID, $curso_id); ?>><?php echo esc_html($c->post_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Módulo Destino</label>
                    <select name="target_module_id" id="dup_aula_module_select" required></select>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('modal-dup-aula')">Cancelar</button>
            <button type="submit" form="form-dup-aula" class="btn btn-primary">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                Duplicar Aula
            </button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="modal-dup-modulo">
    <div class="modal">
        <div class="modal-header">
            <h3>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                Duplicar Módulo
            </h3>
            <button type="button" class="modal-close" onclick="closeModal('modal-dup-modulo')">&times;</button>
        </div>
        <div class="modal-body">
            <form id="form-dup-modulo">
                <input type="hidden" name="source_id" id="dup_mod_source_id">
                <input type="hidden" name="type" value="modulo">
                <div class="form-group">
                    <label>Curso Destino</label>
                    <select name="target_course_id">
                        <?php foreach ($all_courses as $c): ?>
                            <option value="<?php echo $c->ID; ?>" <?php selected($c->ID, $curso_id); ?>><?php echo esc_html($c->post_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <p class="form-hint" style="margin-top:-8px;">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
                    Todas as aulas do módulo serão duplicadas junto
                </p>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('modal-dup-modulo')">Cancelar</button>
            <button type="submit" form="form-dup-modulo" class="btn btn-primary">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                Duplicar Módulo
            </button>
        </div>
    </div>
</div>
<?php endif; ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js"></script>
<script>
var cursoId = <?php echo $curso_id ?: 0; ?>;
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
var nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';
var isSortingEnabled = false;
var sortableInstances = [];

function showTab(t, el) {
    document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(x => x.style.display = 'none');
    el.classList.add('active');
    document.getElementById('tab-' + t).style.display = 'block';
}

function toggleModuloExpand(el) {
    var moduloItem = el.closest('.modulo-item');
    moduloItem.classList.toggle('expanded');
}

function toggleModulo(el) {
    var content = el.nextElementSibling;
    content.style.display = (content.style.display === 'none') ? 'block' : 'none';
}

function toggleAccessDays() {
    var type = document.getElementById('conf_tipo').value;
    document.getElementById('conf_dias_group').style.display = (type === 'vitalicio') ? 'none' : 'block';
}

function openModal(id) { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }

function openModuloModal(id, titulo) {
    document.getElementById('modulo_id').value = id || '';
    document.getElementById('modulo_titulo').value = titulo || '';
    var titleEl = document.getElementById('modal-modulo-title');
    titleEl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>' + (id ? 'Editar Módulo' : 'Novo Módulo');
    openModal('modal-modulo');
}

function editModulo(id, title) { openModuloModal(id, title); }

function razOpenDuplicateModule(id) { 
    document.getElementById('dup_mod_source_id').value = id; 
    openModal('modal-dup-modulo'); 
}

function razOpenDuplicateLesson(id) {
    document.getElementById('dup_aula_source_id').value = id;
    document.getElementById('dup_aula_course_select').value = cursoId;
    razLoadModulesForDup(cursoId);
    openModal('modal-dup-aula');
}

function razLoadModulesForDup(cId) {
    var sel = document.getElementById('dup_aula_module_select');
    if(!cId) { sel.innerHTML = ''; return; }
    sel.innerHTML = '<option>Carregando...</option>';
    fetch(ajaxurl + '?action=raz_get_modules_by_course&nonce='+nonce+'&curso_id='+cId)
    .then(r=>r.json()).then(d=>{
        sel.innerHTML = '';
        if(d.success) d.data.forEach(m=>{
            var opt=document.createElement('option'); opt.value=m.id; opt.textContent=m.title; sel.appendChild(opt);
        });
    });
}

function toggleGlobalSorting() {
    isSortingEnabled = !isSortingEnabled;
    var btn = document.getElementById('toggle-sorting-btn');
    document.getElementById('lock-icon').innerText = isSortingEnabled ? '🔓' : '🔒';
    document.getElementById('lock-text').innerText = isSortingEnabled ? 'Bloquear Ordenação' : 'Destravar Ordenação';
    btn.classList.toggle('btn-warning');
    document.getElementById('modulos-list').classList.toggle('sorting-disabled');
    sortableInstances.forEach(i => i.option("disabled", !isSortingEnabled));
}

function copyWebhookUrl() {
    navigator.clipboard.writeText(document.getElementById('webhook-url-text').innerText).then(() => {
        showToast('URL copiada!');
    });
}

function deleteItem(id, type, btn) {
    if(!confirm('Tem certeza que deseja excluir?')) return;
    var fd = new FormData();
    fd.append('action', 'raz_delete_item');
    fd.append('nonce', nonce);
    fd.append('item_id', id);
    fd.append('type', type);
    fetch(ajaxurl, {method:'POST', body:fd}).then(r=>r.json()).then(d=>{
        if(d.success) location.reload(); else alert(d.data.message);
    });
}

function saveOrder(items, tipo) {
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_reorder&nonce=' + nonce + '&tipo=' + tipo + '&items=' + JSON.stringify(items)
    }).then(r => r.json()).then(d => { 
        if (d.success) showToast('Ordem atualizada!'); 
    });
}

function updateLessonParent(lessonId, newModId) {
    var fd = new FormData();
    fd.append('action', 'raz_save_aula');
    fd.append('nonce', nonce);
    fd.append('aula_id', lessonId);
    fd.append('modulo_id', newModId);
    fetch(ajaxurl, {method:'POST', body:fd});
}

document.getElementById('form-curso').onsubmit = function(e){
    e.preventDefault();
    var fd = new FormData(this);
    fetch(ajaxurl, {method:'POST', body:fd}).then(r=>r.json()).then(d=>{
        if(d.success) { 
            showToast('Curso Salvo!'); 
            if(!cursoId) window.location.href=razAdmin.homeUrl+'/gestao-cursos/curso-editar/'+d.data.curso_id; 
        }
    });
};

document.getElementById('form-modulo').onsubmit = function(e){
    e.preventDefault();
    var btn = document.querySelector('button[form="form-modulo"]');
    if(btn) {
        btn.disabled = true;
        btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" style="animation:spin 1s linear infinite"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Salvando...';
    }
    
    var fd = new FormData(this);
    fd.append('action', 'raz_save_modulo');
    fd.append('nonce', nonce);
    fetch(ajaxurl, {method:'POST', body:fd}).then(r=>r.json()).then(d=>{
        if(d.success) { 
            showToast('Módulo salvo!'); 
            setTimeout(function() {
                location.href = location.pathname + '?tab=conteudo';
            }, 1000);
        } else {
            if(btn) {
                btn.disabled = false;
                btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="20 6 9 17 4 12"/></svg> Salvar Módulo';
            }
            alert(d.data?.message || 'Erro ao salvar módulo');
        }
    });
};

document.getElementById('form-config').onsubmit = function(e){
    e.preventDefault();
    var fd = new FormData(this);
    fd.append('action', 'raz_save_curso');
    fd.append('nonce', nonce);
    fetch(ajaxurl, {method:'POST', body:fd}).then(r=>r.json()).then(d=>{
        if(d.success) showToast('Configurações salvas!');
    });
};

document.getElementById('form-dup-aula').onsubmit = function(e){
    e.preventDefault();
    var btn = document.querySelector('button[form="form-dup-aula"]');
    if(btn) {
        btn.disabled = true;
        btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" style="animation:spin 1s linear infinite"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Processando...';
    }
    
    var fd = new FormData(this);
    fd.append('action', 'raz_duplicate_content');
    fd.append('nonce', nonce);
    fetch(ajaxurl, {method:'POST', body:fd}).then(r=>r.json()).then(d=>{
        if(d.success) { 
            showToast('Aula duplicada!'); 
            setTimeout(function() {
                location.href = location.pathname + '?tab=conteudo';
            }, 1500);
        } else {
            if(btn) {
                btn.disabled = false;
                btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Duplicar Aula';
            }
            alert(d.data.message || 'Erro ao duplicar');
        }
    });
};

document.getElementById('form-dup-modulo').onsubmit = function(e){
    e.preventDefault();
    var btn = document.querySelector('button[form="form-dup-modulo"]');
    if(btn) {
        btn.disabled = true;
        btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" style="animation:spin 1s linear infinite"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Processando...';
    }
    
    var fd = new FormData(this);
    fd.append('action', 'raz_duplicate_content');
    fd.append('nonce', nonce);
    fetch(ajaxurl, {method:'POST', body:fd}).then(r=>r.json()).then(d=>{
        if(d.success) { 
            showToast('Módulo duplicado!'); 
            setTimeout(function() {
                location.href = location.pathname + '?tab=conteudo';
            }, 1500);
        } else {
            if(btn) {
                btn.disabled = false;
                btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Duplicar Módulo';
            }
            alert(d.data.message || 'Erro ao duplicar');
        }
    });
};

document.addEventListener('DOMContentLoaded', function() {
    if(document.getElementById('conf_tipo')) toggleAccessDays();
    
    const urlParams = new URLSearchParams(window.location.search);
    const activeTabParam = urlParams.get('tab');
    
    if(activeTabParam === 'conteudo') {
        const tabBtn = document.querySelector('.tab:nth-child(2)');
        if(tabBtn) showTab('conteudo', tabBtn);
    } else if(activeTabParam === 'grupos') {
        const tabBtn = document.querySelector('.tab:nth-child(3)');
        if(tabBtn) showTab('grupos', tabBtn);
    } else if(activeTabParam === 'config') {
        const tabBtn = document.querySelector('.tab:nth-child(4)');
        if(tabBtn) showTab('config', tabBtn);
    } else {
        const tabBtn = document.querySelector('.tab:first-child');
        if(tabBtn) showTab('info', tabBtn);
    }

    var modList = document.getElementById('modulos-list');
    if (modList && typeof Sortable !== 'undefined') {
        sortableInstances.push(new Sortable(modList, {
            animation: 150, handle: '.item-drag', disabled: true,
            onEnd: function() { 
                var items = []; 
                modList.querySelectorAll('.modulo-item').forEach(el => items.push(el.dataset.id));
                saveOrder(items, 'modulo');
            }
        }));
        document.querySelectorAll('.aulas-list').forEach(list => {
            sortableInstances.push(new Sortable(list, {
                animation: 150, handle: '.item-drag', group: 'lessons', disabled: true,
                onEnd: function(evt) {
                    var items = []; 
                    list.querySelectorAll('.item-row').forEach(el => items.push(el.dataset.id));
                    if(evt.from !== evt.to) updateLessonParent(evt.item.dataset.id, evt.to.id.replace('aulas-', ''));
                    saveOrder(items, 'aula');
                }
            }));
        });
    }
});
</script>