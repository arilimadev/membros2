<?php
/**
 * Admin: Relatórios - Foco em Progresso do Aluno
 * Design: Premium UX/UI
 */
global $wpdb;

// 1. Configurações Iniciais e Filtros
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));
$curso_id = isset($_GET['curso']) ? intval($_GET['curso']) : ($cursos[0]->ID ?? 0);
$curso = get_post($curso_id);

$s_aluno = isset($_GET['s_aluno']) ? sanitize_text_field($_GET['s_aluno']) : '';
$current_page_slug = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : 'gestao-cursos';

// 2. Paginação Configurada para 10 itens
$per_page = 10; 
$current_paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$offset = ($current_paged - 1) * $per_page;

if ($curso) {
    // 3. Lógica de Busca de Alunos
    $user_search_query = "";
    if (!empty($s_aluno)) {
        $user_ids_found = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->users} WHERE user_email LIKE %s OR display_name LIKE %s",
            '%' . $s_aluno . '%', '%' . $s_aluno . '%'
        ));
        if (!empty($user_ids_found)) {
            $user_search_query = " AND user_id IN (" . implode(',', array_map('intval', $user_ids_found)) . ")";
        } else {
            $user_search_query = " AND user_id = 0";
        }
    }

    // 4. Contagem Total para Paginação
    $total_alunos = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key = %s $user_search_query",
        '_raz_curso_acesso_' . $curso_id
    ));

    // 5. Busca Paginada
    $alunos_query = $wpdb->get_results($wpdb->prepare(
        "SELECT DISTINCT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s $user_search_query ORDER BY user_id DESC LIMIT %d OFFSET %d",
        '_raz_curso_acesso_' . $curso_id,
        $per_page,
        $offset
    ));

    $total_pages = ceil($total_alunos / $per_page);
}
?>

<style>
    :root {
        --raz-primary: #0891b2;
        --raz-primary-hover: #0e7490;
        --raz-bg: #f8fafc;
        --raz-surface: #ffffff;
        --raz-border: #e2e8f0;
        --raz-text: #1e293b;
        --raz-text-muted: #64748b;
        --raz-text-light: #94a3b8;
        --raz-success-bg: #ecfdf5;
        --raz-success-text: #059669;
        --raz-info-bg: #f0f9ff;
        --raz-info-text: #0284c7;
        --raz-warning-bg: #fffbeb;
        --raz-warning-text: #d97706;
        --raz-radius: 8px;
        --raz-radius-lg: 12px;
        --raz-shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        --raz-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .raz-admin-container {
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        color: var(--raz-text);
        max-width: 1100px;
        margin: 20px auto 60px;
    }

    /* Headings */
    .raz-page-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 24px;
        padding-bottom: 16px;
        border-bottom: 1px solid var(--raz-border);
    }
    .raz-page-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--raz-text);
        margin: 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .raz-page-title svg { color: var(--raz-primary); }

    /* Cards */
    .raz-card {
        background: var(--raz-surface);
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        padding: 24px;
        box-shadow: var(--raz-shadow);
        margin-bottom: 32px;
    }

    /* Filter Bar */
    .raz-filter-bar {
        display: flex;
        gap: 16px;
        align-items: flex-end;
        flex-wrap: wrap;
    }
    .raz-filter-item { flex: 1; min-width: 250px; }
    .raz-filter-item.narrow { flex: 0 0 auto; min-width: auto; }

    /* Inputs */
    .raz-label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px; color: var(--raz-text); }
    .raz-input-wrapper { position: relative; }
    .raz-input-icon {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--raz-text-light);
        pointer-events: none;
    }
    .raz-input, .raz-select {
        width: 100%;
        padding: 10px 12px 10px 36px;
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius);
        font-size: 14px;
        background: #fff;
        transition: var(--transition);
        box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        height: 42px;
    }
    .raz-select { padding-left: 36px; -webkit-appearance: none; appearance: none; background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e"); background-position: right 0.5rem center; background-repeat: no-repeat; background-size: 1.5em 1.5em; }
    .raz-input:focus, .raz-select:focus {
        border-color: var(--raz-primary);
        outline: none;
        box-shadow: 0 0 0 3px rgba(8, 145, 178, 0.15);
    }

    /* Buttons */
    .raz-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 10px 20px;
        font-size: 14px;
        font-weight: 600;
        border-radius: var(--raz-radius);
        cursor: pointer;
        border: 1px solid transparent;
        transition: var(--transition);
        text-decoration: none;
        gap: 8px;
        height: 42px;
    }
    .raz-btn-primary { 
        background: var(--raz-primary); 
        color: white; 
        box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }
    .raz-btn-primary:hover { 
        background: var(--raz-primary-hover); 
        transform: translateY(-1px);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    /* Table */
    .raz-table-wrapper {
        background: white;
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        overflow: hidden;
        box-shadow: var(--raz-shadow-sm);
    }
    .raz-table { width: 100%; border-collapse: collapse; }
    .raz-table th {
        background: #f8fafc;
        padding: 16px 24px;
        text-align: left;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--raz-text-muted);
        border-bottom: 1px solid var(--raz-border);
    }
    .raz-table td {
        padding: 16px 24px;
        border-bottom: 1px solid var(--raz-border);
        color: var(--raz-text);
        font-size: 14px;
        vertical-align: middle;
    }
    .raz-table tr:last-child td { border-bottom: none; }
    .raz-table tr:hover { background: #fbfbfc; }

    /* User Info */
    .raz-user-info { display: flex; align-items: center; gap: 12px; }
    .raz-avatar-placeholder {
        width: 36px; height: 36px;
        background: #e2e8f0;
        color: #64748b;
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 14px; font-weight: 600;
        flex-shrink: 0;
    }

    /* Progress Bar Component */
    .raz-progress-wrapper {
        display: flex;
        align-items: center;
        gap: 12px;
        width: 100%;
        max-width: 300px;
    }
    .raz-progress-track {
        flex: 1;
        height: 8px;
        background: #f1f5f9;
        border-radius: 9999px;
        overflow: hidden;
    }
    .raz-progress-fill {
        height: 100%;
        background: var(--raz-primary);
        border-radius: 9999px;
        transition: width 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
    }
    .raz-progress-fill.completed { background: var(--raz-success-text); }
    .raz-progress-text {
        font-size: 13px;
        font-weight: 600;
        min-width: 40px;
        text-align: right;
    }
    .raz-progress-meta {
        font-size: 11px;
        color: var(--raz-text-light);
        margin-top: 4px;
        display: block;
    }

    /* Status Badges */
    .raz-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.02em;
    }
    .raz-badge svg { width: 12px; height: 12px; }
    .raz-badge-success { background: var(--raz-success-bg); color: var(--raz-success-text); border: 1px solid rgba(16, 185, 129, 0.2); }
    .raz-badge-warning { background: var(--raz-warning-bg); color: var(--raz-warning-text); border: 1px solid rgba(217, 119, 6, 0.2); }

    /* Utilities */
    .u-muted { color: var(--raz-text-muted); font-size: 13px; }
    .u-bold { font-weight: 600; color: var(--raz-text); }
    
    /* Pagination */
    .raz-pagination {
        display: flex;
        justify-content: center;
        gap: 8px;
        margin-top: 32px;
    }
    .raz-pagination .page-numbers {
        display: flex;
        align-items: center;
        justify-content: center;
        min-width: 36px;
        height: 36px;
        padding: 0 12px;
        border-radius: 6px;
        text-decoration: none;
        color: var(--raz-text-muted);
        background: white;
        border: 1px solid var(--raz-border);
        font-size: 13px;
        font-weight: 500;
        transition: var(--transition);
    }
    .raz-pagination .page-numbers:hover {
        border-color: var(--raz-primary);
        color: var(--raz-primary);
    }
    .raz-pagination .current {
        background: var(--raz-primary);
        color: white;
        border-color: var(--raz-primary);
    }
    .raz-pagination .dots { border: none; background: transparent; }

    .empty-state {
        text-align: center;
        padding: 80px 20px;
        color: var(--raz-text-muted);
        background: white;
        border-radius: var(--raz-radius-lg);
        border: 2px dashed var(--raz-border);
    }
    .empty-state svg { width: 48px; height: 48px; color: #cbd5e1; margin-bottom: 16px; }
</style>

<div class="raz-admin-container">
    
    <div class="raz-page-header">
        <div>
            <h2 class="raz-page-title">
                <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                Relatórios de Progresso
            </h2>
            <?php if ($total_alunos > 0): ?>
                <p style="margin: 4px 0 0 40px; color: var(--raz-text-muted); font-size: 14px;">
                    Exibindo <strong><?php echo count($alunos_query); ?></strong> de <strong><?php echo $total_alunos; ?></strong> alunos matriculados neste curso.
                </p>
            <?php endif; ?>
        </div>
    </div>

    <div class="raz-card">
        <form method="get" class="raz-filter-bar">
            <input type="hidden" name="page" value="<?php echo esc_attr($current_page_slug); ?>">
            <input type="hidden" name="tab" value="relatorios">
            
            <div class="raz-filter-item">
                <label class="raz-label">Curso Selecionado</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                    <select name="curso" class="raz-select" onchange="this.form.submit()">
                        <?php foreach ($cursos as $c) : ?>
                        <option value="<?php echo $c->ID; ?>" <?php selected($curso_id, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="raz-filter-item">
                <label class="raz-label">Buscar Aluno</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    <input type="text" name="s_aluno" class="raz-input" placeholder="Digite e-mail ou nome..." value="<?php echo esc_attr($s_aluno); ?>">
                </div>
            </div>

            <div class="raz-filter-item narrow">
                <button type="submit" class="raz-btn raz-btn-primary" style="width: 100%;">
                    Filtrar
                </button>
            </div>
        </form>
    </div>

    <?php if ($curso) : ?>
        
        <?php if (empty($alunos_query)) : ?>
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                <h3>Nenhum aluno encontrado</h3>
                <p>Não encontramos alunos matriculados neste curso com os filtros atuais.</p>
            </div>
        <?php else : ?>
            <div class="raz-table-wrapper">
                <table class="raz-table">
                    <thead>
                        <tr>
                            <th width="35%">Aluno</th>
                            <th width="25%">Contato</th>
                            <th width="15%" style="text-align: center;">Status</th>
                            <th width="25%">Progresso no Curso</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($alunos_query as $row) :
                            $user = get_userdata($row->user_id);
                            if (!$user) continue;
                            
                            $progress = raz_lms_get_course_progress($row->user_id, $curso_id);
                            $iniciais = strtoupper(substr($user->display_name, 0, 1));
                            $is_completed = $progress['percent'] >= 100;
                        ?>
                        <tr>
                            <td>
                                <div class="raz-user-info">
                                    <div class="raz-avatar-placeholder"><?php echo $iniciais; ?></div>
                                    <div class="u-bold"><?php echo esc_html($user->display_name); ?></div>
                                </div>
                            </td>
                            <td>
                                <div class="u-muted"><?php echo esc_html($user->user_email); ?></div>
                            </td>
                            <td style="text-align: center;">
                                <?php if ($is_completed) : ?>
                                    <span class="raz-badge raz-badge-success">
                                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                                        Concluído
                                    </span>
                                <?php else : ?>
                                    <span class="raz-badge raz-badge-warning">
                                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                        Em Curso
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="raz-progress-wrapper">
                                    <div class="raz-progress-track">
                                        <div class="raz-progress-fill <?php echo $is_completed ? 'completed' : ''; ?>" style="width: <?php echo $progress['percent']; ?>%;"></div>
                                    </div>
                                    <div style="text-align:right;">
                                        <div class="raz-progress-text"><?php echo $progress['percent']; ?>%</div>
                                    </div>
                                </div>
                                <div class="raz-progress-meta">
                                    <?php echo $progress['completed']; ?> de <?php echo $progress['total']; ?> aulas concluídas
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="raz-pagination">
                <?php 
                    echo paginate_links(array(
                        'base'      => add_query_arg('paged', '%#%'),
                        'format'    => '',
                        'prev_text' => '<svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin-right:4px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg> Anterior',
                        'next_text' => 'Próxima <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin-left:4px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>',
                        'total'     => $total_pages,
                        'current'   => $current_paged,
                        'type'      => 'plain',
                        'mid_size'  => 2
                    ));
                ?>
            </div>
        <?php endif; ?>

    <?php endif; ?>

</div>