<?php
/**
 * Admin: Avaliações das Aulas
 * Design: Premium UX/UI
 */
global $wpdb;

// 1. Definição de Parâmetros e Segurança
$curso_filter = isset($_GET['curso']) ? intval($_GET['curso']) : 0;
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

$current_page_slug = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : 'gestao-cursos';
$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'avaliacoes';

// 2. Busca de Avaliações
$ratings = array();
$meta_rows = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_lesson_rating_%'");

foreach ($meta_rows as $row) {
    $aula_id = str_replace('_raz_lesson_rating_', '', $row->meta_key);
    $aula = get_post($aula_id);
    if (!$aula) continue;
    
    $modulo = raz_lms_get_modulo_from_aula($aula_id);
    $curso = raz_lms_get_curso_from_aula($aula_id);
    
    if (!$curso) continue;
    if ($curso_filter && $curso->ID != $curso_filter) continue;
    
    $user = get_userdata($row->user_id);
    
    $ratings[] = array(
        'aula' => $aula,
        'modulo' => $modulo,
        'curso' => $curso,
        'user' => $user,
        'rating' => intval($row->meta_value)
    );
}

// 3. Estatísticas por aula
$stats = array();
foreach ($ratings as $r) {
    $aid = $r['aula']->ID;
    if (!isset($stats[$aid])) {
        $stats[$aid] = array('aula' => $r['aula'], 'curso' => $r['curso'], 'total' => 0, 'sum' => 0);
    }
    $stats[$aid]['total']++;
    $stats[$aid]['sum'] += $r['rating'];
}
foreach ($stats as $k => $s) {
    $stats[$k]['avg'] = $s['total'] > 0 ? round($s['sum'] / $s['total'], 1) : 0;
}

// 4. Configuração de Paginação (10 itens)
$per_page = 10;

// Bloco A: Atenção (avg <= 3)
$low_rated = array_filter($stats, function($s) { return $s['avg'] <= 3; });
usort($low_rated, function($a, $b) { return ($a['avg'] < $b['avg']) ? -1 : 1; });
$current_p_low = isset($_GET['p_low']) ? max(1, intval($_GET['p_low'])) : 1;
$total_p_low = max(1, ceil(count($low_rated) / $per_page));
$paged_low_rated = array_slice($low_rated, ($current_p_low - 1) * $per_page, $per_page);

// Bloco B: Bem Avaliadas (avg >= 4)
$high_rated = array_filter($stats, function($s) { return $s['avg'] >= 4; });
usort($high_rated, function($a, $b) { return ($b['avg'] > $a['avg']) ? -1 : 1; });
$current_p_high = isset($_GET['p_high']) ? max(1, intval($_GET['p_high'])) : 1;
$total_p_high = max(1, ceil(count($high_rated) / $per_page));
$paged_high_rated = array_slice($high_rated, ($current_p_high - 1) * $per_page, $per_page);

// Bloco C: Todas as Avaliações
$current_p_all = isset($_GET['p_all']) ? max(1, intval($_GET['p_all'])) : 1;
$total_p_all = max(1, ceil(count($ratings) / $per_page));
$paged_all_ratings = array_slice($ratings, ($current_p_all - 1) * $per_page, $per_page);
?>

<style>
    :root {
        --raz-primary: #0891b2;
        --raz-primary-hover: #0e7490;
        --raz-bg: #f8fafc;
        --raz-surface: #ffffff;
        --raz-border: #e2e8f0;
        --raz-text: #1e293b;
        --raz-text-muted: #64748b;
        --raz-text-light: #94a3b8;
        --raz-success-bg: #ecfdf5;
        --raz-success-text: #059669;
        --raz-danger-bg: #fef2f2;
        --raz-danger-text: #dc2626;
        --raz-warning-bg: #fffbeb;
        --raz-warning-text: #d97706;
        --raz-info-bg: #f0f9ff;
        --raz-info-text: #0284c7;
        --raz-radius: 8px;
        --raz-radius-lg: 12px;
        --raz-shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        --raz-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        --star-color: #fbbf24;
        --star-empty: #e2e8f0;
    }

    .raz-admin-container {
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        color: var(--raz-text);
        max-width: 1100px;
        margin: 20px auto 60px;
    }

    /* Headings */
    .raz-page-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 24px;
        padding-bottom: 16px;
        border-bottom: 1px solid var(--raz-border);
    }
    .raz-page-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--raz-text);
        margin: 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .raz-page-title svg { color: var(--raz-primary); }

    /* Cards */
    .raz-card {
        background: var(--raz-surface);
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        padding: 24px;
        box-shadow: var(--raz-shadow);
        margin-bottom: 32px;
    }

    /* Grid System */
    .raz-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
        gap: 24px;
        margin-bottom: 32px;
    }

    /* List Items (Stats) */
    .raz-stat-list { list-style: none; padding: 0; margin: 0; }
    .raz-stat-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 16px 0;
        border-bottom: 1px solid var(--raz-border);
        transition: var(--transition);
    }
    .raz-stat-item:last-child { border-bottom: none; }
    .raz-stat-item:hover { padding-left: 4px; padding-right: 4px; background: #fafafa; border-radius: 6px; }

    .raz-item-content { flex: 1; margin-right: 16px; }
    .raz-item-title { font-weight: 600; font-size: 14px; color: var(--raz-text); margin-bottom: 4px; }
    .raz-item-meta { font-size: 12px; color: var(--raz-text-muted); display: flex; align-items: center; gap: 6px; }
    
    .raz-score-badge {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        border-radius: 9999px;
        font-weight: 700;
        font-size: 13px;
    }
    .raz-score-badge svg { width: 14px; height: 14px; }
    
    .raz-score-high { background: var(--raz-success-bg); color: var(--raz-success-text); border: 1px solid rgba(16, 185, 129, 0.2); }
    .raz-score-low { background: var(--raz-danger-bg); color: var(--raz-danger-text); border: 1px solid rgba(239, 68, 68, 0.2); }

    /* Filter Bar */
    .raz-filter-bar { display: flex; align-items: flex-end; gap: 16px; }
    .raz-filter-item { flex: 1; }
    
    .raz-label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px; color: var(--raz-text); }
    .raz-input-wrapper { position: relative; }
    .raz-input-icon {
        position: absolute; left: 12px; top: 50%; transform: translateY(-50%);
        color: var(--raz-text-light); pointer-events: none;
    }
    .raz-select {
        width: 100%; padding: 10px 12px 10px 36px;
        border: 1px solid var(--raz-border); border-radius: var(--raz-radius);
        font-size: 14px; background: #fff;
        height: 42px; transition: var(--transition);
    }
    .raz-select:focus { border-color: var(--raz-primary); outline: none; box-shadow: 0 0 0 3px rgba(8, 145, 178, 0.15); }

    .raz-total-badge {
        background: var(--raz-info-bg); color: var(--raz-info-text);
        padding: 8px 16px; border-radius: 999px;
        font-weight: 600; font-size: 13px;
        border: 1px solid rgba(2, 132, 199, 0.2);
        display: flex; align-items: center; gap: 6px; height: 42px;
    }

    /* Table */
    .raz-table-wrapper {
        background: white;
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        overflow: hidden;
        box-shadow: var(--raz-shadow-sm);
    }
    .raz-table { width: 100%; border-collapse: collapse; }
    .raz-table th {
        background: #f8fafc; padding: 16px 24px; text-align: left;
        font-size: 12px; font-weight: 700; text-transform: uppercase;
        letter-spacing: 0.05em; color: var(--raz-text-muted);
        border-bottom: 1px solid var(--raz-border);
    }
    .raz-table td {
        padding: 16px 24px; border-bottom: 1px solid var(--raz-border);
        color: var(--raz-text); font-size: 14px; vertical-align: middle;
    }
    .raz-table tr:hover { background: #fbfbfc; }

    /* Stars */
    .raz-stars { display: flex; gap: 2px; }
    .raz-stars svg { width: 16px; height: 16px; fill: var(--star-empty); }
    .raz-stars svg.filled { fill: var(--star-color); }

    /* Pagination */
    .raz-pagination {
        display: flex; justify-content: center; align-items: center;
        gap: 12px; margin-top: 20px;
    }
    .raz-pagination-btn {
        display: flex; align-items: center; justify-content: center;
        padding: 6px 12px; border-radius: 6px;
        text-decoration: none; color: var(--raz-text);
        background: white; border: 1px solid var(--raz-border);
        font-size: 12px; font-weight: 500; transition: var(--transition);
    }
    .raz-pagination-btn:hover:not(.disabled) { border-color: var(--raz-primary); color: var(--raz-primary); }
    .raz-pagination-btn.disabled { opacity: 0.5; cursor: not-allowed; background: #f8fafc; }
    .raz-pagination-info { font-size: 12px; color: var(--raz-text-muted); font-weight: 500; }

    .section-header {
        display: flex; align-items: center; gap: 8px; margin-bottom: 20px;
        font-size: 16px; font-weight: 600; color: var(--raz-text);
    }

    .empty-state-mini { text-align: center; padding: 30px; color: var(--raz-text-muted); font-size: 13px; }
</style>

<div class="raz-admin-container">
    
    <div class="raz-page-header">
        <h2 class="raz-page-title">
            <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path></svg>
            Avaliações das Aulas
        </h2>
    </div>

    <div class="raz-card">
        <div class="raz-filter-bar">
            <div class="raz-filter-item">
                <form method="get">
                    <input type="hidden" name="page" value="<?php echo esc_attr($current_page_slug); ?>">
                    <input type="hidden" name="tab" value="<?php echo esc_attr($current_tab); ?>">
                    <label class="raz-label">Filtrar por Curso</label>
                    <div class="raz-input-wrapper">
                        <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                        <select name="curso" onchange="this.form.submit()" class="raz-select">
                            <option value="">Todos os cursos</option>
                            <?php foreach ($cursos as $c) : ?>
                            <option value="<?php echo $c->ID; ?>" <?php selected($curso_filter, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </form>
            </div>
            <div class="raz-total-badge">
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                <?php echo count($ratings); ?> Avaliações
            </div>
        </div>
    </div>

    <div class="raz-grid">
        <div class="raz-card">
            <div class="section-header" style="color: var(--raz-danger-text);">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                Atenção Necessária (Média ≤ 3.0)
            </div>
            
            <?php if (empty($paged_low_rated)) : ?>
                <div class="empty-state-mini">
                    <svg width="32" height="32" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--raz-success-text); margin-bottom:8px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    <p>Tudo ótimo! Nenhuma aula com baixa avaliação.</p>
                </div>
            <?php else : ?>
                <ul class="raz-stat-list">
                    <?php foreach ($paged_low_rated as $s) : ?>
                    <li class="raz-stat-item">
                        <div class="raz-item-content">
                            <div class="raz-item-title"><?php echo esc_html($s['aula']->post_title); ?></div>
                            <div class="raz-item-meta">
                                <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                                <?php echo esc_html($s['curso']->post_title); ?>
                            </div>
                        </div>
                        <div class="raz-score-badge raz-score-low">
                            <svg fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                            <?php echo $s['avg']; ?>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
                
                <div class="raz-pagination">
                    <a href="<?php echo add_query_arg('p_low', max(1, $current_p_low - 1)); ?>" class="raz-pagination-btn <?php echo $current_p_low == 1 ? 'disabled' : ''; ?>">←</a>
                    <span class="raz-pagination-info"><?php echo $current_p_low; ?> / <?php echo $total_p_low; ?></span>
                    <a href="<?php echo add_query_arg('p_low', min($total_p_low, $current_p_low + 1)); ?>" class="raz-pagination-btn <?php echo $current_p_low == $total_p_low ? 'disabled' : ''; ?>">→</a>
                </div>
            <?php endif; ?>
        </div>

        <div class="raz-card">
            <div class="section-header" style="color: var(--raz-success-text);">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path></svg>
                Melhores Avaliadas (Média ≥ 4.0)
            </div>

            <?php if (empty($paged_high_rated)) : ?>
                <div class="empty-state-mini">
                    <p>Ainda não há aulas com avaliações excelentes.</p>
                </div>
            <?php else : ?>
                <ul class="raz-stat-list">
                    <?php foreach ($paged_high_rated as $s) : ?>
                    <li class="raz-stat-item">
                        <div class="raz-item-content">
                            <div class="raz-item-title"><?php echo esc_html($s['aula']->post_title); ?></div>
                            <div class="raz-item-meta">
                                <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                                <?php echo esc_html($s['curso']->post_title); ?>
                            </div>
                        </div>
                        <div class="raz-score-badge raz-score-high">
                            <svg fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                            <?php echo $s['avg']; ?>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>

                <div class="raz-pagination">
                    <a href="<?php echo add_query_arg('p_high', max(1, $current_p_high - 1)); ?>" class="raz-pagination-btn <?php echo $current_p_high == 1 ? 'disabled' : ''; ?>">←</a>
                    <span class="raz-pagination-info"><?php echo $current_p_high; ?> / <?php echo $total_p_high; ?></span>
                    <a href="<?php echo add_query_arg('p_high', min($total_p_high, $current_p_high + 1)); ?>" class="raz-pagination-btn <?php echo $current_p_high == $total_p_high ? 'disabled' : ''; ?>">→</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="section-header">
        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path></svg>
        Histórico Completo
    </div>

    <?php if (empty($paged_all_ratings)) : ?>
        <div class="raz-card">
            <div class="empty-state-mini">
                <p>Nenhuma avaliação encontrada com os filtros atuais.</p>
            </div>
        </div>
    <?php else : ?>
        <div class="raz-table-wrapper">
            <table class="raz-table">
                <thead>
                    <tr>
                        <th width="30%">Aluno</th>
                        <th width="40%">Aula / Curso</th>
                        <th width="30%" style="text-align: center;">Nota</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($paged_all_ratings as $r) : ?>
                    <tr>
                        <td>
                            <div class="u-bold"><?php echo $r['user'] ? esc_html($r['user']->display_name) : 'Membro Inativo'; ?></div>
                            <div class="u-muted"><?php echo $r['user'] ? esc_html($r['user']->user_email) : ''; ?></div>
                        </td>
                        <td>
                            <div class="u-bold"><?php echo esc_html($r['aula']->post_title); ?></div>
                            <div class="u-muted" style="display:flex; align-items:center; gap:4px; font-size:12px;">
                                <svg width="10" height="10" fill="currentColor" viewBox="0 0 20 20"><path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z"></path></svg>
                                <?php echo esc_html($r['curso']->post_title); ?>
                            </div>
                        </td>
                        <td style="text-align: center;">
                            <div class="raz-stars" style="justify-content:center;">
                                <?php for ($i = 1; $i <= 5; $i++) : ?>
                                    <svg class="<?php echo $i <= $r['rating'] ? 'filled' : ''; ?>" viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
                                <?php endfor; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="raz-pagination">
            <a href="<?php echo add_query_arg('p_all', max(1, $current_p_all - 1)); ?>" class="raz-pagination-btn <?php echo $current_p_all == 1 ? 'disabled' : ''; ?>">← Anterior</a>
            <span class="raz-pagination-info">Página <strong><?php echo $current_p_all; ?></strong> de <?php echo $total_p_all; ?></span>
            <a href="<?php echo add_query_arg('p_all', min($total_p_all, $current_p_all + 1)); ?>" class="raz-pagination-btn <?php echo $current_p_all == $total_p_all ? 'disabled' : ''; ?>">Próxima →</a>
        </div>
    <?php endif; ?>

</div>