<?php
/**
 * Admin: Gerenciar Cursos
 * Design: Premium UX/UI
 */

// Ações de Exclusão (Mantido a lógica original de segurança)
if (isset($_GET['action']) && isset($_GET['curso_id'])) {
    $curso_id = intval($_GET['curso_id']);
    
    // Apenas processa se estiver no contexto admin ou se a URL for adaptada para frontend actions
    // Como estamos no frontend, a URL de trash precisa ser cuidadosamente gerada ou tratada via AJAX idealmente
    // Mas manteremos a lógica se ela já estiver funcionando via GET
    if ($_GET['action'] == 'trash' && check_admin_referer('trash_curso_' . $curso_id)) {
        wp_trash_post($curso_id);
        echo '<div class="raz-alert raz-alert-success"><div class="raz-alert-icon">✅</div><div class="raz-alert-content">Curso movido para a lixeira.</div></div>';
    }
}

// Buscar Cursos
$args = array(
    'post_type' => 'curso',
    'posts_per_page' => -1,
    'post_status' => array('publish', 'draft', 'private')
);
$cursos = get_posts($args);
?>

<style>
    :root {
        --raz-primary: #0891b2;
        --raz-primary-hover: #0e7490;
        --raz-bg: #f8fafc;
        --raz-surface: #ffffff;
        --raz-border: #e2e8f0;
        --raz-text: #1e293b;
        --raz-text-muted: #64748b;
        --raz-text-light: #94a3b8;
        --raz-success-bg: #ecfdf5;
        --raz-success-text: #059669;
        --raz-warning-bg: #fffbeb;
        --raz-warning-text: #d97706;
        --raz-danger-text: #dc2626;
        --raz-radius: 8px;
        --raz-radius-lg: 12px;
        --raz-shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        --raz-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .raz-admin-container {
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        color: var(--raz-text);
        max-width: 1200px;
        margin: 20px auto 60px;
    }

    /* Headings */
    .raz-page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 32px;
        padding-bottom: 20px;
        border-bottom: 1px solid var(--raz-border);
    }
    .raz-page-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--raz-text);
        margin: 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .raz-page-title svg { color: var(--raz-primary); }

    /* Alerts */
    .raz-alert {
        padding: 16px;
        border-radius: var(--raz-radius);
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 12px;
        background: var(--raz-success-bg);
        color: #064e3b;
        border: 1px solid rgba(16, 185, 129, 0.2);
        animation: slideIn 0.3s ease-out;
    }
    @keyframes slideIn { from { transform: translateY(-10px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

    /* Course Grid */
    .raz-course-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 24px;
    }

    /* Course Card */
    .raz-course-card {
        background: var(--raz-surface);
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        overflow: hidden;
        transition: var(--transition);
        display: flex;
        flex-direction: column;
        height: 100%;
        position: relative;
    }
    .raz-course-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--raz-shadow);
        border-color: #cbd5e1;
    }

    /* Card Image */
    .raz-card-thumb {
        height: 160px;
        background: #f1f5f9;
        position: relative;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .raz-card-thumb img { width: 100%; height: 100%; object-fit: cover; }
    .raz-card-thumb-placeholder { color: var(--raz-text-light); }
    
    .raz-status-badge {
        position: absolute;
        top: 12px;
        right: 12px;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        background: rgba(255, 255, 255, 0.95);
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        backdrop-filter: blur(4px);
    }
    .status-publish { color: var(--raz-success-text); }
    .status-draft { color: var(--raz-text-muted); }
    .status-private { color: var(--raz-warning-text); }

    /* Card Content */
    .raz-card-content { padding: 20px; flex: 1; display: flex; flex-direction: column; }
    
    .raz-card-title {
        font-size: 16px;
        font-weight: 700;
        color: var(--raz-text);
        margin: 0 0 12px 0;
        line-height: 1.4;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
    
    /* Novo Estilo de Meta (Linha única com bullets) */
    .raz-card-meta-line {
        font-size: 13px;
        color: var(--raz-text-muted);
        font-weight: 500;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 6px;
    }
    .raz-meta-bullet { color: var(--raz-border); font-size: 10px; }

    /* Card Actions */
    .raz-card-footer {
        padding: 16px 20px;
        background: #f8fafc;
        border-top: 1px solid var(--raz-border);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .raz-actions-group { display: flex; gap: 8px; }

    /* Buttons */
    .raz-btn {
        display: inline-flex; align-items: center; justify-content: center;
        padding: 10px 20px; font-size: 14px; font-weight: 600;
        border-radius: var(--raz-radius); cursor: pointer;
        border: 1px solid transparent; transition: var(--transition);
        text-decoration: none; gap: 8px;
    }
    .raz-btn-primary { background: var(--raz-primary); color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1); }
    .raz-btn-primary:hover { background: var(--raz-primary-hover); transform: translateY(-1px); }
    
    .raz-btn-icon {
        width: 32px; height: 32px;
        display: flex; align-items: center; justify-content: center;
        border-radius: 6px; color: var(--raz-text-muted);
        transition: var(--transition);
        text-decoration: none;
    }
    .raz-btn-icon:hover { background: #e2e8f0; color: var(--raz-text); }
    .raz-btn-icon.delete:hover { background: #fee2e2; color: var(--raz-danger-text); }
    .raz-btn-icon svg { width: 18px; height: 18px; }

    .raz-btn-sm {
        padding: 6px 12px;
        font-size: 13px;
        background: white;
        border: 1px solid var(--raz-border);
        color: var(--raz-text);
        border-radius: 6px;
    }
    .raz-btn-sm:hover { border-color: var(--raz-primary); color: var(--raz-primary); }

    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 80px 20px;
        color: var(--raz-text-muted);
        background: white;
        border-radius: var(--raz-radius-lg);
        border: 2px dashed var(--raz-border);
        grid-column: 1 / -1;
    }
    .empty-state svg { width: 48px; height: 48px; color: #cbd5e1; margin-bottom: 16px; }
</style>

<div class="raz-admin-container">
    
    <div class="raz-page-header">
        <h2 class="raz-page-title">
            <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
            Gerenciar Cursos
        </h2>
        <a href="<?php echo home_url('/gestao-cursos/curso-editar/'); ?>" class="raz-btn raz-btn-primary">
            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
            Criar Novo Curso
        </a>
    </div>

    <div class="raz-course-grid">
        <?php if (empty($cursos)) : ?>
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                <h3>Nenhum curso encontrado</h3>
                <p>Comece criando seu primeiro curso agora mesmo!</p>
                <a href="<?php echo home_url('/gestao-cursos/curso-editar/'); ?>" class="raz-btn raz-btn-primary" style="margin-top:20px;">Criar Curso</a>
            </div>
        <?php else : ?>
            <?php foreach ($cursos as $post) : 
                // 1. Contagem de Módulos (Vinculados a este curso)
                $modulos_query = get_posts(array(
                    'post_type' => 'modulo',
                    'meta_key' => '_raz_modulo_curso',
                    'meta_value' => $post->ID,
                    'posts_per_page' => -1,
                    'fields' => 'ids'
                ));
                $modulos_count = count($modulos_query);
                
                // 2. Contagem de Aulas (Vinculadas aos módulos deste curso)
                $aulas_count = 0;
                if ($modulos_count > 0) {
                    $aulas_query = new WP_Query(array(
                        'post_type' => 'aula',
                        'meta_query' => array(
                            array(
                                'key' => '_raz_aula_modulo',
                                'value' => $modulos_query,
                                'compare' => 'IN'
                            )
                        ),
                        'posts_per_page' => -1,
                        'fields' => 'ids'
                    ));
                    $aulas_count = $aulas_query->found_posts;
                }

                // 3. Contagem de Alunos
                global $wpdb;
                $alunos_count = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s",
                    '_raz_curso_acesso_' . $post->ID
                ));
                
                $thumb_url = get_the_post_thumbnail_url($post->ID, 'medium');
                $status = $post->post_status;
                $status_label = $status == 'publish' ? 'Publicado' : ($status == 'draft' ? 'Rascunho' : 'Privado');
                $status_class = 'status-' . $status;
                
                // URLs Corrigidas
                $course_link_frontend = get_permalink($post->ID);
                $course_edit_link = home_url('/gestao-cursos/curso-editar/' . $post->ID);
            ?>
                <div class="raz-course-card">
                    <div class="raz-card-thumb">
                        <?php if ($thumb_url) : ?>
                            <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php echo esc_attr($post->post_title); ?>">
                        <?php else : ?>
                            <div class="raz-card-thumb-placeholder">
                                <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                            </div>
                        <?php endif; ?>
                        <span class="raz-status-badge <?php echo $status_class; ?>"><?php echo $status_label; ?></span>
                    </div>
                    
                    <div class="raz-card-content">
                        <h3 class="raz-card-title"><?php echo esc_html($post->post_title); ?></h3>
                        
                        <div class="raz-card-meta-line">
                            <span><?php echo $modulos_count; ?> módulos</span>
                            <span class="raz-meta-bullet">•</span>
                            <span><?php echo $aulas_count; ?> aulas</span>
                            <span class="raz-meta-bullet">•</span>
                            <span><?php echo $alunos_count; ?> alunos</span>
                        </div>
                    </div>
                    
                    <div class="raz-card-footer">
                        <a href="<?php echo esc_url($course_edit_link); ?>" class="raz-btn-sm" style="text-decoration:none;">
                            Editar Conteúdo
                        </a>
                        
                        <div class="raz-actions-group">
                            <a href="<?php echo esc_url($course_link_frontend); ?>" target="_blank" class="raz-btn-icon" title="Ver no Site">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                            </a>
                            
                            <?php $trash_url = wp_nonce_url(admin_url('admin.php?page=gestao-cursos&tab=cursos&action=trash&curso_id=' . $post->ID), 'trash_curso_' . $post->ID); ?>
                            <a href="<?php echo $trash_url; ?>" class="raz-btn-icon delete" title="Excluir Curso" onclick="return confirm('Tem certeza que deseja mover este curso para a lixeira?');">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>