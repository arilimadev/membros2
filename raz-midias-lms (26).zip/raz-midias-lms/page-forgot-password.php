<?php
/**
 * Template Name: Esqueci a Senha
 * @package RazMidiasLMS
 */

// Se já está logado, redireciona
if (is_user_logged_in()) {
    wp_redirect(home_url('/meus-cursos/'));
    exit;
}

// Configurações visuais (mesmas do login)
$login_logo = get_option('raz_lms_login_logo', '');
$login_bg_color = get_option('raz_lms_login_bg_color', '#667eea');
$login_btn_color = get_option('raz_lms_login_btn_color', '#4f46e5');

// Fallbacks
if (empty($login_bg_color)) $login_bg_color = '#667eea';
if (empty($login_btn_color)) $login_btn_color = '#4f46e5';

$message = '';
$error = '';

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_login'])) {
    $user_login = sanitize_text_field($_POST['user_login']);
    $user = get_user_by('email', $user_login);
    
    if (!$user) {
        $user = get_user_by('login', $user_login);
    }
    
    if (!$user) {
        $error = 'Usuário ou e-mail não encontrado.';
    } else {
        // Gerar chave de recuperação
        $key = get_password_reset_key($user);
        if (is_wp_error($key)) {
            $error = 'Erro ao gerar chave de recuperação. Tente novamente.';
        } else {
            // Enviar e-mail (função nativa do WP)
            $message_email = __('Alguém solicitou a redefinição de senha para a seguinte conta:') . "\r\n\r\n";
            $message_email .= network_home_url('/') . "\r\n\r\n";
            $message_email .= sprintf(__('Nome de usuário: %s'), $user->user_login) . "\r\n\r\n";
            $message_email .= __('Se foi um erro, ignore este e-mail e nada acontecerá.') . "\r\n\r\n";
            $message_email .= __('Para redefinir sua senha, visite o seguinte endereço:') . "\r\n\r\n";
            $message_email .= network_site_url("wp-login.php?action=rp&key=$key&login=" . rawurlencode($user->user_login), 'login') . "\r\n";

            if (wp_mail($user->user_email, 'Redefinição de Senha', $message_email)) {
                $message = 'Verifique seu e-mail para redefinir a senha.';
            } else {
                $error = 'O e-mail não pôde ser enviado. Entre em contato com o suporte.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Recuperar Senha - <?php bloginfo('name'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
    <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
        font-family: 'Inter', -apple-system, sans-serif;
        min-height: 100vh;
        display: flex;
        /* ALTERAÇÃO AQUI: Gradiente removido, usa apenas a cor do banco de dados */
        background: <?php echo esc_attr($login_bg_color); ?>;
    }
    .login-container {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    .login-box {
        background: #fff;
        border-radius: 24px;
        padding: 40px 32px;
        width: 100%;
        max-width: 400px;
        box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
    }
    .login-logo {
        text-align: center;
        margin-bottom: 32px;
        width: 100%;
    }
    .login-logo img {
        max-height: 80px;
        max-width: 200px;
        margin: 0 auto;
        display: block;
    }
    .login-logo h1 {
        font-size: 24px;
        font-weight: 700;
        color: #1e293b;
    }
    .login-title {
        text-align: center;
        margin-bottom: 12px;
        font-size: 20px;
        font-weight: 600;
        color: #1e293b;
    }
    .login-subtitle {
        text-align: center;
        margin-bottom: 24px;
        font-size: 14px;
        color: #64748b;
        line-height: 1.5;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        margin-bottom: 6px;
        font-weight: 500;
        font-size: 14px;
        color: #374151;
    }
    .form-group input[type="text"],
    .form-group input[type="email"] {
        width: 100%;
        padding: 14px 16px;
        border: 2px solid #e5e7eb;
        border-radius: 10px;
        font-size: 15px;
        transition: border-color 0.15s;
        font-family: inherit;
    }
    .form-group input:focus {
        outline: none;
        border-color: <?php echo esc_attr($login_btn_color); ?>;
    }
    .btn-login {
        width: 100%;
        padding: 14px;
        background: <?php echo esc_attr($login_btn_color); ?>;
        color: #fff;
        border: none;
        border-radius: 10px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: opacity 0.15s, transform 0.15s;
        font-family: inherit;
    }
    .btn-login:hover {
        opacity: 0.9;
    }
    .btn-login:active {
        transform: scale(0.98);
    }
    .error-message {
        background: #fef2f2;
        color: #dc2626;
        padding: 12px 16px;
        border-radius: 8px;
        margin-bottom: 20px;
        font-size: 14px;
        text-align: center;
    }
    .success-message {
        background: #ecfdf5;
        color: #059669;
        padding: 12px 16px;
        border-radius: 8px;
        margin-bottom: 20px;
        font-size: 14px;
        text-align: center;
    }
    .login-footer {
        text-align: center;
        margin-top: 24px;
        font-size: 14px;
        color: #64748b;
    }
    .login-footer a {
        color: <?php echo esc_attr($login_btn_color); ?>;
        text-decoration: none;
        font-weight: 500;
    }
    
    @media (max-width: 480px) {
        .login-box {
            padding: 32px 24px;
            border-radius: 16px;
        }
    }
    </style>
</head>
<body>

<div class="login-container">
    <div class="login-box">
        <div class="login-logo">
            <?php if ($login_logo) : ?>
                <img src="<?php echo esc_url($login_logo); ?>" alt="<?php bloginfo('name'); ?>">
            <?php else : ?>
                <h1><?php bloginfo('name'); ?></h1>
            <?php endif; ?>
        </div>
        
        <h2 class="login-title">Recuperar Senha</h2>
        <p class="login-subtitle">Digite seu e-mail abaixo e enviaremos um link para redefinir sua senha.</p>
        
        <?php if ($error) : ?>
            <div class="error-message"><?php echo esc_html($error); ?></div>
        <?php endif; ?>

        <?php if ($message) : ?>
            <div class="success-message"><?php echo esc_html($message); ?></div>
        <?php endif; ?>
        
        <form method="post">
            <div class="form-group">
                <label>Email ou Usuário</label>
                <input type="text" name="user_login" required autofocus>
            </div>
            
            <button type="submit" class="btn-login">Enviar Link</button>
        </form>
        
        <div class="login-footer">
            <a href="<?php echo home_url('/login'); ?>">← Voltar para Login</a>
        </div>
    </div>
</div>

<?php wp_footer(); ?>
</body>
</html>