<?php
/**
 * Componente: Gerenciamento de Grupos do Aluno
 * Inserir na página de edição de aluno
 * 
 * @package RazMidiasLMS
 * @version 2.0.0
 */

defined('ABSPATH') || exit;

/**
 * Renderiza resumo visual dos acessos do aluno
 * 
 * @param int $user_id ID do usuário
 */
function raz_render_aluno_acesso_resumo($user_id) {
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos) || empty($user_grupos_cursos)) {
        ?>
        <div style="padding: 20px; background: #fef3c7; border: 1px solid #fde68a; border-radius: 8px; margin-bottom: 20px;">
            <p style="margin: 0; color: #92400e; font-size: 14px; display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 20px;">⚠️</span>
                <strong>Este aluno não possui acesso a nenhum curso ou módulo.</strong>
            </p>
        </div>
        <?php
        return;
    }
    
    $total_cursos = 0;
    $total_modulos = 0;
    
    foreach ($user_grupos_cursos as $curso_key => $grupos) {
        if (empty($grupos)) continue;
        
        $curso_id = intval(str_replace('curso_', '', $curso_key));
        
        // Verifica se curso ainda existe
        if (get_post_status($curso_id) !== 'publish') continue;
        
        $total_cursos++;
        
        $modulos_acessiveis = raz_get_user_accessible_modulos($user_id, $curso_id);
        $total_modulos += count($modulos_acessiveis);
    }
    ?>
    
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 20px;">
        <div style="padding: 20px; background: linear-gradient(135deg, #dbeafe 0%, #bae6fd 100%); border: 1px solid #7dd3fc; border-radius: 8px; text-align: center;">
            <div style="font-size: 36px; font-weight: 700; color: #0369a1; margin-bottom: 4px;">
                <?php echo $total_cursos; ?>
            </div>
            <div style="font-size: 13px; color: #075985; font-weight: 500;">
                Curso<?php echo $total_cursos !== 1 ? 's' : ''; ?> com Acesso
            </div>
        </div>
        
        <div style="padding: 20px; background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%); border: 1px solid #6ee7b7; border-radius: 8px; text-align: center;">
            <div style="font-size: 36px; font-weight: 700; color: #059669; margin-bottom: 4px;">
                <?php echo $total_modulos; ?>
            </div>
            <div style="font-size: 13px; color: #047857; font-weight: 500;">
                Módulo<?php echo $total_modulos !== 1 ? 's' : ''; ?> Liberado<?php echo $total_modulos !== 1 ? 's' : ''; ?>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Renderiza seção completa de gerenciamento de grupos do aluno
 * 
 * @param int $user_id ID do usuário
 */
function raz_render_aluno_grupos_section($user_id) {
    // Busca todos os cursos publicados
    $cursos = get_posts([
        'post_type' => 'curso',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
        'post_status' => 'publish'
    ]);
    
    // Busca grupos atuais do aluno
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    if (!is_array($user_grupos_cursos)) {
        $user_grupos_cursos = [];
    }
    ?>
    
    <div class="form-card raz-aluno-grupos-container" style="margin-top: 20px;">
        <div style="margin-bottom: 20px;">
            <h3 style="margin: 0; font-size: 18px; color: #1e293b; display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 24px;">🔐</span>
                Grupos de Acesso
            </h3>
            <p style="margin: 4px 0 0 32px; font-size: 13px; color: #64748b;">
                Defina a quais grupos este aluno pertence em cada curso
            </p>
        </div>
        
        <?php if (empty($cursos)): ?>
            <div style="padding: 40px; text-align: center; background: #f8fafc; border-radius: 8px; border: 1px dashed #cbd5e1;">
                <p style="color: #94a3b8; margin: 0;">
                    Nenhum curso cadastrado ainda.
                </p>
            </div>
        <?php else: ?>
            <div class="aluno-grupos-list">
                <?php foreach ($cursos as $curso): 
                    $curso_id = $curso->ID;
                    $curso_key = 'curso_' . $curso_id;
                    $grupos_config = raz_get_curso_grupos_config($curso_id);
                    $user_grupos = isset($user_grupos_cursos[$curso_key]) && is_array($user_grupos_cursos[$curso_key]) 
                        ? $user_grupos_cursos[$curso_key] 
                        : [];
                    
                    // Conta módulos disponíveis
                    $total_modulos = 0;
                    foreach ($grupos_config as $grupo_data) {
                        if (isset($grupo_data['modulos'])) {
                            $total_modulos = max($total_modulos, count($grupo_data['modulos']));
                        }
                    }
                ?>
                    <div class="curso-grupos-card" style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-bottom: 16px; background: #fafafa;">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 12px;">
                            <div style="flex: 1;">
                                <h4 style="margin: 0; font-size: 15px; color: #1e293b; display: flex; align-items: center; gap: 8px;">
                                    <span style="font-size: 18px;">📚</span>
                                    <?php echo esc_html($curso->post_title); ?>
                                </h4>
                                <div style="margin-top: 4px; font-size: 12px; color: #64748b;">
                                    <?php 
                                    $grupos_ativos = count($user_grupos);
                                    echo $grupos_ativos . ' grupo' . ($grupos_ativos !== 1 ? 's' : '') . ' ativo' . ($grupos_ativos !== 1 ? 's' : '');
                                    
                                    if ($total_modulos > 0) {
                                        echo ' • ' . $total_modulos . ' módulo' . ($total_modulos !== 1 ? 's' : '') . ' disponível' . ($total_modulos !== 1 ? 'eis' : '');
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        
                        <?php if (empty($grupos_config)): ?>
                            <p style="color: #94a3b8; font-size: 13px; margin: 0; padding: 12px; background: #fff; border-radius: 4px; border: 1px dashed #e2e8f0;">
                                <em>Este curso não possui grupos configurados</em>
                            </p>
                        <?php else: ?>
                            <div class="grupos-checkboxes" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px;">
                                <?php foreach ($grupos_config as $grupo_slug => $grupo_data): 
                                    $is_checked = in_array($grupo_slug, $user_grupos);
                                    $is_default = isset($grupo_data['is_default']) && $grupo_data['is_default'];
                                    $modulos_count = isset($grupo_data['modulos']) ? count($grupo_data['modulos']) : 0;
                                ?>
                                    <label class="grupo-checkbox-item" 
                                           data-curso="<?php echo $curso_id; ?>"
                                           data-grupo="<?php echo esc_attr($grupo_slug); ?>"
                                           style="display: flex; align-items: start; padding: 12px; background: <?php echo $is_checked ? '#eff6ff' : '#fff'; ?>; border: 2px solid <?php echo $is_checked ? '#0284c7' : '#e2e8f0'; ?>; border-radius: 6px; cursor: pointer; transition: all 0.2s;">
                                        <input 
                                            type="checkbox" 
                                            name="user_grupos[<?php echo $curso_id; ?>][]" 
                                            value="<?php echo esc_attr($grupo_slug); ?>"
                                            <?php checked($is_checked); ?>
                                            style="margin: 2px 10px 0 0; width: 18px; height: 18px; flex-shrink: 0; cursor: pointer;"
                                            onchange="razUpdateGrupoCheckbox(this)"
                                        >
                                        <div style="flex: 1; min-width: 0;">
                                            <div style="font-weight: 500; font-size: 13px; color: #1e293b; margin-bottom: 2px; display: flex; align-items: center; gap: 4px; flex-wrap: wrap;">
                                                <span style="overflow: hidden; text-overflow: ellipsis;"><?php echo esc_html($grupo_data['nome']); ?></span>
                                                <?php if ($is_default): ?>
                                                    <span style="background: #fef3c7; color: #92400e; padding: 2px 6px; border-radius: 3px; font-size: 10px; font-weight: 600; white-space: nowrap;">★ PADRÃO</span>
                                                <?php endif; ?>
                                            </div>
                                            <div style="font-size: 11px; color: #64748b;">
                                                <?php echo $modulos_count; ?> módulo<?php echo $modulos_count !== 1 ? 's' : ''; ?>
                                            </div>
                                        </div>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div style="margin-top: 20px; padding: 12px; background: #eff6ff; border: 1px solid #bae6fd; border-radius: 6px;">
                <p style="margin: 0; font-size: 13px; color: #0369a1;">
                    <strong>💡 Dica:</strong> O aluno terá acesso a todos os módulos dos grupos marcados. Marque múltiplos grupos para dar acesso combinado.
                </p>
            </div>
        <?php endif; ?>
    </div>
    
    <style>
    .raz-aluno-grupos-container .grupo-checkbox-item:hover {
        border-color: #cbd5e1;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    
    .raz-aluno-grupos-container .grupo-checkbox-item input:checked ~ div {
        color: #0369a1;
    }
    </style>
    
    <script>
    function razUpdateGrupoCheckbox(checkbox) {
        const label = checkbox.closest('.grupo-checkbox-item');
        if (!label) return;
        
        if (checkbox.checked) {
            label.style.borderColor = '#0284c7';
            label.style.background = '#eff6ff';
        } else {
            label.style.borderColor = '#e2e8f0';
            label.style.background = '#fff';
        }
    }
    
    // Inicializa checkboxes ao carregar
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.grupo-checkbox-item input[type="checkbox"]').forEach(function(checkbox) {
            razUpdateGrupoCheckbox(checkbox);
        });
    });
    </script>
    <?php
}

/**
 * Widget compacto de resumo para usar em listas
 * 
 * @param int $user_id ID do usuário
 * @return string HTML do widget
 */
function raz_get_aluno_grupos_widget($user_id) {
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos) || empty($user_grupos_cursos)) {
        return '<span style="color: #94a3b8; font-size: 12px;">Sem acesso</span>';
    }
    
    $total_cursos = count(array_filter($user_grupos_cursos, function($grupos) {
        return !empty($grupos);
    }));
    
    $output = '<div style="display: flex; gap: 8px; align-items: center; font-size: 12px;">';
    $output .= '<span style="background: #dbeafe; color: #0369a1; padding: 4px 8px; border-radius: 4px; font-weight: 500;">';
    $output .= $total_cursos . ' curso' . ($total_cursos !== 1 ? 's' : '');
    $output .= '</span>';
    $output .= '</div>';
    
    return $output;
}

/**
 * NOTA: A função raz_save_aluno_grupos() está em access-groups-v2.php
 * para evitar duplicação
 */