<?php
/**
 * Componente: Gerenciamento de Grupos de Acesso do Curso
 * Inserir na aba "Conteúdo" do curso-editar.php
 * * @package RazMidiasLMS
 * @version 2.0.1
 */

defined('ABSPATH') || exit;

// Variáveis necessárias (devem existir no contexto do curso-editar.php)
$curso_id = isset($raz_item_id) ? intval($raz_item_id) : 0;

if (!$curso_id) {
    echo '<div class="notice notice-error"><p>ID do curso não encontrado.</p></div>';
    return;
}

// Busca módulos do curso
if (function_exists('raz_lms_get_modulos')) {
    $modulos = raz_lms_get_modulos($curso_id);
} else {
    // Fallback: busca direto
    $modulos = get_posts([
        'post_type' => 'modulo',
        'posts_per_page' => -1,
        'meta_key' => '_raz_modulo_curso', // CORRIGIDO: chave correta do tema
        'meta_value' => $curso_id,
        'orderby' => 'menu_order',
        'order' => 'ASC'
    ]);
}

// Busca configuração de grupos
$grupos_config = raz_get_curso_grupos_config($curso_id);

// Prepara dados dos módulos para JavaScript
$modulos_data = [];
foreach ($modulos as $modulo) {
    // Conta aulas do módulo
    $aulas_count = 0;
    
    // CORRIGIDO: Usa a função correta do tema 'raz_lms_get_aulas'
    if (function_exists('raz_lms_get_aulas')) {
        $aulas = raz_lms_get_aulas($modulo->ID);
        $aulas_count = count($aulas);
    } else {
        // Fallback com a chave correta
        $aulas = get_posts([
            'post_type' => 'aula',
            'posts_per_page' => -1,
            'meta_key' => '_raz_aula_modulo', // CORRIGIDO: chave correta do tema
            'meta_value' => $modulo->ID
        ]);
        $aulas_count = count($aulas);
    }
    
    $modulos_data[] = [
        'id' => $modulo->ID,
        'nome' => $modulo->post_title,
        'aulas' => $aulas_count
    ];
}
?>

<div class="form-card raz-grupos-container" style="margin-top: 30px;">
    <div class="raz-grupos-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div>
            <h3 style="margin: 0; font-size: 18px; color: #1e293b; display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 24px;">🔐</span>
                Grupos de Acesso
            </h3>
            <p style="margin: 4px 0 0 32px; font-size: 13px; color: #64748b;">
                Configure quais módulos cada grupo de usuários pode acessar
            </p>
        </div>
        <button type="button" class="btn btn-primary" onclick="razAddGrupo()">
            <span style="font-size: 16px;">+</span> Novo Grupo
        </button>
    </div>

    <?php if (empty($modulos)): ?>
        <div style="padding: 40px; text-align: center; background: #fef3c7; border: 1px solid #fde68a; border-radius: 8px;">
            <p style="color: #92400e; margin: 0; font-size: 14px;">
                <strong>⚠️ Atenção:</strong> Crie alguns módulos primeiro antes de configurar os grupos de acesso.
            </p>
        </div>
    <?php else: ?>
        <div id="grupos-container">
            </div>

        <div id="grupos-empty" style="display: none; padding: 40px; text-align: center; background: #f8fafc; border-radius: 8px; border: 1px dashed #cbd5e1;">
            <p style="color: #94a3b8; margin: 0;">
                Nenhum grupo configurado. Clique em "+ Novo Grupo" para começar.
            </p>
        </div>
    <?php endif; ?>
</div>

<style>
.raz-grupos-container .grupo-card {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    margin-bottom: 16px;
    overflow: hidden;
    transition: box-shadow 0.2s;
}

.raz-grupos-container .grupo-card:hover {
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.raz-grupos-container .grupo-header {
    background: #f8fafc;
    padding: 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    border-bottom: 1px solid #e2e8f0;
    transition: background 0.2s;
}

.raz-grupos-container .grupo-header:hover {
    background: #f1f5f9;
}

.raz-grupos-container .grupo-title {
    display: flex;
    align-items: center;
    gap: 12px;
    flex: 1;
}

.raz-grupos-container .grupo-title input {
    font-size: 15px;
    font-weight: 600;
    color: #1e293b;
    border: none;
    background: transparent;
    padding: 6px 10px;
    border-radius: 4px;
    min-width: 200px;
    transition: all 0.2s;
}

.raz-grupos-container .grupo-title input:hover {
    background: rgba(255,255,255,0.5);
}

.raz-grupos-container .grupo-title input:focus {
    background: #fff;
    outline: 2px solid #0284c7;
    outline-offset: -2px;
}

.raz-grupos-container .grupo-badge {
    background: #dbeafe;
    color: #0369a1;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
}

.raz-grupos-container .grupo-badge.default {
    background: #fef3c7;
    color: #92400e;
}

.raz-grupos-container .grupo-actions {
    display: flex;
    gap: 8px;
}

.raz-grupos-container .grupo-content {
    padding: 20px;
    display: none;
}

.raz-grupos-container .grupo-content.active {
    display: block;
}

.raz-grupos-container .modulos-checkboxes {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 12px;
}

.raz-grupos-container .modulo-checkbox {
    display: flex;
    align-items: center;
    padding: 12px;
    background: #f8fafc;
    border: 2px solid #e2e8f0;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s;
}

.raz-grupos-container .modulo-checkbox:hover {
    background: #f1f5f9;
    border-color: #cbd5e1;
}

.raz-grupos-container .modulo-checkbox.checked {
    background: #dbeafe;
    border-color: #0284c7;
}

.raz-grupos-container .modulo-checkbox input[type="checkbox"] {
    margin: 0 12px 0 0;
    width: 18px;
    height: 18px;
    cursor: pointer;
    flex-shrink: 0;
}

.raz-grupos-container .modulo-info {
    flex: 1;
    min-width: 0;
}

.raz-grupos-container .modulo-name {
    font-weight: 500;
    color: #1e293b;
    font-size: 14px;
    margin-bottom: 2px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.raz-grupos-container .modulo-count {
    font-size: 12px;
    color: #64748b;
}
</style>

<script>
(function() {
    // Dados iniciais
    let gruposData = <?php echo json_encode($grupos_config); ?>;
    const modulosData = <?php echo json_encode($modulos_data); ?>;
    const cursoId = <?php echo $curso_id; ?>;
    const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
    const nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';
    
    let saveTimeout = null;

    // Inicializa
    document.addEventListener('DOMContentLoaded', function() {
        razRenderGrupos();
    });

    /**
     * Adiciona novo grupo
     */
    window.razAddGrupo = function() {
        const timestamp = Date.now();
        const slug = 'grupo_' + timestamp;
        const nome = 'Novo Grupo';
        
        gruposData[slug] = {
            nome: nome,
            modulos: [],
            is_default: Object.keys(gruposData).length === 0 // Primeiro grupo é padrão
        };
        
        razRenderGrupos();
        razShowToast('Grupo adicionado! Configure e salve.', 'success');
        
        // Auto-save
        razScheduleSave();
    };

    /**
     * Remove grupo
     */
    window.razRemoveGrupo = function(slug) {
        if (!confirm('Tem certeza que deseja remover este grupo?\n\nUsuários que pertencem a este grupo perderão o acesso.')) {
            return;
        }
        
        delete gruposData[slug];
        razRenderGrupos();
        razSaveGrupos();
        razShowToast('Grupo removido!', 'info');
    };

    /**
     * Define grupo como padrão
     */
    window.razToggleGrupoDefault = function(slug) {
        // Remove default de todos
        Object.keys(gruposData).forEach(key => {
            gruposData[key].is_default = false;
        });
        
        // Define o novo default
        gruposData[slug].is_default = true;
        
        razRenderGrupos();
        razSaveGrupos();
        razShowToast('Grupo padrão atualizado!', 'success');
    };

    /**
     * Atualiza nome do grupo
     */
    window.razUpdateGrupoNome = function(slug, nome) {
        if (gruposData[slug]) {
            gruposData[slug].nome = nome.trim() || 'Sem nome';
            razScheduleSave();
        }
    };

    /**
     * Toggle módulo no grupo
     */
    window.razToggleModulo = function(slug, moduloId) {
        if (!gruposData[slug]) return;
        
        if (!gruposData[slug].modulos) {
            gruposData[slug].modulos = [];
        }
        
        const index = gruposData[slug].modulos.indexOf(moduloId);
        
        if (index > -1) {
            gruposData[slug].modulos.splice(index, 1);
        } else {
            gruposData[slug].modulos.push(moduloId);
        }
        
        // Atualiza visual imediatamente
        const checkbox = document.querySelector(`[data-grupo="${slug}"][data-modulo="${moduloId}"]`);
        if (checkbox) {
            const label = checkbox.closest('.modulo-checkbox');
            if (index > -1) {
                label.classList.remove('checked');
                checkbox.checked = false;
            } else {
                label.classList.add('checked');
                checkbox.checked = true;
            }
            
            // Atualiza contador
            const badge = document.querySelector(`#grupo-badge-${slug}`);
            if (badge) {
                const count = gruposData[slug].modulos.length;
                badge.textContent = count + ' módulo' + (count !== 1 ? 's' : '');
            }
        }
        
        razScheduleSave();
    };

    /**
     * Toggle conteúdo do grupo
     */
    window.razToggleGrupoContent = function(slug) {
        const content = document.getElementById('grupo-content-' + slug);
        if (content) {
            content.classList.toggle('active');
        }
    };

    /**
     * Renderiza todos os grupos
     */
    function razRenderGrupos() {
        const container = document.getElementById('grupos-container');
        const empty = document.getElementById('grupos-empty');
        
        if (!container) return;
        
        if (Object.keys(gruposData).length === 0) {
            container.innerHTML = '';
            if (empty) empty.style.display = 'block';
            return;
        }
        
        if (empty) empty.style.display = 'none';
        container.innerHTML = '';
        
        Object.entries(gruposData).forEach(([slug, data]) => {
            container.insertAdjacentHTML('beforeend', razRenderGrupoCard(slug, data));
        });
    }

    /**
     * Renderiza card de um grupo
     */
    function razRenderGrupoCard(slug, data) {
        const isDefault = data.is_default || false;
        const modulosSelecionados = data.modulos || [];
        const modulosCount = modulosSelecionados.length;
        
        let modulosHtml = '';
        modulosData.forEach(modulo => {
            const checked = modulosSelecionados.includes(modulo.id);
            modulosHtml += `
                <label class="modulo-checkbox ${checked ? 'checked' : ''}" onclick="razToggleModulo('${slug}', ${modulo.id})">
                    <input 
                        type="checkbox" 
                        ${checked ? 'checked' : ''} 
                        onclick="event.stopPropagation()"
                        data-grupo="${slug}"
                        data-modulo="${modulo.id}"
                    >
                    <div class="modulo-info">
                        <div class="modulo-name">${escapeHtml(modulo.nome)}</div>
                        <div class="modulo-count">${modulo.aulas} aula${modulo.aulas !== 1 ? 's' : ''}</div>
                    </div>
                </label>
            `;
        });
        
        return `
            <div class="grupo-card" data-grupo="${slug}">
                <div class="grupo-header" onclick="razToggleGrupoContent('${slug}')">
                    <div class="grupo-title">
                        <input 
                            type="text" 
                            value="${escapeHtml(data.nome)}" 
                            onclick="event.stopPropagation()" 
                            onblur="razUpdateGrupoNome('${slug}', this.value)"
                            onkeypress="if(event.key==='Enter'){this.blur();}"
                            placeholder="Nome do grupo"
                        >
                        ${isDefault ? '<span class="grupo-badge default">★ PADRÃO</span>' : ''}
                        <span class="grupo-badge" id="grupo-badge-${slug}">${modulosCount} módulo${modulosCount !== 1 ? 's' : ''}</span>
                    </div>
                    <div class="grupo-actions" onclick="event.stopPropagation()">
                        ${!isDefault ? `<button type="button" class="btn btn-warning" onclick="razToggleGrupoDefault('${slug}')" title="Definir como padrão">★ Tornar Padrão</button>` : ''}
                        <button type="button" class="btn btn-danger" onclick="razRemoveGrupo('${slug}')">🗑️ Excluir</button>
                    </div>
                </div>
                <div id="grupo-content-${slug}" class="grupo-content">
                    <h4 style="margin: 0 0 16px 0; font-size: 14px; color: #64748b; font-weight: 500;">
                        📚 Selecione os módulos que este grupo pode acessar:
                    </h4>
                    ${modulosData.length > 0 ? `
                        <div class="modulos-checkboxes">
                            ${modulosHtml}
                        </div>
                    ` : '<p style="color: #94a3b8; font-style: italic;">Nenhum módulo disponível</p>'}
                </div>
            </div>
        `;
    }

    /**
     * Agenda salvamento (debounce)
     */
    function razScheduleSave() {
        if (saveTimeout) {
            clearTimeout(saveTimeout);
        }
        
        saveTimeout = setTimeout(function() {
            razSaveGrupos();
        }, 1000);
    }

    /**
     * Salva grupos via AJAX
     */
    function razSaveGrupos() {
        const data = new FormData();
        data.append('action', 'raz_save_curso_grupos');
        data.append('nonce', nonce);
        data.append('curso_id', cursoId);
        data.append('grupos', JSON.stringify(gruposData));
        
        fetch(ajaxUrl, {
            method: 'POST',
            body: data
        })
        .then(res => res.json())
        .then(result => {
            if (result.success) {
                console.log('✅ Grupos salvos');
            } else {
                console.error('❌ Erro:', result.data?.message || 'Erro desconhecido');
                razShowToast('Erro ao salvar grupos', 'error');
            }
        })
        .catch(err => {
            console.error('❌ Erro de rede:', err);
            razShowToast('Erro de comunicação', 'error');
        });
    }

    /**
     * Escape HTML
     */
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Toast notification (usa sistema existente ou cria simples)
     */
    function razShowToast(message, type) {
        // Tenta usar toast existente do tema
        if (typeof window.razShowToast === 'function') {
            return;
        }
        
        // Fallback simples
        console.log(`[${type.toUpperCase()}] ${message}`);
        
        const toast = document.createElement('div');
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 20px;
            background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
            color: white;
            border-radius: 6px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
})();
</script>

<style>
@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes slideOut {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(100%);
        opacity: 0;
    }
}
</style>