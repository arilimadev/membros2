<?php

/**
 * Kiwify Webhook Handler - Integração com Kiwify
 * Versão robusta para hospedagem compartilhada
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * Registrar endpoint do webhook via REST API
 */
function raz_lms_register_kiwify_webhook()
{
    register_rest_route('raz-lms/v1', '/kiwify', array(
        'methods' => array('POST', 'GET'),
        'callback' => 'raz_lms_handle_kiwify_webhook_rest',
        'permission_callback' => '__return_true'
    ));
}
add_action('rest_api_init', 'raz_lms_register_kiwify_webhook');

/**
 * Registrar query var para webhook alternativo
 */
function raz_lms_kiwify_query_vars($vars)
{
    $vars[] = 'raz_kiwify_webhook';
    return $vars;
}
add_filter('query_vars', 'raz_lms_kiwify_query_vars');

/**
 * Interceptar webhook via template_redirect (método alternativo)
 */
function raz_lms_kiwify_intercept()
{
    // Verificar se é uma requisição para o webhook
    $request_uri = $_SERVER['REQUEST_URI'] ?? '';

    // Múltiplas URLs possíveis
    $webhook_paths = array(
        '/wp-json/raz-lms/v1/kiwify',
        '/index.php?rest_route=/raz-lms/v1/kiwify',
        '/?raz_kiwify_webhook=1',
        '/webhook-kiwify'
    );

    $is_webhook = false;
    foreach ($webhook_paths as $path) {
        if (strpos($request_uri, $path) !== false) {
            $is_webhook = true;
            break;
        }
    }

    // Também verificar query var
    if (isset($_GET['raz_kiwify_webhook']) || get_query_var('raz_kiwify_webhook')) {
        $is_webhook = true;
    }

    if ($is_webhook) {
        raz_lms_handle_kiwify_webhook_direct();
        exit;
    }
}
add_action('init', 'raz_lms_kiwify_intercept', 1);

/**
 * Handler REST API
 */
function raz_lms_handle_kiwify_webhook_rest($request)
{
    $raw_body = $request->get_body();
    $data = json_decode($raw_body, true);

    if (empty($data)) {
        $data = $request->get_json_params();
    }

    raz_lms_log_webhook('rest_received', 'Dados recebidos via REST API');

    $result = raz_lms_process_kiwify_webhook($data, $raw_body);

    return new WP_REST_Response(
        array(
            'success' => $result,
            'message' => $result ? 'OK' : 'Erro'
        ),
        200
    );
}

/**
 * Handler direto (sem REST API)
 */
function raz_lms_handle_kiwify_webhook_direct()
{
    // Headers CORS
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    header('Content-Type: application/json');

    // Responder OPTIONS imediatamente
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        echo json_encode(array('success' => true));
        exit;
    }

    raz_lms_log_webhook('direct_request', 'Requisição direta recebida - Método: ' . $_SERVER['REQUEST_METHOD']);

    // Obter body
    $raw_body = file_get_contents('php://input');

    raz_lms_log_webhook('raw_body_length', 'Tamanho do body: ' . strlen($raw_body));

    if (empty($raw_body)) {
        raz_lms_log_webhook('error', 'Body vazio');
        echo json_encode(array('success' => false, 'message' => 'Body vazio'));
        exit;
    }

    $data = json_decode($raw_body, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        raz_lms_log_webhook('error', 'Erro ao decodificar JSON: ' . json_last_error_msg());
        echo json_encode(array('success' => false, 'message' => 'JSON inválido'));
        exit;
    }

    $result = raz_lms_process_kiwify_webhook($data, $raw_body);

    echo json_encode(
        array(
            'success' => $result,
            'message' => $result ? 'Processado com sucesso' : 'Erro ao processar'
        )
    );
    exit;
}

/**
 * Processar dados do Kiwify
 */
function raz_lms_process_kiwify_webhook($data, $raw_body = '')
{
    raz_lms_log_webhook('processing', 'Iniciando processamento');

    if (empty($data)) {
        raz_lms_log_webhook('error', 'Dados vazios');
        return false;
    }

    // Log dos dados recebidos (primeiros 500 caracteres)
    raz_lms_log_webhook('data_preview', substr(json_encode($data), 0, 500));

    // Identificar o tipo de evento
    $event_type = isset($data['webhook_event_type']) ? $data['webhook_event_type'] : '';
    $order_status = isset($data['order_status']) ? $data['order_status'] : '';

    raz_lms_log_webhook('event', "Tipo: {$event_type} | Status: {$order_status}");

    // Extrair dados do cliente (estrutura Kiwify)
    $customer_email = '';
    $customer_name = '';
    $product_id = '';

    if (isset($data['Customer']) && is_array($data['Customer'])) {
        $customer = $data['Customer'];
        $customer_email = isset($customer['email']) ? sanitize_email($customer['email']) : '';
        $customer_name = isset($customer['full_name']) ? sanitize_text_field($customer['full_name']) : '';
    }

    if (isset($data['Product']) && is_array($data['Product'])) {
        $product = $data['Product'];
        $product_id = isset($product['product_id']) ? sanitize_text_field($product['product_id']) : '';
    }

    raz_lms_log_webhook('parsed', "Email: {$customer_email} | Nome: {$customer_name} | Product: {$product_id}");

    // Validar dados mínimos
    if (empty($customer_email)) {
        raz_lms_log_webhook('error', 'Email não encontrado');
        return false;
    }

    if (empty($product_id)) {
        raz_lms_log_webhook('error', 'Product ID não encontrado');
        return false;
    }

    // Buscar curso pelo ID do produto Kiwify
    $curso_id = raz_lms_find_curso_by_kiwify_id($product_id);

    if (!$curso_id) {
        raz_lms_log_webhook('error', "Curso não encontrado para product_id: {$product_id}");

        // Listar todos os cursos e seus IDs Kiwify para debug
        $cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1));
        $cursos_info = array();
        foreach ($cursos as $c) {
            $kid = get_post_meta($c->ID, '_raz_curso_kiwify_id', true);
            $cursos_info[] = "Curso {$c->ID} ({$c->post_title}): Kiwify ID = " . ($kid ?: 'NÃO CONFIGURADO');
        }
        raz_lms_log_webhook('debug_cursos', implode(' | ', $cursos_info));

        return false;
    }

    raz_lms_log_webhook('curso_found', "Curso ID: {$curso_id}");

    // Processar baseado no tipo de evento
    switch ($event_type) {
        case 'order_approved':
            if ($order_status === 'paid') {
                raz_lms_log_webhook('action', 'Liberando acesso (order_approved + paid)');
                return raz_lms_kiwify_grant_access($customer_email, $customer_name, $curso_id);
            }
            break;

        case 'subscription_renewed':
            raz_lms_log_webhook('action', 'Renovando acesso (subscription_renewed)');
            return raz_lms_kiwify_grant_access($customer_email, $customer_name, $curso_id);

        case 'order_refunded':
        case 'chargeback':
        case 'subscription_canceled':
            raz_lms_log_webhook('action', "Revogando acesso ({$event_type})");
            return raz_lms_kiwify_revoke_access($customer_email, $curso_id);

        case 'subscription_late':
            raz_lms_log_webhook('info', 'Assinatura atrasada - nenhuma ação');
            return true;

        default:
            raz_lms_log_webhook('info', "Evento não tratado: {$event_type}");
            return true;
    }

    return true;
}

/**
 * Liberar acesso ao curso
 * FIX: Corrigida a captura de dias_acesso para respeitar a configuração do curso
 */
function raz_lms_kiwify_grant_access($email, $name, $curso_id)
{
    raz_lms_log_webhook('grant_access', "Iniciando para: {$email}");

    $user = get_user_by('email', $email);
    $is_new_user = false;
    $password = '';

    if (!$user) {
        // Criar usuário
        $username = sanitize_user(explode('@', $email)[0]);
        $original_username = $username;
        $counter = 1;

        while (username_exists($username)) {
            $username = $original_username . $counter;
            $counter++;
        }

        $password = wp_generate_password(12, false);

        $user_id = wp_create_user($username, $password, $email);

        if (is_wp_error($user_id)) {
            raz_lms_log_webhook('error', 'Erro ao criar usuário: ' . $user_id->get_error_message());
            return false;
        }

        // Atualizar nome
        if ($name) {
            wp_update_user(array(
                'ID' => $user_id,
                'display_name' => $name,
                'first_name' => explode(' ', $name)[0]
            ));
        }

        $is_new_user = true;
        $user = get_userdata($user_id);

        raz_lms_log_webhook('user_created', "Usuário criado: ID {$user_id}");
    } else {
        raz_lms_log_webhook('user_exists', "Usuário existente: ID {$user->ID}");
    }

    /**
     * AJUSTE DE BUG: Busca os dias de acesso configurados nas metas do curso
     */
    $tipo = get_post_meta($curso_id, '_raz_curso_tipo', true) ?: 'avulso';
    $vitalicio_meta = get_post_meta($curso_id, '_raz_curso_vitalicio', true);
    $dias = (int) get_post_meta($curso_id, '_raz_curso_dias_acesso', true);

    // Se os dias não estiverem definidos, aplica um padrão de 365
    if ($dias <= 0) {
        $dias = 365;
    }

    // Define se é vitalício baseado na meta ou no tipo selecionado
    $is_vitalicio = ($vitalicio_meta === '1' || $tipo === 'vitalicio');

    $acesso_data = array(
        'inicio' => current_time('mysql'),
        'vitalicio' => $is_vitalicio,
        'tipo' => $tipo,
        'origem' => 'kiwify'
    );

    if (!$is_vitalicio) {
        $acesso_data['expiracao'] = date('Y-m-d', strtotime('+' . $dias . ' days'));
    }

    update_user_meta($user->ID, '_raz_curso_acesso_' . $curso_id, $acesso_data);

    raz_lms_log_webhook('access_granted', "Acesso liberado para user {$user->ID} no curso {$curso_id}. Tipo: {$tipo}, Dias: {$dias}");

    // Enviar emails
    if ($is_new_user && function_exists('raz_lms_send_credentials_email')) {
        raz_lms_send_credentials_email($user->ID, $password);
        raz_lms_log_webhook('email_sent', 'Email com credenciais enviado');
    }

    if (function_exists('raz_lms_send_access_granted_email')) {
        raz_lms_send_access_granted_email($user->ID, $curso_id);
        raz_lms_log_webhook('email_sent', 'Email de acesso liberado enviado');
    }

    return true;
}

/**
 * Revogar acesso ao curso
 */
function raz_lms_kiwify_revoke_access($email, $curso_id)
{
    $user = get_user_by('email', $email);

    if (!$user) {
        raz_lms_log_webhook('info', "Usuário não encontrado para revogação: {$email}");
        return true;
    }

    delete_user_meta($user->ID, '_raz_curso_acesso_' . $curso_id);

    raz_lms_log_webhook('access_revoked', "Acesso revogado para user {$user->ID} no curso {$curso_id}");

    return true;
}

/**
 * Encontrar curso pelo ID Kiwify
 */
function raz_lms_find_curso_by_kiwify_id($kiwify_id)
{
    if (empty($kiwify_id)) {
        return null;
    }

    global $wpdb;

    $result = $wpdb->get_var($wpdb->prepare(
        "SELECT post_id FROM {$wpdb->postmeta} 
         WHERE meta_key = '_raz_curso_kiwify_id' 
         AND meta_value = %s 
         LIMIT 1",
        $kiwify_id
    ));

    return $result ? intval($result) : null;
}

/**
 * Log de webhook para debug
 */
function raz_lms_log_webhook($type, $message)
{
    $log = get_option('raz_lms_webhook_log', array());

    if (!is_array($log)) {
        $log = array();
    }

    $timezone = wp_timezone();
    $now = new DateTime('now', $timezone);

    array_unshift($log, array(
        'type' => $type,
        'message' => is_string($message) ? $message : json_encode($message),
        'date' => $now->format('Y-m-d H:i:s')
    ));

    // Manter apenas últimos 200 logs
    $log = array_slice($log, 0, 200);

    update_option('raz_lms_webhook_log', $log, false);
}

/**
 * Página de teste/debug do webhook
 */
function raz_lms_webhook_debug_page()
{
    if (!current_user_can('manage_options')) {
        wp_die('Sem permissão');
    }

    // Processar ações
    if (isset($_POST['test_webhook']) && wp_verify_nonce($_POST['_wpnonce'], 'test_webhook')) {
        $test_data = array(
            'webhook_event_type' => 'order_approved',
            'order_status' => 'paid',
            'Customer' => array(
                'email' => sanitize_email($_POST['test_email']),
                'full_name' => sanitize_text_field($_POST['test_name'])
            ),
            'Product' => array(
                'product_id' => sanitize_text_field($_POST['test_product_id'])
            )
        );

        $result = raz_lms_process_kiwify_webhook($test_data);

        echo '<div class="notice notice-' . ($result ? 'success' : 'error') . '"><p>';
        echo $result ? 'Teste executado com sucesso!' : 'Erro no teste. Verifique os logs.';
        echo '</p></div>';
    }

    if (isset($_GET['clear_logs']) && wp_verify_nonce($_GET['_wpnonce'], 'clear_logs')) {
        delete_option('raz_lms_webhook_log');
        echo '<div class="notice notice-success"><p>Logs limpos!</p></div>';
    }

    $logs = get_option('raz_lms_webhook_log', array());
    if (!is_array($logs)) {
        $logs = array();
    }

    // Listar cursos e seus IDs Kiwify
    $cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1));

?>
    <div class="wrap">
        <h1>🔌 Webhook Kiwify - Debug</h1>

        <div style="background:#fff;padding:20px;border:1px solid #ccd0d4;margin:20px 0;">
            <h2>URLs do Webhook</h2>
            <p>Configure uma destas URLs na Kiwify:</p>
            <p><strong>Opção 1 (REST API):</strong><br>
                <code style="background:#f0f0f0;padding:8px 12px;display:inline-block;margin:5px 0;"><?php echo home_url('/wp-json/raz-lms/v1/kiwify'); ?></code>
            </p>

            <p><strong>Opção 2 (Alternativa):</strong><br>
                <code style="background:#f0f0f0;padding:8px 12px;display:inline-block;margin:5px 0;"><?php echo home_url('/?raz_kiwify_webhook=1'); ?></code>
            </p>
        </div>

        <div style="background:#fff;padding:20px;border:1px solid #ccd0d4;margin:20px 0;">
            <h2>Cursos e IDs Kiwify Configurados</h2>
            <table class="widefat">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Curso</th>
                        <th>ID Kiwify</th>
                        <th>Configuração Acesso</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cursos as $curso) :
                        $kiwify_id = get_post_meta($curso->ID, '_raz_curso_kiwify_id', true);
                        $tipo = get_post_meta($curso->ID, '_raz_curso_tipo', true) ?: 'avulso';
                        $dias = get_post_meta($curso->ID, '_raz_curso_dias_acesso', true) ?: 365;
                        $vitalicio = get_post_meta($curso->ID, '_raz_curso_vitalicio', true) === '1' ? 'Sim' : 'Não';
                    ?>
                        <tr>
                            <td><?php echo $curso->ID; ?></td>
                            <td><?php echo esc_html($curso->post_title); ?></td>
                            <td><code><?php echo $kiwify_id ? esc_html($kiwify_id) : '<span style="color:red;">NÃO CONFIGURADO</span>'; ?></code></td>
                            <td>
                                <strong>Tipo:</strong> <?php echo ucfirst($tipo); ?><br>
                                <strong>Dias:</strong> <?php echo $dias; ?><br>
                                <strong>Vitalício:</strong> <?php echo $vitalicio; ?>
                            </td>
                            <td><?php echo $kiwify_id ? '✅ OK' : '❌ Configurar'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div style="background:#fff;padding:20px;border:1px solid #ccd0d4;margin:20px 0;">
            <h2>🧪 Testar Webhook Manualmente</h2>
            <form method="post">
                <?php wp_nonce_field('test_webhook'); ?>
                <table class="form-table">
                    <tr>
                        <th>Email do Cliente</th>
                        <td><input type="email" name="test_email" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th>Nome do Cliente</th>
                        <td><input type="text" name="test_name" class="regular-text" value="Teste Webhook"></td>
                    </tr>
                    <tr>
                        <th>Product ID (Kiwify)</th>
                        <td>
                            <select name="test_product_id">
                                <?php foreach ($cursos as $curso) :
                                    $kiwify_id = get_post_meta($curso->ID, '_raz_curso_kiwify_id', true);
                                    if ($kiwify_id) :
                                ?>
                                        <option value="<?php echo esc_attr($kiwify_id); ?>"><?php echo esc_html($curso->post_title); ?> (<?php echo esc_html($kiwify_id); ?>)</option>
                                <?php endif;
                                endforeach; ?>
                            </select>
                        </td>
                    </tr>
                </table>
                <p><button type="submit" name="test_webhook" class="button button-primary">Simular Compra Aprovada</button></p>
            </form>
        </div>

        <h2>📋 Logs (<?php echo count($logs); ?> entradas)</h2>
        <p>
            <a href="<?php echo wp_nonce_url(admin_url('tools.php?page=raz-webhook-logs&clear_logs=1'), 'clear_logs'); ?>" class="button">Limpar Logs</a>
        </p>

        <table class="widefat" style="margin-top:10px;">
            <thead>
                <tr>
                    <th style="width:150px;">Data</th>
                    <th style="width:120px;">Tipo</th>
                    <th>Mensagem</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)) : ?>
                    <tr>
                        <td colspan="3" style="text-align:center;padding:20px;">Nenhum log registrado. Os logs aparecerão aqui quando o webhook for acionado.</td>
                    </tr>
                <?php else : ?>
                    <?php foreach ($logs as $log) : ?>
                        <tr>
                            <td><small><?php echo esc_html($log['date']); ?></small></td>
                            <td><code style="font-size:11px;"><?php echo esc_html($log['type']); ?></code></td>
                            <td>
                                <pre style="margin:0;white-space:pre-wrap;word-wrap:break-word;font-size:11px;max-width:600px;"><?php echo esc_html($log['message']); ?></pre>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php
}

/**
 * Adicionar menu de debug no admin
 */
function raz_lms_add_webhook_menu()
{
    add_submenu_page(
        'tools.php',
        'Webhook Kiwify',
        'Webhook Kiwify',
        'manage_options',
        'raz-webhook-logs',
        'raz_lms_webhook_debug_page'
    );
}
add_action('admin_menu', 'raz_lms_add_webhook_menu');

/**
 * Endpoint de verificação simples
 */
function raz_lms_webhook_health_check()
{
    if (isset($_GET['raz_webhook_check'])) {
        header('Content-Type: application/json');
        echo json_encode(array(
            'status' => 'ok',
            'message' => 'Webhook endpoint funcionando',
            'time' => current_time('mysql')
        ));
        exit;
    }
}
add_action('init', 'raz_lms_webhook_health_check', 0);