<?php
/**
 * Sistema de E-mails de Lembrete e Envio Manual
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * Agendar verificação diária de lembretes
 */
function raz_lms_schedule_reminder_check() {
    if (!wp_next_scheduled('raz_lms_daily_reminder_check')) {
        wp_schedule_event(time(), 'daily', 'raz_lms_daily_reminder_check');
    }
}
add_action('init', 'raz_lms_schedule_reminder_check');

/**
 * Verificar e enviar lembretes
 */
function raz_lms_send_reminders() {
    $config = get_option('raz_lms_email_lembrete', array());
    
    if (empty($config['ativo'])) return;
    
    $dias_inativo = isset($config['dias']) ? intval($config['dias']) : 7;
    $assunto = isset($config['assunto']) ? $config['assunto'] : 'Sentimos sua falta!';
    $mensagem = isset($config['mensagem']) ? $config['mensagem'] : '';
    
    if (empty($mensagem)) return;
    
    global $wpdb;
    $timezone = wp_timezone();
    $now = new DateTime('now', $timezone);
    $limite = $now->modify("-{$dias_inativo} days")->getTimestamp();
    
    // Buscar alunos que não acessam há X dias
    $alunos = $wpdb->get_results($wpdb->prepare(
        "SELECT DISTINCT um.user_id 
         FROM {$wpdb->usermeta} um 
         WHERE um.meta_key LIKE '_raz_curso_acesso_%%'
         AND um.user_id IN (
             SELECT user_id FROM {$wpdb->usermeta} 
             WHERE meta_key = '_raz_last_access_timestamp' 
             AND CAST(meta_value AS UNSIGNED) < %d
         )",
        $limite
    ));
    
    // Verificar último envio de lembrete para não enviar repetidamente
    foreach ($alunos as $aluno) {
        $ultimo_lembrete = get_user_meta($aluno->user_id, '_raz_last_reminder_sent', true);
        
        // Não enviar se já enviou nos últimos 7 dias
        if ($ultimo_lembrete && (time() - intval($ultimo_lembrete)) < (7 * DAY_IN_SECONDS)) {
            continue;
        }
        
        $user = get_userdata($aluno->user_id);
        if (!$user) continue;
        
        // Buscar um curso do aluno para personalizar
        $cursos = raz_lms_get_user_courses($aluno->user_id);
        $curso_nome = !empty($cursos) ? $cursos[0]->post_title : 'seu curso';
        
        $vars = array(
            '{nome}' => $user->display_name,
            '{email}' => $user->user_email,
            '{curso}' => $curso_nome,
            '{dias}' => $dias_inativo,
            '{link}' => home_url('/meus-cursos'),
            '{site_nome}' => get_bloginfo('name')
        );
        
        $email_assunto = str_replace(array_keys($vars), array_values($vars), $assunto);
        $email_mensagem = str_replace(array_keys($vars), array_values($vars), $mensagem);
        $email_mensagem = nl2br($email_mensagem);
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        if (wp_mail($user->user_email, $email_assunto, $email_mensagem, $headers)) {
            update_user_meta($aluno->user_id, '_raz_last_reminder_sent', time());
        }
    }
}
add_action('raz_lms_daily_reminder_check', 'raz_lms_send_reminders');

/**
 * AJAX: Enviar e-mail manual para alunos
 */
function raz_lms_ajax_send_manual_email() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $assunto = sanitize_text_field($_POST['assunto']);
    $mensagem = wp_kses_post($_POST['mensagem']);
    $destinatarios = isset($_POST['destinatarios']) ? $_POST['destinatarios'] : 'todos';
    $curso_id = isset($_POST['curso_id']) ? intval($_POST['curso_id']) : 0;
    $emails_manuais = isset($_POST['emails_manuais']) ? sanitize_textarea_field($_POST['emails_manuais']) : '';
    
    if (empty($assunto) || empty($mensagem)) {
        wp_send_json_error(array('message' => 'Assunto e mensagem são obrigatórios'));
    }
    
    $emails = array();
    
    if ($destinatarios === 'manual' && !empty($emails_manuais)) {
        // Emails inseridos manualmente
        $emails = array_filter(array_map('trim', explode("\n", $emails_manuais)));
        $emails = array_filter($emails, 'is_email');
    } elseif ($destinatarios === 'curso' && $curso_id) {
        // Alunos de um curso específico
        global $wpdb;
        $users = $wpdb->get_col($wpdb->prepare(
            "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s",
            '_raz_curso_acesso_' . $curso_id
        ));
        foreach ($users as $uid) {
            $user = get_userdata($uid);
            if ($user) $emails[] = $user->user_email;
        }
    } else {
        // Todos os alunos
        global $wpdb;
        $users = $wpdb->get_col(
            "SELECT DISTINCT user_id FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%'"
        );
        foreach ($users as $uid) {
            $user = get_userdata($uid);
            if ($user) $emails[] = $user->user_email;
        }
    }
    
    $emails = array_unique($emails);
    
    if (empty($emails)) {
        wp_send_json_error(array('message' => 'Nenhum destinatário encontrado'));
    }
    
    $mensagem_html = nl2br($mensagem);
    $headers = array('Content-Type: text/html; charset=UTF-8');
    
    $enviados = 0;
    $erros = 0;
    
    foreach ($emails as $email) {
        if (wp_mail($email, $assunto, $mensagem_html, $headers)) {
            $enviados++;
        } else {
            $erros++;
        }
    }
    
    wp_send_json_success(array(
        'enviados' => $enviados,
        'erros' => $erros,
        'total' => count($emails)
    ));
}
add_action('wp_ajax_raz_send_manual_email', 'raz_lms_ajax_send_manual_email');

/**
 * AJAX: Obter contagem de destinatários
 */
function raz_lms_ajax_count_recipients() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error();
    }
    
    $tipo = isset($_GET['tipo']) ? $_GET['tipo'] : 'todos';
    $curso_id = isset($_GET['curso_id']) ? intval($_GET['curso_id']) : 0;
    
    global $wpdb;
    
    if ($tipo === 'curso' && $curso_id) {
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key = %s",
            '_raz_curso_acesso_' . $curso_id
        ));
    } else {
        $count = $wpdb->get_var(
            "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%'"
        );
    }
    
    wp_send_json_success(array('count' => intval($count)));
}
add_action('wp_ajax_raz_count_recipients', 'raz_lms_ajax_count_recipients');
