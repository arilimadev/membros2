<?php
/**
 * Helper Functions
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * Get SVG icon
 */
function raz_lms_icon($name, $size = 20) {
    $icons = array(
        'play' => '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>',
        'pause' => '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>',
        'check' => '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>',
        'lock' => '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
        'video' => '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>',
        'audio' => '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
        'text' => '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
    );
    
    return isset($icons[$name]) ? $icons[$name] : '';
}

/**
 * Format duration
 */
function raz_lms_format_duration($seconds) {
    if ($seconds < 60) {
        return $seconds . 's';
    }
    
    $mins = floor($seconds / 60);
    $secs = $seconds % 60;
    
    if ($mins < 60) {
        return $mins . ':' . str_pad($secs, 2, '0', STR_PAD_LEFT);
    }
    
    $hours = floor($mins / 60);
    $mins = $mins % 60;
    
    return $hours . ':' . str_pad($mins, 2, '0', STR_PAD_LEFT) . ':' . str_pad($secs, 2, '0', STR_PAD_LEFT);
}

/**
 * Get user initials
 */
function raz_lms_get_initials($name) {
    $words = explode(' ', trim($name));
    $initials = '';
    
    if (count($words) >= 2) {
        $initials = strtoupper(substr($words[0], 0, 1) . substr(end($words), 0, 1));
    } else {
        $initials = strtoupper(substr($name, 0, 2));
    }
    
    return $initials;
}

/**
 * Check if current page is LMS
 */
function raz_lms_is_lms_page() {
    return is_singular('curso') || is_singular('modulo') || is_singular('aula') || is_post_type_archive('curso');
}

/**
 * Get first incomplete lesson
 */
function raz_lms_get_first_incomplete_lesson($user_id, $curso_id) {
    $aulas = raz_lms_get_all_aulas($curso_id);
    
    foreach ($aulas as $aula) {
        if (!raz_lms_is_lesson_completed($user_id, $aula->ID)) {
            return $aula;
        }
    }
    
    // If all complete, return first lesson
    return !empty($aulas) ? $aulas[0] : null;
}

/**
 * Get lesson type icon
 */
function raz_lms_get_lesson_type_icon($aula_id) {
    $tipo = get_post_meta($aula_id, '_raz_aula_tipo', true) ?: 'video';
    return raz_lms_icon($tipo);
}

/**
 * AJAX: Save rating
 */
function raz_lms_ajax_rate_lesson() {
    check_ajax_referer('raz_lms_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Você precisa estar logado.'));
    }
    
    $aula_id = isset($_POST['aula_id']) ? intval($_POST['aula_id']) : 0;
    $rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
    
    if (!$aula_id || $rating < 1 || $rating > 5) {
        wp_send_json_error(array('message' => 'Dados inválidos.'));
    }
    
    update_user_meta(get_current_user_id(), '_raz_lesson_rating_' . $aula_id, $rating);
    
    wp_send_json_success(array('message' => 'Avaliação salva!'));
}
add_action('wp_ajax_raz_rate_lesson', 'raz_lms_ajax_rate_lesson');
