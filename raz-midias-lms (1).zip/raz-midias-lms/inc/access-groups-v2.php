<?php
/**
 * Sistema de Grupos de Acesso v2.0
 * Controle de acesso por MÓDULOS dentro de cada curso
 * 
 * ARQUITETURA:
 * - Cada CURSO tem seus próprios GRUPOS
 * - Cada GRUPO libera acesso a MÓDULOS específicos
 * - Usuários são vinculados aos grupos do curso
 * 
 * ESTRUTURA DE DADOS:
 * 
 * Post Meta do Curso:
 *   '_raz_curso_grupos' => [
 *       'padrao' => [
 *           'nome' => 'Padrão',
 *           'modulos' => [10, 11, 12],  // IDs dos módulos
 *           'is_default' => true
 *       ],
 *       'bronze' => [
 *           'nome' => 'Bronze',
 *           'modulos' => [10, 11],
 *           'is_default' => false
 *       ]
 *   ]
 * 
 * User Meta:
 *   '_raz_user_grupos_cursos' => [
 *       'curso_45' => ['padrao', 'bronze'],  // Slugs dos grupos
 *       'curso_67' => ['ouro']
 *   ]
 * 
 * @package RazMidiasLMS
 * @version 2.0.0
 */

defined('ABSPATH') || exit;

// ============================================================================
// 1. FUNÇÕES PRINCIPAIS DE VALIDAÇÃO DE ACESSO
// ============================================================================

/**
 * Verifica se o usuário tem acesso a um módulo específico
 * 
 * @param int $user_id ID do usuário
 * @param int $modulo_id ID do módulo
 * @param int $curso_id ID do curso
 * @return bool True se tem acesso
 */
function raz_user_can_access_modulo($user_id, $modulo_id, $curso_id) {
    // Admin sempre tem acesso
    if (user_can($user_id, 'manage_options')) {
        return true;
    }
    
    // Busca grupos do usuário neste curso
    $user_grupos = raz_get_user_grupos_in_curso($user_id, $curso_id);
    
    if (empty($user_grupos)) {
        return false;
    }
    
    // Busca configuração de grupos do curso
    $curso_grupos = raz_get_curso_grupos_config($curso_id);
    
    // Verifica se algum grupo do usuário libera este módulo
    foreach ($user_grupos as $grupo_slug) {
        if (isset($curso_grupos[$grupo_slug])) {
            $modulos_liberados = $curso_grupos[$grupo_slug]['modulos'] ?? [];
            
            if (in_array($modulo_id, $modulos_liberados)) {
                return true;
            }
        }
    }
    
    return false;
}

/**
 * Verifica se o usuário tem acesso a uma aula
 * 
 * @param int $user_id ID do usuário
 * @param int $aula_id ID da aula
 * @return bool True se tem acesso
 */
function raz_user_can_access_aula($user_id, $aula_id) {
    // Admin sempre tem acesso
    if (user_can($user_id, 'manage_options')) {
        return true;
    }
    
    // Busca o módulo da aula
    $modulo_id = get_post_meta($aula_id, '_aula_modulo_id', true);
    
    if (!$modulo_id) {
        // Se não tem módulo, tenta buscar pelo curso diretamente
        $curso_id = get_post_meta($aula_id, '_aula_curso_id', true);
        if ($curso_id) {
            return raz_user_can_access_curso($user_id, $curso_id);
        }
        return false;
    }
    
    // Busca o curso do módulo
    $curso_id = get_post_meta($modulo_id, '_modulo_curso_id', true);
    
    if (!$curso_id) {
        return false;
    }
    
    return raz_user_can_access_modulo($user_id, $modulo_id, $curso_id);
}

/**
 * Verifica se o usuário tem acesso ao curso
 * 
 * @param int $user_id ID do usuário
 * @param int $curso_id ID do curso
 * @return bool True se tem acesso
 */
function raz_user_can_access_curso($user_id, $curso_id) {
    // Admin sempre tem acesso
    if (user_can($user_id, 'manage_options')) {
        return true;
    }
    
    // Verifica se tem algum grupo no curso
    $user_grupos = raz_get_user_grupos_in_curso($user_id, $curso_id);
    
    return !empty($user_grupos);
}

// ============================================================================
// 2. FUNÇÕES DE GERENCIAMENTO DE GRUPOS DO CURSO
// ============================================================================

/**
 * Busca configuração de grupos de um curso
 * 
 * @param int $curso_id ID do curso
 * @return array Configuração dos grupos
 */
function raz_get_curso_grupos_config($curso_id) {
    $grupos = get_post_meta($curso_id, '_raz_curso_grupos', true);
    
    if (!is_array($grupos) || empty($grupos)) {
        // Cria grupo padrão se não existir
        $grupos = [
            'padrao' => [
                'nome' => 'Padrão',
                'modulos' => [],
                'is_default' => true
            ]
        ];
        update_post_meta($curso_id, '_raz_curso_grupos', $grupos);
    }
    
    return $grupos;
}

/**
 * Salva configuração de grupos do curso
 * 
 * @param int $curso_id ID do curso
 * @param array $grupos Configuração dos grupos
 * @return bool True se salvou com sucesso
 */
function raz_save_curso_grupos_config($curso_id, $grupos) {
    if (!is_array($grupos)) {
        return false;
    }
    
    return update_post_meta($curso_id, '_raz_curso_grupos', $grupos);
}

/**
 * Adiciona um novo grupo ao curso
 * 
 * @param int $curso_id ID do curso
 * @param string $slug Slug do grupo
 * @param string $nome Nome do grupo
 * @param array $modulos IDs dos módulos
 * @param bool $is_default Se é grupo padrão
 * @return bool True se adicionou
 */
function raz_add_grupo_to_curso($curso_id, $slug, $nome, $modulos = [], $is_default = false) {
    $grupos = raz_get_curso_grupos_config($curso_id);
    
    // Se já existe, não adiciona
    if (isset($grupos[$slug])) {
        return false;
    }
    
    // Se este será o padrão, remove flag de outros
    if ($is_default) {
        foreach ($grupos as $key => $grupo) {
            $grupos[$key]['is_default'] = false;
        }
    }
    
    $grupos[$slug] = [
        'nome' => $nome,
        'modulos' => $modulos,
        'is_default' => $is_default
    ];
    
    return raz_save_curso_grupos_config($curso_id, $grupos);
}

/**
 * Remove um grupo do curso
 * 
 * @param int $curso_id ID do curso
 * @param string $slug Slug do grupo
 * @return bool True se removeu
 */
function raz_remove_grupo_from_curso($curso_id, $slug) {
    $grupos = raz_get_curso_grupos_config($curso_id);
    
    if (!isset($grupos[$slug])) {
        return false;
    }
    
    unset($grupos[$slug]);
    
    return raz_save_curso_grupos_config($curso_id, $grupos);
}

// ============================================================================
// 3. FUNÇÕES DE GERENCIAMENTO DE GRUPOS DO USUÁRIO
// ============================================================================

/**
 * Busca grupos de um usuário em um curso específico
 * 
 * @param int $user_id ID do usuário
 * @param int $curso_id ID do curso
 * @return array Array de slugs de grupos
 */
function raz_get_user_grupos_in_curso($user_id, $curso_id) {
    static $cache = [];
    
    $cache_key = $user_id . '_' . $curso_id;
    
    if (isset($cache[$cache_key])) {
        return $cache[$cache_key];
    }
    
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos)) {
        $user_grupos_cursos = [];
    }
    
    $curso_key = 'curso_' . $curso_id;
    $grupos = isset($user_grupos_cursos[$curso_key]) && is_array($user_grupos_cursos[$curso_key]) 
        ? $user_grupos_cursos[$curso_key] 
        : [];
    
    $cache[$cache_key] = $grupos;
    
    return $grupos;
}

/**
 * Adiciona usuário a um grupo de um curso
 * 
 * @param int $user_id ID do usuário
 * @param int $curso_id ID do curso
 * @param string $grupo_slug Slug do grupo
 * @return bool True se adicionou
 */
function raz_add_user_to_curso_grupo($user_id, $curso_id, $grupo_slug) {
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos)) {
        $user_grupos_cursos = [];
    }
    
    $curso_key = 'curso_' . $curso_id;
    
    if (!isset($user_grupos_cursos[$curso_key])) {
        $user_grupos_cursos[$curso_key] = [];
    }
    
    if (!in_array($grupo_slug, $user_grupos_cursos[$curso_key])) {
        $user_grupos_cursos[$curso_key][] = $grupo_slug;
        
        return update_user_meta($user_id, '_raz_user_grupos_cursos', $user_grupos_cursos);
    }
    
    return false;
}

/**
 * Remove usuário de um grupo de um curso
 * 
 * @param int $user_id ID do usuário
 * @param int $curso_id ID do curso
 * @param string $grupo_slug Slug do grupo
 * @return bool True se removeu
 */
function raz_remove_user_from_curso_grupo($user_id, $curso_id, $grupo_slug) {
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos)) {
        return false;
    }
    
    $curso_key = 'curso_' . $curso_id;
    
    if (!isset($user_grupos_cursos[$curso_key])) {
        return false;
    }
    
    $key = array_search($grupo_slug, $user_grupos_cursos[$curso_key]);
    
    if ($key !== false) {
        unset($user_grupos_cursos[$curso_key][$key]);
        $user_grupos_cursos[$curso_key] = array_values($user_grupos_cursos[$curso_key]);
        
        return update_user_meta($user_id, '_raz_user_grupos_cursos', $user_grupos_cursos);
    }
    
    return false;
}

/**
 * Define grupos do usuário em um curso (substitui todos)
 * 
 * @param int $user_id ID do usuário
 * @param int $curso_id ID do curso
 * @param array $grupos_slugs Array de slugs de grupos
 * @return bool True se definiu
 */
function raz_set_user_grupos_in_curso($user_id, $curso_id, $grupos_slugs) {
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos)) {
        $user_grupos_cursos = [];
    }
    
    $curso_key = 'curso_' . $curso_id;
    $user_grupos_cursos[$curso_key] = is_array($grupos_slugs) ? $grupos_slugs : [];
    
    return update_user_meta($user_id, '_raz_user_grupos_cursos', $user_grupos_cursos);
}

/**
 * Busca todos os módulos que um usuário tem acesso em um curso
 * 
 * @param int $user_id ID do usuário
 * @param int $curso_id ID do curso
 * @return array Array de IDs de módulos
 */
function raz_get_user_accessible_modulos($user_id, $curso_id) {
    $user_grupos = raz_get_user_grupos_in_curso($user_id, $curso_id);
    
    if (empty($user_grupos)) {
        return [];
    }
    
    $curso_grupos = raz_get_curso_grupos_config($curso_id);
    $modulos_ids = [];
    
    foreach ($user_grupos as $grupo_slug) {
        if (isset($curso_grupos[$grupo_slug])) {
            $modulos = $curso_grupos[$grupo_slug]['modulos'] ?? [];
            $modulos_ids = array_merge($modulos_ids, $modulos);
        }
    }
    
    return array_unique($modulos_ids);
}

// ============================================================================
// 4. INTEGRAÇÃO COM TEMPLATES
// ============================================================================

/**
 * Valida acesso ou redireciona para página de bloqueio
 * 
 * @param string $tipo 'curso' ou 'aula'
 * @return bool True se tem acesso
 */
function raz_validate_access_or_redirect($tipo = 'curso') {
    if (!is_user_logged_in()) {
        wp_redirect(home_url('/login'));
        exit;
    }
    
    $user_id = get_current_user_id();
    $post_id = get_the_ID();
    
    $has_access = false;
    
    if ($tipo === 'curso') {
        $has_access = raz_user_can_access_curso($user_id, $post_id);
    } elseif ($tipo === 'aula') {
        $has_access = raz_user_can_access_aula($user_id, $post_id);
    }
    
    if (!$has_access) {
        raz_display_access_blocked($tipo);
        return false;
    }
    
    return true;
}

/**
 * Exibe mensagem de acesso bloqueado
 * 
 * @param string $tipo 'curso' ou 'aula'
 */
function raz_display_access_blocked($tipo = 'curso') {
    get_header();
    ?>
    <div class="raz-access-blocked" style="max-width: 600px; margin: 80px auto; text-align: center; padding: 40px;">
        <div style="font-size: 64px; margin-bottom: 20px;">🔒</div>
        <h1 style="font-size: 32px; margin-bottom: 16px; color: #1e293b;">Acesso Restrito</h1>
        <p style="color: #64748b; font-size: 16px; margin-bottom: 32px; line-height: 1.6;">
            Você não tem permissão para acessar <?php echo $tipo === 'curso' ? 'este curso' : 'esta aula'; ?>.<br>
            Entre em contato com o suporte se acredita que isto é um erro.
        </p>
        <a href="<?php echo home_url('/cursos'); ?>" style="display: inline-block; background: #0284c7; color: #fff; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; transition: background 0.2s;">
            Ver Meus Cursos
        </a>
    </div>
    <?php
    get_footer();
    exit;
}

// ============================================================================
// 5. FILTROS E HOOKS
// ============================================================================

/**
 * Adiciona usuário ao grupo padrão quando registrado
 * (Se algum curso tiver grupo padrão)
 */
add_action('user_register', 'raz_add_new_user_to_default_grupos', 10, 1);
function raz_add_new_user_to_default_grupos($user_id) {
    // Busca todos os cursos
    $cursos = get_posts([
        'post_type' => 'curso',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ]);
    
    foreach ($cursos as $curso_id) {
        $grupos = raz_get_curso_grupos_config($curso_id);
        
        // Adiciona ao grupo padrão se existir
        foreach ($grupos as $slug => $data) {
            if (!empty($data['is_default'])) {
                raz_add_user_to_curso_grupo($user_id, $curso_id, $slug);
                break;
            }
        }
    }
}

// ============================================================================
// 6. AJAX HANDLERS
// ============================================================================

/**
 * AJAX: Salvar grupos do curso
 */
add_action('wp_ajax_raz_save_curso_grupos', 'raz_ajax_save_curso_grupos');
function raz_ajax_save_curso_grupos() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Sem permissão']);
    }
    
    $curso_id = intval($_POST['curso_id'] ?? 0);
    $grupos_json = stripslashes($_POST['grupos'] ?? '{}');
    $grupos = json_decode($grupos_json, true);
    
    if (!$curso_id || !is_array($grupos)) {
        wp_send_json_error(['message' => 'Dados inválidos']);
    }
    
    $result = raz_save_curso_grupos_config($curso_id, $grupos);
    
    if ($result) {
        wp_send_json_success(['message' => 'Grupos salvos com sucesso']);
    } else {
        wp_send_json_error(['message' => 'Erro ao salvar']);
    }
}

/**
 * AJAX: Buscar grupos do curso
 */
add_action('wp_ajax_raz_get_curso_grupos', 'raz_ajax_get_curso_grupos');
function raz_ajax_get_curso_grupos() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Sem permissão']);
    }
    
    $curso_id = intval($_GET['curso_id'] ?? 0);
    
    if (!$curso_id) {
        wp_send_json_error(['message' => 'ID do curso inválido']);
    }
    
    $grupos_config = raz_get_curso_grupos_config($curso_id);
    
    wp_send_json_success([
        'grupos' => $grupos_config
    ]);
}

/**
 * AJAX: Salvar grupos do aluno
 */
add_action('wp_ajax_raz_save_aluno_grupos', 'raz_ajax_save_aluno_grupos');
function raz_ajax_save_aluno_grupos() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Sem permissão']);
    }
    
    $user_id = intval($_POST['user_id'] ?? 0);
    $grupos = $_POST['grupos'] ?? [];
    
    if (!$user_id) {
        wp_send_json_error(['message' => 'Usuário inválido']);
    }
    
    $result = raz_save_aluno_grupos($user_id, $grupos);
    
    if ($result) {
        wp_send_json_success(['message' => 'Grupos atualizados com sucesso']);
    } else {
        wp_send_json_error(['message' => 'Erro ao salvar grupos']);
    }
}

/**
 * Salva grupos do aluno (helper para AJAX)
 * 
 * @param int $user_id ID do usuário
 * @param array $grupos_data Array com grupos por curso
 * @return bool
 */
function raz_save_aluno_grupos($user_id, $grupos_data) {
    if (!is_array($grupos_data)) {
        return false;
    }
    
    $user_grupos_cursos = [];
    
    foreach ($grupos_data as $curso_id => $grupos) {
        if (!empty($grupos) && is_array($grupos)) {
            $curso_key = 'curso_' . intval($curso_id);
            $user_grupos_cursos[$curso_key] = array_values($grupos);
        }
    }
    
    return update_user_meta($user_id, '_raz_user_grupos_cursos', $user_grupos_cursos);
}
