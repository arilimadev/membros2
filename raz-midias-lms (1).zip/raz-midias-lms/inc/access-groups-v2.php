<?php
/**
 * Sistema de Grupos de Acesso v2.3
 * Controle de acesso por MÓDULOS dentro de cada curso
 * * Funcionalidades:
 * - Validação de acesso (Curso, Módulo, Aula)
 * - Gestão de Grupos no backend
 * - Sincronização de alunos em Grupos Padrão
 * - Busca e Paginação de Alunos nos Grupos
 * * @package RazMidiasLMS
 * @version 2.3.0
 */

defined('ABSPATH') || exit;

// ============================================================================
// 1. FUNÇÕES PRINCIPAIS DE VALIDAÇÃO DE ACESSO
// ============================================================================

/**
 * Verifica se o usuário tem acesso a um módulo específico
 */
function raz_user_can_access_modulo($user_id, $modulo_id, $curso_id) {
    // Admin sempre tem acesso
    if (user_can($user_id, 'manage_options')) {
        return true;
    }
    
    // Busca grupos do usuário neste curso
    $user_grupos = raz_get_user_grupos_in_curso($user_id, $curso_id);
    
    if (empty($user_grupos)) {
        return false;
    }
    
    // Busca configuração de grupos do curso
    $curso_grupos = raz_get_curso_grupos_config($curso_id);
    
    // Verifica se algum grupo do usuário libera este módulo
    foreach ($user_grupos as $grupo_slug) {
        if (isset($curso_grupos[$grupo_slug])) {
            $modulos_liberados = $curso_grupos[$grupo_slug]['modulos'] ?? [];
            
            // Verifica se o módulo está no array de liberados
            if (in_array(intval($modulo_id), array_map('intval', $modulos_liberados))) {
                return true;
            }
        }
    }
    
    return false;
}

/**
 * Verifica se o usuário tem acesso a uma aula
 */
function raz_user_can_access_aula($user_id, $aula_id) {
    // Admin sempre tem acesso
    if (user_can($user_id, 'manage_options')) {
        return true;
    }
    
    // 1. Busca o módulo da aula
    $modulo_id = get_post_meta($aula_id, '_raz_aula_modulo', true);
    
    if (!$modulo_id) {
        // Fallback: se não tem módulo, tenta buscar pelo curso diretamente
        $curso_id = get_post_meta($aula_id, '_raz_aula_curso', true);
        if ($curso_id) {
            return raz_user_can_access_curso($user_id, $curso_id);
        }
        return false;
    }
    
    // 2. Busca o curso do módulo
    $curso_id = get_post_meta($modulo_id, '_raz_modulo_curso', true);
    
    if (!$curso_id) {
        return false;
    }
    
    // 3. Valida se o usuário tem acesso a esse módulo específico nesse curso
    return raz_user_can_access_modulo($user_id, $modulo_id, $curso_id);
}

/**
 * Verifica se o usuário tem acesso ao curso
 */
function raz_user_can_access_curso($user_id, $curso_id) {
    // Admin sempre tem acesso
    if (user_can($user_id, 'manage_options')) {
        return true;
    }
    
    // Verifica se tem algum grupo no curso
    $user_grupos = raz_get_user_grupos_in_curso($user_id, $curso_id);
    
    // Se tiver qualquer grupo atribuído, considera que tem acesso "ao curso"
    return !empty($user_grupos);
}

// ============================================================================
// 2. FUNÇÕES DE GERENCIAMENTO DE GRUPOS DO CURSO
// ============================================================================

/**
 * Busca configuração de grupos de um curso
 */
function raz_get_curso_grupos_config($curso_id) {
    $grupos = get_post_meta($curso_id, '_raz_curso_grupos', true);
    
    if (!is_array($grupos) || empty($grupos)) {
        // Cria grupo padrão se não existir
        $grupos = [
            'padrao' => [
                'nome' => 'Padrão',
                'modulos' => [],
                'is_default' => true
            ]
        ];
    }
    
    return $grupos;
}

/**
 * Salva configuração de grupos do curso
 */
function raz_save_curso_grupos_config($curso_id, $grupos) {
    if (!is_array($grupos)) {
        return false;
    }
    
    return update_post_meta($curso_id, '_raz_curso_grupos', $grupos);
}

/**
 * Adiciona um novo grupo ao curso
 */
function raz_add_grupo_to_curso($curso_id, $slug, $nome, $modulos = [], $is_default = false) {
    $grupos = raz_get_curso_grupos_config($curso_id);
    
    if (isset($grupos[$slug])) {
        return false;
    }
    
    if ($is_default) {
        foreach ($grupos as $key => $grupo) {
            $grupos[$key]['is_default'] = false;
        }
    }
    
    $grupos[$slug] = [
        'nome' => $nome,
        'modulos' => $modulos,
        'is_default' => $is_default
    ];
    
    return raz_save_curso_grupos_config($curso_id, $grupos);
}

/**
 * Remove um grupo do curso
 */
function raz_remove_grupo_from_curso($curso_id, $slug) {
    $grupos = raz_get_curso_grupos_config($curso_id);
    
    if (!isset($grupos[$slug])) {
        return false;
    }
    
    unset($grupos[$slug]);
    
    return raz_save_curso_grupos_config($curso_id, $grupos);
}

// ============================================================================
// 3. FUNÇÕES DE GERENCIAMENTO DE GRUPOS DO USUÁRIO
// ============================================================================

/**
 * Busca grupos de um usuário em um curso específico
 */
function raz_get_user_grupos_in_curso($user_id, $curso_id) {
    static $cache = [];
    $cache_key = $user_id . '_' . $curso_id;
    
    if (isset($cache[$cache_key])) {
        return $cache[$cache_key];
    }
    
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos)) {
        $user_grupos_cursos = [];
    }
    
    $curso_key = 'curso_' . $curso_id;
    $grupos = isset($user_grupos_cursos[$curso_key]) && is_array($user_grupos_cursos[$curso_key]) 
        ? $user_grupos_cursos[$curso_key] 
        : [];
    
    $cache[$cache_key] = $grupos;
    
    return $grupos;
}

/**
 * Adiciona usuário a um grupo de um curso
 */
function raz_add_user_to_curso_grupo($user_id, $curso_id, $grupo_slug) {
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos)) {
        $user_grupos_cursos = [];
    }
    
    $curso_key = 'curso_' . $curso_id;
    
    if (!isset($user_grupos_cursos[$curso_key])) {
        $user_grupos_cursos[$curso_key] = [];
    }
    
    if (!in_array($grupo_slug, $user_grupos_cursos[$curso_key])) {
        $user_grupos_cursos[$curso_key][] = $grupo_slug;
        return update_user_meta($user_id, '_raz_user_grupos_cursos', $user_grupos_cursos);
    }
    
    return false;
}

/**
 * Remove usuário de um grupo de um curso
 */
function raz_remove_user_from_curso_grupo($user_id, $curso_id, $grupo_slug) {
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos)) {
        return false;
    }
    
    $curso_key = 'curso_' . $curso_id;
    
    if (!isset($user_grupos_cursos[$curso_key])) {
        return false;
    }
    
    $key = array_search($grupo_slug, $user_grupos_cursos[$curso_key]);
    
    if ($key !== false) {
        unset($user_grupos_cursos[$curso_key][$key]);
        $user_grupos_cursos[$curso_key] = array_values($user_grupos_cursos[$curso_key]);
        return update_user_meta($user_id, '_raz_user_grupos_cursos', $user_grupos_cursos);
    }
    
    return false;
}

/**
 * Define grupos do usuário em um curso (substitui todos)
 */
function raz_set_user_grupos_in_curso($user_id, $curso_id, $grupos_slugs) {
    $user_grupos_cursos = get_user_meta($user_id, '_raz_user_grupos_cursos', true);
    
    if (!is_array($user_grupos_cursos)) {
        $user_grupos_cursos = [];
    }
    
    $curso_key = 'curso_' . $curso_id;
    $user_grupos_cursos[$curso_key] = is_array($grupos_slugs) ? $grupos_slugs : [];
    
    return update_user_meta($user_id, '_raz_user_grupos_cursos', $user_grupos_cursos);
}

/**
 * Sincroniza usuários para o Grupo Padrão
 * Adiciona o grupo padrão a TODOS os usuários que têm acesso ao curso
 */
function raz_sync_default_group_users($curso_id, $default_group_slug) {
    global $wpdb;
    
    // A chave de meta de acesso é _raz_curso_acesso_{ID}
    $meta_key_access = '_raz_curso_acesso_' . intval($curso_id);
    
    // Busca todos os IDs de usuários que possuem essa meta (têm acesso ao curso)
    $users_with_access = $wpdb->get_col($wpdb->prepare(
        "SELECT user_id FROM $wpdb->usermeta WHERE meta_key = %s",
        $meta_key_access
    ));
    
    if (empty($users_with_access)) {
        return;
    }
    
    foreach ($users_with_access as $user_id) {
        raz_add_user_to_curso_grupo($user_id, $curso_id, $default_group_slug);
    }
}

// ============================================================================
// 4. INTEGRAÇÃO COM TEMPLATES
// ============================================================================

/**
 * Valida acesso ou redireciona para página de bloqueio
 */
function raz_validate_access_or_redirect($tipo = 'curso') {
    if (!is_user_logged_in()) {
        wp_redirect(home_url('/login'));
        exit;
    }
    
    $user_id = get_current_user_id();
    $post_id = get_the_ID();
    
    $has_access = false;
    
    if ($tipo === 'curso') {
        $has_access = raz_user_can_access_curso($user_id, $post_id);
    } elseif ($tipo === 'aula') {
        $has_access = raz_user_can_access_aula($user_id, $post_id);
    }
    
    if (!$has_access) {
        raz_display_access_blocked($tipo);
        return false;
    }
    
    return true;
}

/**
 * Exibe mensagem de acesso bloqueado
 */
function raz_display_access_blocked($tipo = 'curso') {
    if (file_exists(RAZ_LMS_DIR . '/templates/access-blocked.php')) {
        include(RAZ_LMS_DIR . '/templates/access-blocked.php');
        exit;
    }
    
    // Fallback simples
    get_header();
    ?>
    <div class="raz-access-blocked" style="max-width: 600px; margin: 80px auto; text-align: center; padding: 40px;">
        <div style="font-size: 64px; margin-bottom: 20px;">🔒</div>
        <h1 style="font-size: 32px; margin-bottom: 16px; color: #1e293b;">Acesso Restrito</h1>
        <p style="color: #64748b; font-size: 16px; margin-bottom: 32px; line-height: 1.6;">
            Você não tem permissão para acessar <?php echo $tipo === 'curso' ? 'este curso' : 'esta aula'; ?>.
        </p>
        <a href="<?php echo home_url('/meus-cursos'); ?>" style="display: inline-block; background: #0284c7; color: #fff; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600;">
            Ver Meus Cursos
        </a>
    </div>
    <?php
    get_footer();
    exit;
}

// ============================================================================
// 5. FILTROS E HOOKS
// ============================================================================

/**
 * Adiciona usuário ao grupo padrão quando registrado
 */
add_action('user_register', 'raz_add_new_user_to_default_grupos', 10, 1);
function raz_add_new_user_to_default_grupos($user_id) {
    $cursos = get_posts([
        'post_type' => 'curso',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ]);
    
    foreach ($cursos as $curso_id) {
        $grupos = raz_get_curso_grupos_config($curso_id);
        
        foreach ($grupos as $slug => $data) {
            if (!empty($data['is_default'])) {
                raz_add_user_to_curso_grupo($user_id, $curso_id, $slug);
            }
        }
    }
}

/**
 * Adiciona usuário ao grupo padrão quando acesso é concedido (Webhook/Manual)
 */
add_action('raz_lms_access_granted', 'raz_add_user_to_default_course_group', 10, 2);
function raz_add_user_to_default_course_group($user_id, $curso_id) {
    $grupos = raz_get_curso_grupos_config($curso_id);
    
    foreach ($grupos as $slug => $data) {
        if (!empty($data['is_default'])) {
            raz_add_user_to_curso_grupo($user_id, $curso_id, $slug);
        }
    }
}

// ============================================================================
// 6. AJAX HANDLERS
// ============================================================================

/**
 * Salva Grupos de Acesso e Sincroniza Alunos
 */
add_action('wp_ajax_raz_save_curso_grupos', 'raz_ajax_save_curso_grupos');
function raz_ajax_save_curso_grupos() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Sem permissão']);
    
    $curso_id = intval($_POST['curso_id'] ?? 0);
    $grupos = json_decode(stripslashes($_POST['grupos'] ?? '{}'), true);
    
    if (raz_save_curso_grupos_config($curso_id, $grupos)) {
        
        // Sincronização automática para grupos padrão
        foreach ($grupos as $slug => $grupo) {
            if (!empty($grupo['is_default'])) {
                raz_sync_default_group_users($curso_id, $slug);
            }
        }
        
        wp_send_json_success(['message' => 'Grupos salvos']);
    } else {
        wp_send_json_error(['message' => 'Erro ao salvar']);
    }
}

add_action('wp_ajax_raz_get_curso_grupos', 'raz_ajax_get_curso_grupos');
function raz_ajax_get_curso_grupos() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Sem permissão']);
    
    $curso_id = intval($_GET['curso_id'] ?? 0);
    wp_send_json_success(['grupos' => raz_get_curso_grupos_config($curso_id)]);
}

add_action('wp_ajax_raz_save_aluno_grupos', 'raz_ajax_save_aluno_grupos');
function raz_ajax_save_aluno_grupos() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Sem permissão']);
    
    $user_id = intval($_POST['user_id'] ?? 0);
    $grupos = $_POST['grupos'] ?? [];
    
    if (raz_save_aluno_grupos($user_id, $grupos)) {
        wp_send_json_success(['message' => 'Salvo com sucesso']);
    } else {
        wp_send_json_error(['message' => 'Erro ao salvar']);
    }
}

function raz_save_aluno_grupos($user_id, $grupos_data) {
    if (!is_array($grupos_data)) return false;
    
    $user_grupos_cursos = [];
    foreach ($grupos_data as $curso_id => $grupos) {
        if (!empty($grupos) && is_array($grupos)) {
            $curso_key = 'curso_' . intval($curso_id);
            $user_grupos_cursos[$curso_key] = array_values($grupos);
        }
    }
    return update_user_meta($user_id, '_raz_user_grupos_cursos', $user_grupos_cursos);
}

/**
 * AJAX: Contar alunos em um grupo
 */
add_action('wp_ajax_raz_get_group_student_count', 'raz_ajax_get_group_student_count');
function raz_ajax_get_group_student_count() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error();
    
    $curso_id = intval($_GET['curso_id']);
    $grupo_slug = sanitize_text_field($_GET['grupo_slug']);
    
    // Obtém todos os IDs (sem filtro de busca para contagem total rápida)
    $users_in_group = raz_get_users_in_group_raw($curso_id, $grupo_slug);
    
    wp_send_json_success(['count' => count($users_in_group)]);
}

/**
 * AJAX: Listar alunos em um grupo COM BUSCA E PAGINAÇÃO
 */
add_action('wp_ajax_raz_get_group_students', 'raz_ajax_get_group_students');
function raz_ajax_get_group_students() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error();
    
    $curso_id = intval($_GET['curso_id']);
    $grupo_slug = sanitize_text_field($_GET['grupo_slug']);
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
    $per_page = 20; // Limite por página

    // 1. Obtém todos os IDs que estão no grupo
    $all_users_in_group = raz_get_users_in_group_raw($curso_id, $grupo_slug);
    $filtered_users = [];

    // 2. Filtragem de Busca (Manual, pois dados estão em meta serializado)
    // Se houver busca, filtra. Se não, usa todos.
    if (!empty($search)) {
        $search = mb_strtolower($search);
        foreach ($all_users_in_group as $uid) {
            $u = get_userdata($uid);
            if ($u) {
                // Busca em Nome, Login e Email
                if (strpos(mb_strtolower($u->display_name), $search) !== false || 
                    strpos(mb_strtolower($u->user_email), $search) !== false || 
                    strpos(mb_strtolower($u->user_login), $search) !== false) {
                    $filtered_users[] = $uid;
                }
            }
        }
    } else {
        $filtered_users = $all_users_in_group;
    }

    // 3. Paginação (Slice no array)
    $total_items = count($filtered_users);
    $total_pages = ceil($total_items / $per_page);
    $offset = ($paged - 1) * $per_page;
    $paged_users_ids = array_slice($filtered_users, $offset, $per_page);

    // 4. Montagem dos dados
    $users_data = [];
    foreach ($paged_users_ids as $uid) {
        $u = get_userdata($uid);
        if ($u) {
            $users_data[] = [
                'id' => $u->ID,
                'name' => $u->display_name,
                'email' => $u->user_email
            ];
        }
    }
    
    wp_send_json_success([
        'rows' => $users_data,
        'total_items' => $total_items,
        'total_pages' => $total_pages,
        'current_page' => $paged
    ]);
}

/**
 * Helper: Busca IDs de usuários em um grupo específico (Raw Data)
 */
function raz_get_users_in_group_raw($curso_id, $grupo_slug) {
    global $wpdb;
    
    // Busca users que possuem a meta key
    $results = $wpdb->get_results(
        "SELECT user_id, meta_value FROM $wpdb->usermeta WHERE meta_key = '_raz_user_grupos_cursos'"
    );
    
    $users_in_group = [];
    $curso_key = 'curso_' . $curso_id;
    
    foreach ($results as $row) {
        $data = maybe_unserialize($row->meta_value);
        if (isset($data[$curso_key]) && is_array($data[$curso_key])) {
            if (in_array($grupo_slug, $data[$curso_key])) {
                $users_in_group[] = intval($row->user_id);
            }
        }
    }
    
    return $users_in_group;
}