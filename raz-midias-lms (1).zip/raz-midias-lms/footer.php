<?php
/**
 * Footer Template
 * @package RazMidiasLMS
 */
?>

<?php if (!is_singular('aula')) : ?>
<footer class="raz-site-footer">
    <div class="raz-footer-content">
        <div class="raz-footer-info">
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. Todos os direitos reservados.</p>
        </div>
        
        <?php if (has_nav_menu('footer')) : ?>
        <nav class="raz-footer-nav">
            <?php wp_nav_menu(array(
                'theme_location' => 'footer',
                'container' => false,
                'menu_class' => 'raz-footer-menu',
                'depth' => 1,
            )); ?>
        </nav>
        <?php endif; ?>
    </div>
</footer>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
