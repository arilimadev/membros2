<?php
/**
 * Template: Archive Cursos
 * @package RazMidiasLMS
 */

get_header();
?>

<div class="raz-course-header">
    <div class="raz-course-header-content">
        <h1 class="raz-course-title">Nossos Cursos</h1>
        <p class="raz-course-description">Explore nossa biblioteca de cursos e comece sua jornada de aprendizado hoje mesmo.</p>
    </div>
</div>

<div class="raz-course-content">
    <?php if (have_posts()) : ?>
    <div class="raz-dashboard-courses">
        <?php while (have_posts()) : the_post();
            $total_aulas = raz_lms_count_aulas(get_the_ID());
            $total_modulos = count(raz_lms_get_modulos(get_the_ID()));
        ?>
        <div class="raz-course-card">
            <?php if (has_post_thumbnail()) : ?>
            <div class="raz-course-card-image">
                <a href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail('raz-course-card'); ?>
                </a>
            </div>
            <?php endif; ?>
            
            <div class="raz-course-card-content">
                <h3 class="raz-course-card-title">
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </h3>
                
                <div class="raz-course-card-meta">
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                        <?php echo $total_aulas; ?> aulas
                    </span>
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
                        <?php echo $total_modulos; ?> módulos
                    </span>
                </div>
                
                <?php if (has_excerpt()) : ?>
                <p style="color:var(--text-secondary);font-size:.875rem;margin-bottom:1rem;"><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                <?php endif; ?>
                
                <a href="<?php the_permalink(); ?>" class="raz-course-card-action">Ver Curso</a>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    
    <?php the_posts_pagination(array(
        'prev_text' => '&larr; Anterior',
        'next_text' => 'Próximo &rarr;',
    )); ?>
    
    <?php else : ?>
    <p style="text-align:center;padding:3rem;">Nenhum curso disponível no momento.</p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
