<?php
/**
 * Template Name: Nova Senha
 * @package RazMidiasLMS
 */

if (is_user_logged_in()) {
    wp_redirect(home_url('/meus-cursos'));
    exit;
}

$login_logo = get_option('raz_lms_login_logo', '');
$login_bg_color = get_option('raz_lms_login_bg_color', '#667eea');
$login_btn_color = get_option('raz_lms_login_btn_color', '#4f46e5');

$message = '';
$message_type = '';
$valid_key = false;

$key = isset($_GET['key']) ? sanitize_text_field($_GET['key']) : '';
$login = isset($_GET['login']) ? sanitize_text_field($_GET['login']) : '';

// Verificar chave
if ($key && $login) {
    $user = check_password_reset_key($key, $login);
    if (!is_wp_error($user)) {
        $valid_key = true;
    } else {
        $message = 'Link inválido ou expirado. Solicite um novo link.';
        $message_type = 'error';
    }
}

// Processar nova senha
if (isset($_POST['reset_submit']) && $valid_key) {
    $pass1 = $_POST['pass1'];
    $pass2 = $_POST['pass2'];
    
    if (empty($pass1) || empty($pass2)) {
        $message = 'Preencha os dois campos de senha.';
        $message_type = 'error';
    } elseif ($pass1 !== $pass2) {
        $message = 'As senhas não coincidem.';
        $message_type = 'error';
    } elseif (strlen($pass1) < 6) {
        $message = 'A senha deve ter pelo menos 6 caracteres.';
        $message_type = 'error';
    } else {
        reset_password($user, $pass1);
        $message = 'Senha alterada com sucesso! Redirecionando...';
        $message_type = 'success';
        ?>
        <script>setTimeout(function(){ window.location.href = '<?php echo wp_login_url(); ?>'; }, 2000);</script>
        <?php
    }
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nova Senha - <?php bloginfo('name'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
    <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
        font-family: 'Inter', -apple-system, sans-serif;
        min-height: 100vh;
        display: flex;
        background: linear-gradient(135deg, <?php echo esc_attr($login_bg_color); ?> 0%, #764ba2 100%);
    }
    .login-container { flex: 1; display: flex; align-items: center; justify-content: center; padding: 20px; }
    .login-box { background: #fff; border-radius: 24px; padding: 48px 40px; width: 100%; max-width: 420px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); }
    .login-logo { text-align: center; margin-bottom: 32px; }
    .login-logo img { max-height: 60px; max-width: 200px; }
    .login-logo h1 { font-size: 28px; font-weight: 700; color: #1e293b; }
    .login-title { text-align: center; margin-bottom: 8px; font-size: 24px; font-weight: 600; color: #1e293b; }
    .login-subtitle { text-align: center; margin-bottom: 32px; color: #64748b; font-size: 14px; }
    .form-group { margin-bottom: 24px; }
    .form-group label { display: block; margin-bottom: 8px; font-weight: 500; font-size: 14px; color: #374151; }
    .form-group input { width: 100%; padding: 14px 16px; border: 2px solid #e5e7eb; border-radius: 12px; font-size: 16px; transition: all 0.15s; font-family: inherit; }
    .form-group input:focus { outline: none; border-color: <?php echo esc_attr($login_btn_color); ?>; box-shadow: 0 0 0 3px <?php echo esc_attr($login_btn_color); ?>20; }
    .btn-submit { width: 100%; padding: 16px; background: <?php echo esc_attr($login_btn_color); ?>; color: #fff; border: none; border-radius: 12px; font-size: 16px; font-weight: 600; cursor: pointer; transition: all 0.15s; font-family: inherit; }
    .btn-submit:hover { transform: translateY(-1px); box-shadow: 0 4px 12px <?php echo esc_attr($login_btn_color); ?>40; }
    .message { padding: 14px 16px; border-radius: 10px; margin-bottom: 24px; font-size: 14px; text-align: center; }
    .message.error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
    .message.success { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }
    .back-link { display: block; text-align: center; margin-top: 24px; color: #64748b; text-decoration: none; font-size: 14px; }
    .back-link:hover { color: <?php echo esc_attr($login_btn_color); ?>; }
    .icon-wrapper { text-align: center; margin-bottom: 24px; }
    .icon-wrapper svg { width: 64px; height: 64px; color: <?php echo esc_attr($login_btn_color); ?>; }
    .password-hint { font-size: 12px; color: #64748b; margin-top: 6px; }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="login-logo">
                <?php if ($login_logo) : ?>
                    <img src="<?php echo esc_url($login_logo); ?>" alt="<?php bloginfo('name'); ?>">
                <?php else : ?>
                    <h1><?php bloginfo('name'); ?></h1>
                <?php endif; ?>
            </div>
            
            <div class="icon-wrapper">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <path d="M15 7a2 2 0 0 1 2 2m4 0a6 6 0 0 1-7.743 5.743L11 17H9v2H7v2H4a1 1 0 0 1-1-1v-2.586a1 1 0 0 1 .293-.707l5.964-5.964A6 6 0 1 1 21 9z"/>
                </svg>
            </div>
            
            <h2 class="login-title">Criar nova senha</h2>
            <p class="login-subtitle">Digite sua nova senha abaixo.</p>
            
            <?php if ($message) : ?>
            <div class="message <?php echo esc_attr($message_type); ?>">
                <?php echo esc_html($message); ?>
            </div>
            <?php endif; ?>
            
            <?php if ($valid_key) : ?>
            <form method="post">
                <div class="form-group">
                    <label for="pass1">Nova senha</label>
                    <input type="password" name="pass1" id="pass1" placeholder="••••••••" required autofocus>
                    <p class="password-hint">Mínimo de 6 caracteres</p>
                </div>
                
                <div class="form-group">
                    <label for="pass2">Confirmar nova senha</label>
                    <input type="password" name="pass2" id="pass2" placeholder="••••••••" required>
                </div>
                
                <button type="submit" name="reset_submit" class="btn-submit">
                    Salvar nova senha
                </button>
            </form>
            <?php else : ?>
            <a href="<?php echo home_url('/esqueci-senha'); ?>" class="btn-submit" style="display:block;text-align:center;text-decoration:none;">
                Solicitar novo link
            </a>
            <?php endif; ?>
            
            <a href="<?php echo wp_login_url(); ?>" class="back-link">
                ← Voltar para o login
            </a>
        </div>
    </div>
    <?php wp_footer(); ?>
</body>
</html>
