<?php
/**
 * Admin: Avaliações das Aulas - UX Optimized Version
 */
global $wpdb;

// 1. Definição de Parâmetros e Segurança
$curso_filter = isset($_GET['curso']) ? intval($_GET['curso']) : 0;
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

$current_page_slug = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : 'gestao-cursos';
$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'avaliacoes';

// 2. Busca de Avaliações
$ratings = array();
$meta_rows = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_lesson_rating_%'");

foreach ($meta_rows as $row) {
    $aula_id = str_replace('_raz_lesson_rating_', '', $row->meta_key);
    $aula = get_post($aula_id);
    if (!$aula) continue;
    
    $modulo = raz_lms_get_modulo_from_aula($aula_id);
    $curso = raz_lms_get_curso_from_aula($aula_id);
    
    if (!$curso) continue;
    if ($curso_filter && $curso->ID != $curso_filter) continue;
    
    $user = get_userdata($row->user_id);
    
    $ratings[] = array(
        'aula' => $aula,
        'modulo' => $modulo,
        'curso' => $curso,
        'user' => $user,
        'rating' => intval($row->meta_value)
    );
}

// 3. Estatísticas por aula
$stats = array();
foreach ($ratings as $r) {
    $aid = $r['aula']->ID;
    if (!isset($stats[$aid])) {
        $stats[$aid] = array('aula' => $r['aula'], 'curso' => $r['curso'], 'total' => 0, 'sum' => 0);
    }
    $stats[$aid]['total']++;
    $stats[$aid]['sum'] += $r['rating'];
}
foreach ($stats as $k => $s) {
    $stats[$k]['avg'] = $s['total'] > 0 ? round($s['sum'] / $s['total'], 1) : 0;
}

// 4. Configuração de Paginação (10 itens)
$per_page = 10;

// Bloco A: Atenção (avg <= 3)
$low_rated = array_filter($stats, function($s) { return $s['avg'] <= 3; });
usort($low_rated, function($a, $b) { return ($a['avg'] < $b['avg']) ? -1 : 1; });
$current_p_low = isset($_GET['p_low']) ? max(1, intval($_GET['p_low'])) : 1;
$total_p_low = max(1, ceil(count($low_rated) / $per_page));
$paged_low_rated = array_slice($low_rated, ($current_p_low - 1) * $per_page, $per_page);

// Bloco B: Bem Avaliadas (avg >= 4)
$high_rated = array_filter($stats, function($s) { return $s['avg'] >= 4; });
usort($high_rated, function($a, $b) { return ($b['avg'] > $a['avg']) ? -1 : 1; });
$current_p_high = isset($_GET['p_high']) ? max(1, intval($_GET['p_high'])) : 1;
$total_p_high = max(1, ceil(count($high_rated) / $per_page));
$paged_high_rated = array_slice($high_rated, ($current_p_high - 1) * $per_page, $per_page);

// Bloco C: Todas as Avaliações
$current_p_all = isset($_GET['p_all']) ? max(1, intval($_GET['p_all'])) : 1;
$total_p_all = max(1, ceil(count($ratings) / $per_page));
$paged_all_ratings = array_slice($ratings, ($current_p_all - 1) * $per_page, $per_page);
?>

<style>
    :root {
        --ux-primary: #4F46E5;
        --ux-success: #10B981;
        --ux-warning: #F59E0B;
        --ux-danger: #EF4444;
        --ux-bg: #F9FAFB;
        --ux-card: #FFFFFF;
        --ux-text-main: #111827;
        --ux-text-sub: #6B7280;
        --ux-border: #E5E7EB;
    }

    .admin-header h2 {
        font-size: 24px;
        font-weight: 800;
        color: var(--ux-text-main);
        margin-bottom: 20px;
    }

    /* Dashboard Header Card */
    .ux-filter-area {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: var(--ux-card);
        padding: 20px;
        border-radius: 12px;
        border: 1px solid var(--ux-border);
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        margin-bottom: 30px;
    }

    .ux-selector {
        padding: 10px 16px;
        border-radius: 8px;
        border: 1px solid var(--ux-border);
        font-weight: 500;
        color: var(--ux-text-main);
        background-color: #fff;
        min-width: 280px;
        transition: border 0.2s;
    }

    .ux-selector:focus { border-color: var(--ux-primary); outline: none; }

    .ux-badge-total {
        background: #EEF2FF;
        color: var(--ux-primary);
        padding: 8px 16px;
        border-radius: 999px;
        font-weight: 700;
        font-size: 13px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    /* Cards de Estatística */
    .ux-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 24px;
        margin-bottom: 32px;
    }

    .ux-card {
        background: var(--ux-card);
        border-radius: 12px;
        border: 1px solid var(--ux-border);
        padding: 24px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .ux-card h3 {
        font-size: 16px;
        font-weight: 700;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .ux-list-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 14px 0;
        border-bottom: 1px solid #F3F4F6;
        transition: padding 0.2s;
    }

    .ux-list-item:hover { padding-left: 5px; }
    .ux-list-item:last-child { border-bottom: none; }

    .ux-item-title { font-weight: 600; font-size: 14px; color: var(--ux-text-main); }
    .ux-item-sub { font-size: 12px; color: var(--ux-text-sub); }

    .ux-avg-badge {
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 800;
        font-size: 14px;
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .ux-danger-bg { background: #FEF2F2; color: var(--ux-danger); }
    .ux-success-bg { background: #ECFDF5; color: var(--ux-success); }

    /* Tabela de Avaliações */
    .ux-table-card {
        background: var(--ux-card);
        border-radius: 12px;
        border: 1px solid var(--ux-border);
        overflow: hidden;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    }

    .data-table { width: 100%; border-collapse: collapse; }
    .data-table thead th {
        background: #F9FAFB;
        padding: 16px 20px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: var(--ux-text-sub);
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .data-table tbody td {
        padding: 16px 20px;
        border-bottom: 1px solid var(--ux-border);
        color: var(--ux-text-main);
    }

    .data-table tbody tr:hover td { background: #F9FAFB; }

    /* Estrelas UX */
    .rating-star { color: #FBBF24; font-size: 16px; text-shadow: 0 0 2px rgba(251,191,36,0.2); }
    .rating-empty { color: #D1D5DB; font-size: 16px; }

    /* Paginação Moderna */
    .ux-pagination {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 20px;
        padding: 10px 0;
    }

    .ux-page-info { font-size: 13px; color: var(--ux-text-sub); font-weight: 500; }

    .ux-nav-btns { display: flex; gap: 8px; }

    .ux-btn-nav {
        padding: 8px 14px;
        background: #fff;
        border: 1px solid var(--ux-border);
        border-radius: 6px;
        color: var(--ux-text-main);
        text-decoration: none;
        font-size: 12px;
        font-weight: 600;
        transition: all 0.2s;
    }

    .ux-btn-nav:hover:not(.disabled) {
        background: var(--ux-primary);
        color: #fff;
        border-color: var(--ux-primary);
    }

    .ux-btn-nav.disabled { opacity: 0.4; cursor: not-allowed; }

    @media (max-width: 900px) { .ux-grid { grid-template-columns: 1fr; } }
</style>

<div class="admin-header">
    <h2>⭐ Avaliações das Aulas</h2>
</div>

<div class="ux-filter-area">
    <form method="get">
        <input type="hidden" name="page" value="<?php echo esc_attr($current_page_slug); ?>">
        <input type="hidden" name="tab" value="<?php echo esc_attr($current_tab); ?>">
        <select name="curso" onchange="this.form.submit()" class="ux-selector">
            <option value="">Todos os cursos disponíveis</option>
            <?php foreach ($cursos as $c) : ?>
            <option value="<?php echo $c->ID; ?>" <?php selected($curso_filter, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
            <?php endforeach; ?>
        </select>
    </form>
    <div class="ux-badge-total">
        <span>📊</span> <?php echo count($ratings); ?> Avaliações filtradas
    </div>
</div>

<div class="ux-grid">
    <div class="ux-card">
        <h3>⚠️ Aulas que precisam de atenção</h3>
        <?php if (empty($paged_low_rated)) : ?>
            <p style="color:var(--ux-text-sub); text-align:center; padding:20px;">Excelente! Nenhuma aula com notas baixas.</p>
        <?php else : ?>
            <?php foreach ($paged_low_rated as $s) : ?>
            <div class="ux-list-item">
                <div>
                    <div class="ux-item-title"><?php echo esc_html($s['aula']->post_title); ?></div>
                    <div class="ux-item-sub"><?php echo esc_html($s['curso']->post_title); ?></div>
                </div>
                <div class="ux-avg-badge ux-danger-bg">
                    <span>★</span> <?php echo $s['avg']; ?>
                    <span style="font-size:10px; font-weight:400; opacity:0.8;">(<?php echo $s['total']; ?>)</span>
                </div>
            </div>
            <?php endforeach; ?>
            
            <div class="ux-pagination">
                <span class="ux-page-info"><?php echo $current_p_low; ?> de <?php echo $total_p_low; ?></span>
                <div class="ux-nav-btns">
                    <a href="<?php echo add_query_arg('p_low', max(1, $current_p_low - 1)); ?>" class="ux-btn-nav <?php echo $current_p_low == 1 ? 'disabled' : ''; ?>">«</a>
                    <a href="<?php echo add_query_arg('p_low', min($total_p_low, $current_p_low + 1)); ?>" class="ux-btn-nav <?php echo $current_p_low == $total_p_low ? 'disabled' : ''; ?>">»</a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="ux-card">
        <h3>🏆 Aulas mais bem avaliadas</h3>
        <?php if (empty($paged_high_rated)) : ?>
            <p style="color:var(--ux-text-sub); text-align:center; padding:20px;">Aguardando as primeiras avaliações positivas.</p>
        <?php else : ?>
            <?php foreach ($paged_high_rated as $s) : ?>
            <div class="ux-list-item">
                <div>
                    <div class="ux-item-title"><?php echo esc_html($s['aula']->post_title); ?></div>
                    <div class="ux-item-sub"><?php echo esc_html($s['curso']->post_title); ?></div>
                </div>
                <div class="ux-avg-badge ux-success-bg">
                    <span>★</span> <?php echo $s['avg']; ?>
                    <span style="font-size:10px; font-weight:400; opacity:0.8;">(<?php echo $s['total']; ?>)</span>
                </div>
            </div>
            <?php endforeach; ?>
            
            <div class="ux-pagination">
                <span class="ux-page-info"><?php echo $current_p_high; ?> de <?php echo $total_p_high; ?></span>
                <div class="ux-nav-btns">
                    <a href="<?php echo add_query_arg('p_high', max(1, $current_p_high - 1)); ?>" class="ux-btn-nav <?php echo $current_p_high == 1 ? 'disabled' : ''; ?>">«</a>
                    <a href="<?php echo add_query_arg('p_high', min($total_p_high, $current_p_high + 1)); ?>" class="ux-btn-nav <?php echo $current_p_high == $total_p_high ? 'disabled' : ''; ?>">»</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="ux-table-card">
    <div style="padding: 24px; border-bottom: 1px solid var(--ux-border);">
        <h3 style="margin:0; font-size:16px;">📋 Histórico Completo de Avaliações</h3>
    </div>
    <?php if (empty($paged_all_ratings)) : ?>
        <p style="color:var(--ux-text-sub); text-align:center; padding:40px;">Nenhum registro encontrado para este filtro.</p>
    <?php else : ?>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Aluno</th>
                    <th>Aula / Curso</th>
                    <th style="text-align: center;">Nota</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($paged_all_ratings as $r) : ?>
                <tr>
                    <td>
                        <div style="font-weight:700; font-size:14px;"><?php echo $r['user'] ? esc_html($r['user']->display_name) : 'Membro Inativo'; ?></div>
                        <div style="font-size:12px; color:var(--ux-text-sub);"><?php echo $r['user'] ? esc_html($r['user']->user_email) : ''; ?></div>
                    </td>
                    <td>
                        <div style="font-weight:500;"><?php echo esc_html($r['aula']->post_title); ?></div>
                        <div style="font-size:11px; color:var(--ux-text-sub); text-transform: uppercase;"><?php echo esc_html($r['curso']->post_title); ?></div>
                    </td>
                    <td style="text-align: center;">
                        <div style="display:flex; justify-content:center; gap:3px;">
                            <?php for ($i = 1; $i <= 5; $i++) : ?>
                                <span class="<?php echo $i <= $r['rating'] ? 'rating-star' : 'rating-empty'; ?>">★</span>
                            <?php endfor; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div style="padding: 20px; background: #fff; display: flex; justify-content: center; align-items: center; gap: 20px;">
            <span class="ux-page-info">Mostrando página <strong><?php echo $current_p_all; ?></strong> de <?php echo $total_p_all; ?></span>
            <div class="ux-nav-btns">
                <a href="<?php echo add_query_arg('p_all', max(1, $current_p_all - 1)); ?>" class="ux-btn-nav <?php echo $current_p_all == 1 ? 'disabled' : ''; ?>">← Anterior</a>
                <a href="<?php echo add_query_arg('p_all', min($total_p_all, $current_p_all + 1)); ?>" class="ux-btn-nav <?php echo $current_p_all == $total_p_all ? 'disabled' : ''; ?>">Próxima →</a>
            </div>
        </div>
    <?php endif; ?>
</div>