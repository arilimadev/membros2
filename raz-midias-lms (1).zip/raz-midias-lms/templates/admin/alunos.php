<?php
/**
 * Admin: Alunos - VERSÃO CORRIGIDA
 * - Botões de fechar modal com type="button"
 * - Grupos de acesso funcionando
 */
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

$filter_curso = isset($_GET['curso_id']) ? intval($_GET['curso_id']) : 0;
$filter_status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$filter_origem = isset($_GET['origem']) ? sanitize_text_field($_GET['origem']) : '';
$search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
$current_page = isset($_GET['pag']) ? max(1, intval($_GET['pag'])) : 1;
$per_page = 10;

global $wpdb;

$where = "WHERE 1=1";

if ($search) {
    $where .= $wpdb->prepare(" AND (u.user_email LIKE %s OR u.display_name LIKE %s)", '%' . $search . '%', '%' . $search . '%');
}

if ($filter_curso) {
    $where .= $wpdb->prepare(" AND u.ID IN (SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s)", '_raz_curso_acesso_' . $filter_curso);
}

if ($filter_origem) {
    $where .= $wpdb->prepare(" AND u.ID IN (SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%' AND meta_value LIKE %s)", '%' . $filter_origem . '%');
}

$query_base = "FROM {$wpdb->users} u {$where}";
$total = $wpdb->get_var("SELECT COUNT(u.ID) {$query_base}");

$offset = ($current_page - 1) * $per_page;
$total_pages = ceil($total / $per_page);

$alunos = $wpdb->get_results("SELECT u.ID as user_id, u.user_email, u.display_name {$query_base} ORDER BY u.display_name ASC LIMIT {$per_page} OFFSET {$offset}");
?>

<style>
.filters-form { display: flex; gap: 12px; margin-bottom: 24px; flex-wrap: wrap; align-items: center; }
.filters-form input[type="text"], .filters-form select { padding: 10px 14px; border: 1px solid var(--border); border-radius: 8px; font-size: 14px; background: #fff; }
.filters-form input[type="text"] { flex: 1; min-width: 200px; }
.filters-form select { min-width: 140px; }

.aluno-modal { position: fixed; inset: 0; background: rgba(0,0,0,0.6); display: none; align-items: center; justify-content: center; z-index: 1000; padding: 20px; }
.aluno-modal.open { display: flex; }
.aluno-modal-content { background: #fff; border-radius: 12px; max-height: 90vh; overflow-y: auto; width: 100%; max-width: 750px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
.aluno-modal-header { display: flex; justify-content: space-between; align-items: center; padding: 20px 24px; border-bottom: 1px solid var(--border); position: sticky; top: 0; background: #fff; z-index: 10; }
.aluno-modal-header h3 { margin: 0; font-size: 18px; }
.aluno-modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--muted); line-height: 1; padding: 4px 8px; }
.aluno-modal-close:hover { color: var(--danger); }
.aluno-modal-body { padding: 24px; }
.aluno-modal-footer { display: flex; justify-content: flex-end; gap: 12px; padding: 16px 24px; border-top: 1px solid var(--border); position: sticky; bottom: 0; background: #fff; }

.form-group { margin-bottom: 18px; }
.form-group label { display: block; margin-bottom: 6px; font-weight: 500; font-size: 13px; color: #1e293b; }
.form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px; border: 1px solid var(--border); border-radius: 6px; font-size: 14px; }
.form-group small { font-size: 11px; color: var(--muted); display: block; margin-top: 4px; }

.curso-checkbox-wrapper { padding: 8px; border-radius: 6px; transition: background 0.2s; cursor: pointer; }
.curso-checkbox-wrapper:hover { background: #f8fafc; }
.curso-checkbox-wrapper input[type="checkbox"] { margin-right: 10px; cursor: pointer; }

.grupos-por-curso { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-top: 12px; }
.grupos-por-curso h5 { margin: 0 0 12px 0; font-size: 13px; color: #64748b; font-weight: 600; }
.grupo-checkbox-mini { display: inline-flex; align-items: center; padding: 8px 12px; background: #fff; border: 1px solid #e2e8f0; border-radius: 6px; margin-right: 8px; margin-bottom: 8px; cursor: pointer; transition: all 0.2s; }
.grupo-checkbox-mini:hover { border-color: #0284c7; background: #eff6ff; }
.grupo-checkbox-mini.checked { background: #dbeafe; border-color: #0284c7; }
.grupo-checkbox-mini input { margin-right: 6px; cursor: pointer; }

.audit-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
.audit-card { background: var(--bg); padding: 16px; border-radius: 8px; }
.audit-card h4 { font-size: 14px; margin-bottom: 10px; display: flex; align-items: center; gap: 6px; }
.audit-card p { font-size: 13px; color: var(--muted); margin-bottom: 6px; }
.audit-card .value { color: var(--text); font-weight: 500; }
.audit-table { width: 100%; font-size: 12px; }
.audit-table th, .audit-table td { padding: 10px 8px; text-align: left; border-bottom: 1px solid var(--border); }
.audit-table th { background: var(--bg); font-weight: 600; }

.action-link { font-size: 12px; color: var(--primary); cursor: pointer; text-decoration: none; padding: 4px 8px; border-radius: 4px; white-space: nowrap; }
.action-link:hover { background: rgba(99, 102, 241, 0.1); }

.cursos-badge { cursor: pointer; background: var(--primary); color: #fff; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 500; }
.cursos-badge:hover { opacity: 0.9; }

.dias-sem-acesso { font-size: 11px; color: var(--muted); }
.dias-sem-acesso.alerta { color: var(--danger); font-weight: 500; }

.origem-badge { font-size: 10px; padding: 2px 6px; border-radius: 4px; text-transform: uppercase; }
.origem-badge.manual { background: #e0e7ff; color: #4338ca; }
.origem-badge.kiwify { background: #d1fae5; color: #065f46; }
.origem-badge.woocommerce { background: #fef3c7; color: #92400e; }

.cursos-list { margin-top: 12px; }
.curso-item { display: flex; justify-content: space-between; align-items: center; padding: 10px; background: var(--bg); border-radius: 6px; margin-bottom: 8px; }
.curso-item-name { font-weight: 500; font-size: 13px; }
.curso-item-exp { font-size: 11px; color: var(--muted); }
.curso-item-exp.vitalicio { color: var(--success); }
.curso-item-exp.expirado { color: var(--danger); }

.pagination-mini { display: flex; align-items: center; gap: 8px; justify-content: center; margin-top: 12px; }
.pagination-mini button { padding: 4px 10px; font-size: 11px; border: 1px solid var(--border); background: #fff; border-radius: 4px; cursor: pointer; }
.pagination-mini button:disabled { opacity: 0.5; cursor: not-allowed; }
.pagination-mini span { font-size: 11px; color: var(--muted); }

@media (max-width: 768px) {
    .filters-form { flex-direction: column; }
    .filters-form input[type="text"], .filters-form select { width: 100%; }
    .audit-grid { grid-template-columns: 1fr; }
    .aluno-modal-content { max-width: 100%; margin: 10px; }
}
</style>

<div class="admin-header">
    <h2>Alunos</h2>
    <button class="btn btn-primary" onclick="openAddModal()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Novo Aluno
    </button>
</div>

<form method="get" action="<?php echo home_url('/gestao-cursos/alunos/'); ?>" class="filters-form">
    <input type="text" name="s" placeholder="Buscar por nome ou email..." value="<?php echo esc_attr($search); ?>">
    <select name="curso_id">
        <option value="">Todos os cursos</option>
        <?php foreach ($cursos as $c) : ?>
        <option value="<?php echo $c->ID; ?>" <?php selected($filter_curso, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
        <?php endforeach; ?>
    </select>
    <select name="status">
        <option value="">Todos status</option>
        <option value="ativo" <?php selected($filter_status, 'ativo'); ?>>Ativos</option>
        <option value="expirado" <?php selected($filter_status, 'expirado'); ?>>Expirados</option>
    </select>
    <select name="origem">
        <option value="">Todas origens</option>
        <option value="manual" <?php selected($filter_origem, 'manual'); ?>>Manual</option>
        <option value="kiwify" <?php selected($filter_origem, 'kiwify'); ?>>Kiwify</option>
        <option value="woocommerce" <?php selected($filter_origem, 'woocommerce'); ?>>WooCommerce</option>
    </select>
    <button type="submit" class="btn btn-secondary">Filtrar</button>
    <?php if ($search || $filter_curso || $filter_status || $filter_origem) : ?>
    <a href="<?php echo home_url('/gestao-cursos/alunos/'); ?>" class="btn btn-sm" style="color:var(--muted);">Limpar</a>
    <?php endif; ?>
</form>

<div class="table-card">
    <table class="data-table">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Cursos</th>
                <th>Último Acesso</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($alunos) : ?>
                <?php foreach ($alunos as $a) :
                    $user_id = $a->user_id;
                    
                    // Tenta buscar último acesso em diferentes meta_keys possíveis
                    $ultimo_acesso = get_user_meta($user_id, '_raz_ultimo_acesso', true);
                    
                    if (empty($ultimo_acesso)) {
                        $ultimo_acesso = get_user_meta($user_id, '_raz_last_login', true);
                    }
                    
                    if (empty($ultimo_acesso)) {
                        $ultimo_acesso = get_user_meta($user_id, 'last_login', true);
                    }
                    
                    if ($ultimo_acesso && is_numeric($ultimo_acesso)) {
                        $last_date = date('d/m/Y H:i', $ultimo_acesso);
                        $dias_sem_acesso = floor((time() - $ultimo_acesso) / 86400);
                    } elseif ($ultimo_acesso && strtotime($ultimo_acesso)) {
                        $last_date = date('d/m/Y H:i', strtotime($ultimo_acesso));
                        $dias_sem_acesso = floor((time() - strtotime($ultimo_acesso)) / 86400);
                    } else {
                        // Se nenhum último acesso, verifica se tem algum curso e pega a data de registro
                        $tem_cursos = $wpdb->get_var($wpdb->prepare(
                            "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE '_raz_curso_acesso_%'",
                            $user_id
                        ));
                        
                        if ($tem_cursos > 0) {
                            $user_obj = get_userdata($user_id);
                            $last_date = date('d/m/Y H:i', strtotime($user_obj->user_registered));
                            $dias_sem_acesso = floor((time() - strtotime($user_obj->user_registered)) / 86400);
                        } else {
                            $last_date = 'Nunca';
                            $dias_sem_acesso = null;
                        }
                    }
                    
                    $telefone = get_user_meta($user_id, '_raz_user_telefone', true) ?: '-';
                    
                    $cursos_count = $wpdb->get_var($wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE '_raz_curso_acesso_%'",
                        $user_id
                    ));
                    
                    $origem_meta = get_user_meta($user_id, '_raz_user_origem', true);
                    $origem = $origem_meta ?: 'manual';
                    $origem_class = 'manual';
                    if (strpos($origem, 'kiwify') !== false) $origem_class = 'kiwify';
                    if (strpos($origem, 'woocommerce') !== false) $origem_class = 'woocommerce';
                ?>
                <tr>
                    <td>
                        <div><?php echo esc_html($a->display_name); ?></div>
                        <span class="origem-badge <?php echo $origem_class; ?>"><?php echo esc_html($origem); ?></span>
                    </td>
                    <td><?php echo esc_html($a->user_email); ?></td>
                    <td><?php echo esc_html($telefone); ?></td>
                    <td>
                        <?php if ($cursos_count > 0) : ?>
                        <span class="cursos-badge" onclick="showUserCursos(<?php echo $user_id; ?>, '<?php echo esc_js($a->display_name); ?>')">
                            <?php echo $cursos_count; ?> curso<?php echo $cursos_count > 1 ? 's' : ''; ?>
                        </span>
                        <?php else : ?>
                        <span style="color:var(--muted);font-size:12px;">Nenhum</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div><?php echo $last_date; ?></div>
                        <?php if ($dias_sem_acesso !== null && $dias_sem_acesso >= 0) : ?>
                        <div class="dias-sem-acesso <?php echo $dias_sem_acesso > 30 ? 'alerta' : ''; ?>">
                            <?php echo $dias_sem_acesso == 0 ? 'Hoje' : $dias_sem_acesso . ' dia' . ($dias_sem_acesso > 1 ? 's' : '') . ' atrás'; ?>
                        </div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            <a href="javascript:void(0)" class="action-link" onclick="editUser(<?php echo $user_id; ?>)">✏️ Editar</a>
                            <a href="javascript:void(0)" class="action-link" onclick="showUserAudit(<?php echo $user_id; ?>, '<?php echo esc_js($a->display_name); ?>')">📊 Auditoria</a>
                            <a href="javascript:void(0)" class="action-link" style="color:var(--danger);" onclick="deleteUser(<?php echo $user_id; ?>)">🗑️ Excluir</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="6" style="text-align:center;padding:40px;color:var(--muted);">
                        Nenhum aluno encontrado
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php if ($total_pages > 1) : ?>
<div class="pagination">
    <?php
    $base_url = home_url('/gestao-cursos/alunos/');
    $query_params = array();
    if ($search) $query_params['s'] = $search;
    if ($filter_curso) $query_params['curso_id'] = $filter_curso;
    if ($filter_status) $query_params['status'] = $filter_status;
    if ($filter_origem) $query_params['origem'] = $filter_origem;
    
    if ($current_page > 1) :
        $prev_params = $query_params;
        $prev_params['pag'] = $current_page - 1;
        $prev_url = add_query_arg($prev_params, $base_url);
    ?>
    <a href="<?php echo esc_url($prev_url); ?>" class="btn btn-sm">← Anterior</a>
    <?php endif; ?>
    
    <span style="padding:0 16px;font-size:14px;">Página <?php echo $current_page; ?> de <?php echo $total_pages; ?></span>
    
    <?php if ($current_page < $total_pages) :
        $next_params = $query_params;
        $next_params['pag'] = $current_page + 1;
        $next_url = add_query_arg($next_params, $base_url);
    ?>
    <a href="<?php echo esc_url($next_url); ?>" class="btn btn-sm">Próxima →</a>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Modal: Adicionar/Editar Aluno -->
<div id="user-modal" class="aluno-modal">
    <div class="aluno-modal-content">
        <div class="aluno-modal-header">
            <h3 id="modal-title">Novo Aluno</h3>
            <button type="button" class="aluno-modal-close" onclick="closeModal()">&times;</button>
        </div>
        <div class="aluno-modal-body">
            <form id="user-form">
                <input type="hidden" name="user_id" id="user_id">
                
                <div class="form-group">
                    <label>Nome Completo *</label>
                    <input type="text" name="user_name" id="user_name" required>
                </div>
                
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="user_email" id="user_email" required>
                </div>
                
                <div class="form-group">
                    <label>Telefone (WhatsApp)</label>
                    <input type="tel" name="user_telefone" id="user_telefone" placeholder="(00) 00000-0000">
                </div>
                
                <div class="form-group">
                    <label>Senha <span style="font-size:12px;color:var(--muted);">(deixe em branco para manter/gerar)</span></label>
                    <input type="password" name="user_password" id="user_password">
                </div>
                
                <div class="form-group">
                    <label>Tipo de Acesso</label>
                    <select name="acesso_tipo" id="form_acesso_tipo" onchange="toggleDiasField()">
                        <option value="dias">Por Período (Dias)</option>
                        <option value="assinatura">Assinatura (Recorrente)</option>
                        <option value="vitalicio">Vitalício</option>
                    </select>
                </div>
                
                <div class="form-group" id="dias-group">
                    <label>Dias de Acesso</label>
                    <input type="number" name="dias_acesso" id="form_dias" value="365" min="1">
                    <small>Quantidade de dias que o aluno terá acesso aos cursos</small>
                </div>
                
                <div class="form-group">
                    <label>Cursos com Acesso</label>
                    <div id="cursos-checkboxes" style="max-height:250px; overflow-y:auto; border:1px solid var(--border); border-radius:8px; padding:12px;">
                        <?php foreach ($cursos as $curso) : ?>
                        <div class="curso-checkbox-wrapper">
                            <label style="display:flex;align-items:center;cursor:pointer;">
                                <input 
                                    type="checkbox" 
                                    name="user_cursos[]" 
                                    value="<?php echo $curso->ID; ?>"
                                    data-curso-id="<?php echo $curso->ID; ?>"
                                    data-curso-nome="<?php echo esc_attr($curso->post_title); ?>"
                                    onchange="toggleGruposCurso(this)"
                                >
                                <span style="font-size:14px; font-weight:500;"><?php echo esc_html($curso->post_title); ?></span>
                            </label>
                            
                            <!-- Container de grupos deste curso -->
                            <div id="grupos-curso-<?php echo $curso->ID; ?>" class="grupos-por-curso" style="display:none;">
                                <h5>🔐 Grupos de Acesso:</h5>
                                <div id="grupos-list-<?php echo $curso->ID; ?>">
                                    <!-- Será preenchido dinamicamente -->
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </form>
        </div>
        <div class="aluno-modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button>
            <button type="button" class="btn btn-primary" onclick="saveUser()">Salvar</button>
        </div>
    </div>
</div>

<!-- Modal: Ver Cursos -->
<div id="cursos-modal" class="aluno-modal">
    <div class="aluno-modal-content" style="max-width:500px;">
        <div class="aluno-modal-header">
            <h3 id="cursos-modal-title">Cursos do Aluno</h3>
            <button type="button" class="aluno-modal-close" onclick="closeCursosModal()">&times;</button>
        </div>
        <div class="aluno-modal-body">
            <div id="cursos-content"></div>
        </div>
    </div>
</div>

<!-- Modal: Auditoria -->
<div id="audit-modal" class="aluno-modal">
    <div class="aluno-modal-content" style="max-width:900px;">
        <div class="aluno-modal-header">
            <h3 id="audit-modal-title">Auditoria</h3>
            <button type="button" class="aluno-modal-close" onclick="closeAuditModal()">&times;</button>
        </div>
        <div class="aluno-modal-body">
            <div id="audit-content"></div>
        </div>
    </div>
</div>

<script>
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
var nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';
var currentEditUserId = 0;
var cursosGrupos = {}; // Cache de grupos por curso

function toggleDiasField() {
    var tipo = document.getElementById('form_acesso_tipo').value;
    var diasGroup = document.getElementById('dias-group');
    diasGroup.style.display = (tipo === 'vitalicio') ? 'none' : 'block';
}

// Mostra/oculta grupos quando seleciona curso
function toggleGruposCurso(checkbox) {
    var cursoId = checkbox.getAttribute('data-curso-id');
    var gruposContainer = document.getElementById('grupos-curso-' + cursoId);
    
    if (checkbox.checked) {
        gruposContainer.style.display = 'block';
        // Carregar grupos do curso se ainda não carregou
        if (!cursosGrupos[cursoId]) {
            loadGruposCurso(cursoId);
        }
    } else {
        gruposContainer.style.display = 'none';
    }
}

// Carrega grupos de um curso específico
function loadGruposCurso(cursoId) {
    var container = document.getElementById('grupos-list-' + cursoId);
    container.innerHTML = '<p style="font-size:12px;color:var(--muted);">Carregando...</p>';
    
    console.log('Carregando grupos do curso:', cursoId);
    
    fetch(ajaxurl + '?action=raz_get_curso_grupos&nonce=' + nonce + '&curso_id=' + cursoId)
        .then(r => r.json())
        .then(data => {
            console.log('Resposta grupos curso ' + cursoId + ':', data);
            
            if (data.success && data.data && data.data.grupos) {
                cursosGrupos[cursoId] = data.data.grupos;
                renderGruposCurso(cursoId, data.data.grupos);
            } else {
                console.error('Grupos não encontrados para curso', cursoId, data);
                container.innerHTML = '<p style="font-size:11px;color:var(--muted);font-style:italic;">Nenhum grupo configurado para este curso</p>';
            }
        })
        .catch(err => {
            console.error('Erro ao carregar grupos:', err);
            container.innerHTML = '<p style="font-size:11px;color:var(--danger);">Erro ao carregar grupos</p>';
        });
}

// Renderiza checkboxes de grupos
function renderGruposCurso(cursoId, grupos) {
    var container = document.getElementById('grupos-list-' + cursoId);
    var html = '';
    
    Object.keys(grupos).forEach(slug => {
        var grupo = grupos[slug];
        var modulosCount = (grupo.modulos || []).length;
        var isDefault = grupo.is_default || false;
        
        html += '<label class="grupo-checkbox-mini" onclick="toggleGrupoCheckbox(this, event)">';
        html += '<input type="checkbox" name="user_grupos[' + cursoId + '][]" value="' + slug + '" onclick="event.stopPropagation()">';
        html += '<span style="font-size:12px;">' + grupo.nome;
        if (isDefault) html += ' <span style="color:#92400e;">★</span>';
        html += ' (' + modulosCount + ' módulo' + (modulosCount !== 1 ? 's' : '') + ')</span>';
        html += '</label>';
    });
    
    container.innerHTML = html || '<p style="font-size:11px;color:var(--muted);">Nenhum grupo</p>';
}

function toggleGrupoCheckbox(label, event) {
    if (event) event.preventDefault();
    var checkbox = label.querySelector('input[type="checkbox"]');
    if (checkbox) {
        checkbox.checked = !checkbox.checked;
    }
    
    if (label.classList.contains('checked')) {
        label.classList.remove('checked');
    } else {
        label.classList.add('checked');
    }
}

function openAddModal() {
    currentEditUserId = 0;
    document.getElementById('modal-title').textContent = 'Novo Aluno';
    document.getElementById('user-form').reset();
    document.getElementById('user_id').value = '';
    document.getElementById('user-modal').classList.add('open');
    
    // Oculta todos os grupos
    document.querySelectorAll('.grupos-por-curso').forEach(el => el.style.display = 'none');
    
    toggleDiasField();
}

function closeModal() {
    var modal = document.getElementById('user-modal');
    if (modal) {
        modal.classList.remove('open');
    }
}

function closeCursosModal() { 
    var modal = document.getElementById('cursos-modal');
    if (modal) {
        modal.classList.remove('open');
    }
}

function closeAuditModal() { 
    var modal = document.getElementById('audit-modal');
    if (modal) {
        modal.classList.remove('open');
    }
}

function editUser(userId) {
    currentEditUserId = userId;
    document.getElementById('modal-title').textContent = 'Editar Aluno';
    document.getElementById('user-modal').classList.add('open');
    
    fetch(ajaxurl + '?action=raz_get_user&nonce=' + nonce + '&user_id=' + userId)
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                var u = d.data;
                document.getElementById('user_id').value = userId;
                document.getElementById('user_name').value = u.name;
                document.getElementById('user_email').value = u.email;
                document.getElementById('user_telefone').value = u.telefone || '';
                document.getElementById('user_password').value = '';
                
                if (u.acesso_tipo) {
                    document.getElementById('form_acesso_tipo').value = u.acesso_tipo;
                }
                
                if (u.dias_acesso) {
                    document.getElementById('form_dias').value = u.dias_acesso;
                }
                
                toggleDiasField();
                
                // Marca cursos e mostra grupos
                var checkboxes = document.querySelectorAll('input[name="user_cursos[]"]');
                checkboxes.forEach(cb => {
                    var cursoId = cb.getAttribute('data-curso-id');
                    if (u.cursos.indexOf(parseInt(cursoId)) > -1) {
                        cb.checked = true;
                        toggleGruposCurso(cb);
                    }
                });
                
                // Carrega grupos do usuário
                setTimeout(() => loadUserGrupos(userId), 500);
            } else {
                alert('Erro: ' + (d.data ? d.data.message : 'Usuário não encontrado'));
                closeModal();
            }
        })
        .catch(e => {
            console.error(e);
            alert('Erro ao carregar dados do usuário');
            closeModal();
        });
}

// Carrega grupos que o usuário já pertence
function loadUserGrupos(userId) {
    fetch(ajaxurl + '?action=raz_get_user_grupos_data&nonce=' + nonce + '&user_id=' + userId)
        .then(r => r.json())
        .then(d => {
            if (d.success && d.data) {
                Object.keys(d.data).forEach(cursoKey => {
                    var cursoId = cursoKey.replace('curso_', '');
                    var gruposUser = d.data[cursoKey];
                    
                    gruposUser.forEach(slug => {
                        var checkbox = document.querySelector('input[name="user_grupos[' + cursoId + '][]"][value="' + slug + '"]');
                        if (checkbox) {
                            checkbox.checked = true;
                            var label = checkbox.closest('.grupo-checkbox-mini');
                            if (label) label.classList.add('checked');
                        }
                    });
                });
            }
        });
}

function deleteUser(userId) {
    if (!confirm('Tem certeza que deseja excluir este aluno?\n\nTodos os dados dele serão perdidos.')) return;
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_delete_user&nonce=' + nonce + '&user_id=' + userId
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) { 
            location.reload(); 
        } else { 
            alert('Erro: ' + (d.data ? d.data.message : 'Desconhecido')); 
        }
    });
}

function saveUser() {
    var form = document.getElementById('user-form');
    
    // Validação manual antes de enviar
    var userName = document.getElementById('user_name').value.trim();
    var userEmail = document.getElementById('user_email').value.trim();
    
    if (!userName || !userEmail) {
        alert('Por favor, preencha nome e email');
        return;
    }
    
    // Coletar cursos selecionados
    var cursos = [];
    document.querySelectorAll('input[name="user_cursos[]"]:checked').forEach(function(cb) {
        cursos.push(cb.value);
    });
    
    // Coletar grupos selecionados
    var grupos = {};
    document.querySelectorAll('input[name^="user_grupos["]:checked').forEach(function(cb) {
        var match = cb.name.match(/user_grupos\[(\d+)\]\[\]/);
        if (match) {
            var cursoId = match[1];
            if (!grupos[cursoId]) {
                grupos[cursoId] = [];
            }
            grupos[cursoId].push(cb.value);
        }
    });
    
    // Montar dados manualmente
    var formData = new FormData();
    formData.append('action', 'raz_save_user');
    formData.append('nonce', nonce);
    formData.append('user_id', document.getElementById('user_id').value || '');
    formData.append('user_name', userName);
    formData.append('user_email', userEmail);
    formData.append('user_telefone', document.getElementById('user_telefone').value || '');
    formData.append('user_password', document.getElementById('user_password').value || '');
    formData.append('acesso_tipo', document.getElementById('form_acesso_tipo').value);
    formData.append('dias_acesso', document.getElementById('form_dias').value);
    
    // Adicionar cursos
    cursos.forEach(function(cursoId) {
        formData.append('user_cursos[]', cursoId);
    });
    
    // Adicionar grupos
    Object.keys(grupos).forEach(function(cursoId) {
        grupos[cursoId].forEach(function(grupoSlug) {
            formData.append('user_grupos[' + cursoId + '][]', grupoSlug);
        });
    });
    
    // Debug: veja o que está sendo enviado
    console.log('Dados enviados:', {
        user_id: formData.get('user_id'),
        user_name: formData.get('user_name'),
        user_email: formData.get('user_email'),
        cursos: cursos,
        grupos: grupos
    });
    
    fetch(ajaxurl, { method: 'POST', body: formData })
    .then(r => {
        console.log('Status HTTP:', r.status);
        console.log('Headers:', r.headers);
        return r.text(); // Primeiro pega como texto
    })
    .then(text => {
        console.log('Resposta RAW do servidor:', text);
        
        // Tenta fazer parse do JSON
        try {
            var d = JSON.parse(text);
            console.log('JSON parseado:', d);
            
            if (d.success) { 
                location.reload(); 
            } else {
                // Mostrar debug se disponível
                if (d.data && d.data.debug) {
                    console.error('Debug do servidor:', d.data.debug);
                    
                    // Montar mensagem detalhada
                    var debugMsg = 'Erro: ' + d.data.message + '\n\n';
                    debugMsg += 'DEBUG:\n';
                    debugMsg += '- Raw name: "' + d.data.debug.name_raw + '"\n';
                    debugMsg += '- Raw email: "' + d.data.debug.email_raw + '"\n';
                    debugMsg += '- Sanitized name: "' + d.data.debug.name_sanitized + '"\n';
                    debugMsg += '- Sanitized email: "' + d.data.debug.email_sanitized + '"\n';
                    debugMsg += '- Name length: ' + d.data.debug.name_length + '\n';
                    debugMsg += '- Email length: ' + d.data.debug.email_length + '\n';
                    debugMsg += '- POST keys: ' + JSON.stringify(d.data.debug.post_keys) + '\n';
                    debugMsg += '- isset user_name: ' + d.data.debug.isset_user_name + '\n';
                    debugMsg += '- isset user_email: ' + d.data.debug.isset_user_email;
                    
                    alert(debugMsg);
                } else {
                    alert('Erro: ' + (d.data ? d.data.message : 'Desconhecido')); 
                }
            }
        } catch (e) {
            console.error('Erro ao fazer parse do JSON:', e);
            console.error('Texto recebido:', text);
            alert('Erro: Resposta inválida do servidor. Veja o console para detalhes.');
        }
    })
    .catch(e => {
        console.error('Erro na requisição:', e);
        alert('Erro ao salvar: ' + e.message);
    });
}

function showUserCursos(userId, userName) {
    document.getElementById('cursos-modal-title').textContent = 'Cursos de ' + userName;
    document.getElementById('cursos-modal').classList.add('open');
    document.getElementById('cursos-content').innerHTML = '<p style="text-align:center;padding:20px;color:var(--muted);">Carregando...</p>';
    
    fetch(ajaxurl + '?action=raz_get_user_cursos&nonce=' + nonce + '&user_id=' + userId)
        .then(r => r.json())
        .then(d => {
            if (d.success && d.data.length > 0) {
                var html = '<div class="cursos-list">';
                d.data.forEach(c => {
                    var expClass = c.vitalicio ? 'vitalicio' : (c.expirado ? 'expirado' : '');
                    var expText = c.vitalicio ? '♾️ Vitalício' : (c.expirado ? '❌ Expirado em ' + c.expiracao : '📅 Expira em ' + c.expiracao);
                    
                    html += '<div class="curso-item">';
                    html += '<div><span class="curso-item-name">' + c.nome + '</span></div>';
                    html += '<span class="curso-item-exp ' + expClass + '">' + expText + '</span>';
                    html += '</div>';
                });
                html += '</div>';
                document.getElementById('cursos-content').innerHTML = html;
            } else {
                document.getElementById('cursos-content').innerHTML = '<p style="text-align:center;color:var(--muted);">Nenhum curso encontrado</p>';
            }
        });
}

var auditPage = 1;
var auditUserId = 0;

function showUserAudit(userId, userName) {
    auditUserId = userId;
    auditPage = 1;
    document.getElementById('audit-modal-title').textContent = 'Auditoria: ' + userName;
    document.getElementById('audit-modal').classList.add('open');
    loadAuditData();
}

function loadAuditData() {
    document.getElementById('audit-content').innerHTML = '<p style="text-align:center;padding:40px;color:var(--muted);">Carregando...</p>';
    
    fetch(ajaxurl + '?action=raz_get_user_audit&nonce=' + nonce + '&user_id=' + auditUserId + '&page=' + auditPage)
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                var a = d.data;
                var html = '<div class="audit-grid">';
                
                html += '<div class="audit-card"><h4>📅 Último Acesso</h4>';
                html += '<p>Data: <span class="value">' + a.last_access.date + '</span></p>';
                html += '<p>Dias sem acessar: <span class="value">' + (a.last_access.dias_sem_acesso || '0') + '</span></p>';
                html += '<p>Curso: <span class="value">' + (a.last_access.curso || '-') + '</span></p>';
                html += '<p>Aula: <span class="value">' + (a.last_access.aula || '-') + '</span></p></div>';
                
                html += '<div class="audit-card"><h4>📍 Posição Atual</h4>';
                html += '<p>Módulo: <span class="value">' + (a.posicao.modulo || '-') + '</span></p>';
                html += '<p>Aula: <span class="value">' + (a.posicao.aula || '-') + '</span></p>';
                html += '<p>Progresso: <span class="value">' + (a.posicao.progresso || '0%') + '</span></p></div>';
                
                html += '<div class="audit-card"><h4>💻 Dispositivo</h4>';
                html += '<p>Navegador: <span class="value">' + (a.last_access.browser || '-') + '</span></p>';
                html += '<p>Sistema: <span class="value">' + (a.last_access.os || '-') + '</span></p>';
                html += '<p>IP: <span class="value">' + (a.last_access.ip || '-') + '</span></p></div>';
                
                html += '<div class="audit-card"><h4>👤 Informações</h4>';
                html += '<p>Cadastro: <span class="value">' + (a.user.registered || '-') + '</span></p>';
                html += '<p>Origem: <span class="value">' + (a.user.origem || 'manual') + '</span></p>';
                html += '<p>Total acessos: <span class="value">' + (a.total_acessos || '0') + '</span></p></div>';
                
                html += '</div>';
                
                html += '<h4 style="margin:20px 0 12px;">📜 Histórico de Acessos</h4>';
                html += '<div style="max-height:300px;overflow-y:auto;border:1px solid var(--border);border-radius:8px;">';
                html += '<table class="audit-table"><thead><tr><th>Data/Hora</th><th>Curso</th><th>Módulo</th><th>Aula</th><th>IP</th></tr></thead><tbody>';
                
                if (a.history && a.history.length) {
                    a.history.forEach(h => {
                        html += '<tr><td>' + h.date + '</td><td>' + h.curso + '</td><td>' + h.modulo + '</td><td>' + h.aula + '</td><td>' + h.ip + '</td></tr>';
                    });
                } else {
                    html += '<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:20px;">Nenhum acesso registrado</td></tr>';
                }
                
                html += '</tbody></table></div>';
                
                if (a.total_pages > 1) {
                    html += '<div class="pagination-mini">';
                    html += '<button onclick="auditPrev()" ' + (auditPage <= 1 ? 'disabled' : '') + '>← Anterior</button>';
                    html += '<span>Página ' + auditPage + ' de ' + a.total_pages + '</span>';
                    html += '<button onclick="auditNext(' + a.total_pages + ')" ' + (auditPage >= a.total_pages ? 'disabled' : '') + '>Próxima →</button>';
                    html += '</div>';
                }
                
                document.getElementById('audit-content').innerHTML = html;
            }
        });
}

function auditPrev() { if (auditPage > 1) { auditPage--; loadAuditData(); } }
function auditNext(max) { if (auditPage < max) { auditPage++; loadAuditData(); } }

// Event listeners para fechar modais
document.addEventListener('DOMContentLoaded', function() {
    // Fechar ao clicar fora do modal
    document.querySelectorAll('.aluno-modal').forEach(function(modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.classList.remove('open');
            }
        });
    });
    
    // Fechar ao pressionar ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.aluno-modal.open').forEach(function(modal) {
                modal.classList.remove('open');
            });
        }
    });
});

</script>