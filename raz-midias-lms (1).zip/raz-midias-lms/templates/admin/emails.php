<?php
/**
 * Admin: Configuração de Emails
 */
$email_boas_vindas = get_option('raz_lms_email_boas_vindas', array(
    'ativo' => '1',
    'assunto' => 'Bem-vindo ao {curso}!',
    'mensagem' => "Olá {nome},\n\nSeja bem-vindo ao curso {curso}!\n\nVocê já pode começar a estudar acessando:\n{link_curso}\n\nSeu acesso é válido até: {data_expiracao}\n\nBons estudos!\n{site_nome}"
));

$email_expirando = get_option('raz_lms_email_expirando', array(
    'ativo' => '1',
    'dias_antes' => '7',
    'assunto' => 'Seu acesso ao {curso} expira em breve!',
    'mensagem' => "Olá {nome},\n\nSeu acesso ao curso {curso} expira em {dias_restantes} dias ({data_expiracao}).\n\nAproveite para concluir seus estudos!\n{link_curso}\n\nCaso queira renovar seu acesso, entre em contato conosco.\n\n{site_nome}"
));

$email_conclusao = get_option('raz_lms_email_conclusao', array(
    'ativo' => '0',
    'assunto' => 'Parabéns! Você concluiu o curso {curso}!',
    'mensagem' => "Olá {nome},\n\nParabéns por concluir o curso {curso}! 🎉\n\nSeu certificado está disponível em:\n{link_certificado}\n\nContinue aprendendo!\n{site_nome}"
));

// Salvar se POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['raz_email_nonce']) && wp_verify_nonce($_POST['raz_email_nonce'], 'raz_save_emails')) {
    if (isset($_POST['boas_vindas'])) {
        update_option('raz_lms_email_boas_vindas', array_map('sanitize_textarea_field', $_POST['boas_vindas']));
        $email_boas_vindas = $_POST['boas_vindas'];
    }
    if (isset($_POST['expirando'])) {
        update_option('raz_lms_email_expirando', array_map('sanitize_textarea_field', $_POST['expirando']));
        $email_expirando = $_POST['expirando'];
    }
    if (isset($_POST['conclusao'])) {
        update_option('raz_lms_email_conclusao', array_map('sanitize_textarea_field', $_POST['conclusao']));
        $email_conclusao = $_POST['conclusao'];
    }
    echo '<div style="background:var(--success);color:#fff;padding:12px 20px;border-radius:8px;margin-bottom:24px;">✓ Configurações salvas com sucesso!</div>';
}
?>

<div class="admin-header">
    <h2>Configurar Emails</h2>
</div>

<form method="post">
    <?php wp_nonce_field('raz_save_emails', 'raz_email_nonce'); ?>
    
    <!-- Variáveis Disponíveis -->
    <div class="form-card" style="margin-bottom:24px;background:linear-gradient(135deg,#eff6ff,#dbeafe);">
        <h4 style="margin-bottom:12px;">📌 Variáveis Disponíveis</h4>
        <div style="display:flex;flex-wrap:wrap;gap:8px;">
            <code style="background:#fff;padding:4px 8px;border-radius:4px;font-size:13px;">{nome}</code>
            <code style="background:#fff;padding:4px 8px;border-radius:4px;font-size:13px;">{email}</code>
            <code style="background:#fff;padding:4px 8px;border-radius:4px;font-size:13px;">{curso}</code>
            <code style="background:#fff;padding:4px 8px;border-radius:4px;font-size:13px;">{link_curso}</code>
            <code style="background:#fff;padding:4px 8px;border-radius:4px;font-size:13px;">{data_expiracao}</code>
            <code style="background:#fff;padding:4px 8px;border-radius:4px;font-size:13px;">{dias_restantes}</code>
            <code style="background:#fff;padding:4px 8px;border-radius:4px;font-size:13px;">{site_nome}</code>
            <code style="background:#fff;padding:4px 8px;border-radius:4px;font-size:13px;">{site_url}</code>
        </div>
    </div>
    
    <!-- Email de Boas-vindas -->
    <div class="form-card" style="margin-bottom:24px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
            <h3>📧 Email de Boas-vindas</h3>
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                <input type="checkbox" name="boas_vindas[ativo]" value="1" <?php checked(isset($email_boas_vindas['ativo']) && $email_boas_vindas['ativo']); ?>>
                Ativo
            </label>
        </div>
        <p style="color:var(--muted);font-size:14px;margin-bottom:16px;">Enviado automaticamente quando um aluno recebe acesso ao curso.</p>
        
        <div class="form-group">
            <label>Assunto</label>
            <input type="text" name="boas_vindas[assunto]" value="<?php echo esc_attr($email_boas_vindas['assunto']); ?>">
        </div>
        
        <div class="form-group">
            <label>Mensagem</label>
            <textarea name="boas_vindas[mensagem]" rows="8"><?php echo esc_textarea($email_boas_vindas['mensagem']); ?></textarea>
        </div>
    </div>
    
    <!-- Email de Acesso Expirando -->
    <div class="form-card" style="margin-bottom:24px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
            <h3>⏰ Email de Acesso Expirando</h3>
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                <input type="checkbox" name="expirando[ativo]" value="1" <?php checked(isset($email_expirando['ativo']) && $email_expirando['ativo']); ?>>
                Ativo
            </label>
        </div>
        <p style="color:var(--muted);font-size:14px;margin-bottom:16px;">Enviado automaticamente X dias antes do acesso expirar.</p>
        
        <div class="form-group">
            <label>Enviar quantos dias antes</label>
            <input type="number" name="expirando[dias_antes]" value="<?php echo intval($email_expirando['dias_antes']); ?>" min="1" max="30" style="max-width:100px;">
        </div>
        
        <div class="form-group">
            <label>Assunto</label>
            <input type="text" name="expirando[assunto]" value="<?php echo esc_attr($email_expirando['assunto']); ?>">
        </div>
        
        <div class="form-group">
            <label>Mensagem</label>
            <textarea name="expirando[mensagem]" rows="8"><?php echo esc_textarea($email_expirando['mensagem']); ?></textarea>
        </div>
    </div>
    
    <!-- Email de Conclusão -->
    <div class="form-card" style="margin-bottom:24px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
            <h3>🎉 Email de Conclusão do Curso</h3>
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                <input type="checkbox" name="conclusao[ativo]" value="1" <?php checked(isset($email_conclusao['ativo']) && $email_conclusao['ativo']); ?>>
                Ativo
            </label>
        </div>
        <p style="color:var(--muted);font-size:14px;margin-bottom:16px;">Enviado quando o aluno completa 100% do curso.</p>
        
        <div class="form-group">
            <label>Assunto</label>
            <input type="text" name="conclusao[assunto]" value="<?php echo esc_attr($email_conclusao['assunto']); ?>">
        </div>
        
        <div class="form-group">
            <label>Mensagem</label>
            <textarea name="conclusao[mensagem]" rows="8"><?php echo esc_textarea($email_conclusao['mensagem']); ?></textarea>
        </div>
    </div>
    
    <button type="submit" class="btn btn-primary">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
        Salvar Configurações
    </button>
</form>
