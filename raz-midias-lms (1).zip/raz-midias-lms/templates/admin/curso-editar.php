<?php
/**
 * Admin: Editar Curso
 *
 * Estrutura:
 * - Edição de Curso com Textarea normal (Removido TinyMCE).
 * - Listagem de Módulos e Aulas.
 * - Links diretos para criação/edição de aulas (SEM MODAL).
 * - Sistema de Travamento e Duplicação.
 *
 * @package RazMidiasLMS
 * @version 5.2.0
 */

defined('ABSPATH') || exit;

// 1. Inicialização de Dados
$curso_id = isset($raz_item_id) ? intval($raz_item_id) : 0;
$curso = $curso_id ? get_post($curso_id) : null;

// Garante que a biblioteca de mídia esteja carregada
if (function_exists('wp_enqueue_media')) {
    wp_enqueue_media();
}

// Validação de segurança básica
if ($curso_id && (!$curso || $curso->post_type !== 'curso')) {
    echo '<div class="raz-admin-container"><div class="notice notice-error"><p>Curso não encontrado.</p></div></div>';
    return;
}

// Metas do Curso
$modulos = $curso_id ? raz_lms_get_modulos($curso_id) : array();
$kiwify_id = $curso_id ? get_post_meta($curso_id, '_raz_curso_kiwify_id', true) : '';
$dias_acesso = $curso_id ? (get_post_meta($curso_id, '_raz_curso_dias_acesso', true) ?: 365) : 365;
$vitalicio = $curso_id ? get_post_meta($curso_id, '_raz_curso_vitalicio', true) : '';
$tipo_acesso = $curso_id ? (get_post_meta($curso_id, '_raz_curso_tipo', true) ?: 'avulso') : 'avulso';

// Se vitalicio estava setado no modelo antigo, força tipo visual
if ($vitalicio) {
    $tipo_acesso = 'vitalicio';
}

$thumb_id = $curso_id ? get_post_thumbnail_id($curso_id) : 0;
$thumb_url = $thumb_id ? wp_get_attachment_image_url($thumb_id, 'medium') : '';
$cor_header = $curso_id ? get_post_meta($curso_id, '_raz_curso_cor_header', true) : '#667eea';
$cor_controls = $curso_id ? get_post_meta($curso_id, '_raz_curso_cor_controls', true) : '#1e293b';

if (!$cor_header) { $cor_header = '#667eea'; }
if (!$cor_controls) { $cor_controls = '#1e293b'; }

// Tab ativa (Verifica URL para manter a tab após redirecionamentos)
$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'info';

// Buscar todos os cursos para o modal de duplicação
$all_courses = get_posts(array(
    'post_type'      => 'curso',
    'posts_per_page' => -1,
    'orderby'        => 'title',
    'order'          => 'ASC',
    'post_status'    => 'publish'
));
?>

<style>
    .admin-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
    .tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 1px solid #ddd; }
    .tab { padding: 10px 20px; cursor: pointer; font-weight: 600; color: #64748b; border-bottom: 2px solid transparent; }
    .tab:hover { color: #1e293b; }
    .tab.active { color: #0284c7; border-bottom-color: #0284c7; }
    .tab-content { display: none; }
    
    .form-card { background: #fff; padding: 24px; border-radius: 8px; border: 1px solid #e2e8f0; margin-bottom: 20px; }
    .form-group { margin-bottom: 16px; }
    .form-group label { display: block; margin-bottom: 6px; font-weight: 500; font-size: 13px; color: #334155; }
    .form-group input[type="text"], .form-group select, .form-group input[type="number"], .form-group textarea { 
        width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 14px; 
    }
    .form-hint { font-size: 12px; color: #94a3b8; margin-top: 4px; }
    
    .btn { padding: 8px 16px; border-radius: 6px; cursor: pointer; border: none; font-size: 14px; font-weight: 500; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; }
    .btn:disabled { opacity: 0.6; cursor: not-allowed; }
    .btn-primary { background: #0284c7; color: #fff; }
    .btn-secondary { background: #fff; border: 1px solid #e2e8f0; color: #475569; }
    .btn-danger { background: #fee2e2; color: #ef4444; border: 1px solid #fecaca; padding: 6px 10px; }
    .btn-warning { background: #fff7ed; border: 1px solid #ffedd5; color: #c2410c; }
    
    .modulo-item { background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 12px; overflow: hidden; }
    .item-header { padding: 12px 16px; background: #f8fafc; display: flex; justify-content: space-between; align-items: center; cursor: pointer; border-bottom: 1px solid #e2e8f0; }
    .item-header:hover { background: #f1f5f9; }
    
    .item-drag { cursor: grab; color: #94a3b8; margin-right: 10px; }
    .badge { padding: 2px 8px; border-radius: 12px; font-size: 11px; background: #e0f2fe; color: #0284c7; margin-left: 10px; }
    
    .aulas-list { padding: 0; }
    .item-row { padding: 10px 16px 10px 40px; border-bottom: 1px solid #f1f5f9; display: flex; align-items: center; justify-content: space-between; background: #fff; }
    .item-row:last-child { border-bottom: none; }
    .item-row:hover { background: #f8fafc; }
    
    .sorting-disabled .item-drag { opacity: 0.3; cursor: not-allowed; }
    
    .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: none; align-items: center; justify-content: center; z-index: 1000; }
    .modal-overlay.open { display: flex; }
    .modal { background: #fff; width: 450px; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); padding: 20px; }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    
    .webhook-tutorial { margin-top: 30px; padding: 20px; background: #f0f9ff; border-radius: 8px; border: 1px solid #bae6fd; }
    .webhook-url-box { background: #fff; border: 1px dashed #7dd3fc; padding: 12px; border-radius: 6px; font-family: monospace; font-size: 12px; color: #0369a1; display: flex; justify-content: space-between; align-items: center; margin: 10px 0; }
    .tutorial-steps { padding-left: 18px; margin-bottom: 0; }
    .tutorial-steps li { font-size: 13px; color: #475569; margin-bottom: 8px; }

    /* Ajuste para que o Toast apareça na frente do modal */
    #raz-toast-container { z-index: 9999 !important; }
</style>

<div class="admin-header">
    <h2><?php echo $curso_id ? 'Editar Curso' : 'Novo Curso'; ?></h2>
    <a href="<?php echo home_url('/gestao-cursos/cursos'); ?>" class="btn btn-secondary">← Voltar</a>
</div>

<div class="tabs">
    <div class="tab <?php echo $active_tab === 'info' ? 'active' : ''; ?>" onclick="showTab('info',this)">Informações</div>
    <?php if ($curso_id) : ?>
    <div class="tab <?php echo $active_tab === 'conteudo' ? 'active' : ''; ?>" onclick="showTab('conteudo',this)">Conteúdo (Aulas)</div>
    <div class="tab <?php echo $active_tab === 'config' ? 'active' : ''; ?>" onclick="showTab('config',this)">Configurações</div>
    <?php endif; ?>
</div>

<div id="tab-info" class="tab-content" style="<?php echo $active_tab === 'info' ? 'display:block;' : 'display:none;'; ?>">
    <div class="form-card" style="max-width:800px;">
        <form id="form-curso" enctype="multipart/form-data">
            <input type="hidden" name="curso_id" value="<?php echo $curso_id; ?>">
            <input type="hidden" name="action" value="raz_save_curso">
            <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('raz_admin_nonce'); ?>">
            
            <div class="form-group">
                <label>Imagem do Curso</label>
                <div style="display:flex;gap:16px;align-items:flex-start;">
                    <div id="thumb-preview" style="width:200px;height:125px;background:linear-gradient(135deg,<?php echo esc_attr($cor_header); ?>,#764ba2);border-radius:12px;overflow:hidden;flex-shrink:0;">
                        <?php if ($thumb_url) : ?>
                        <img src="<?php echo esc_url($thumb_url); ?>" style="width:100%;height:100%;object-fit:cover;">
                        <?php endif; ?>
                    </div>
                    <div>
                        <input type="file" name="thumbnail" id="thumbnail-input" accept="image/*" style="display:none;">
                        <input type="hidden" name="thumbnail_id" id="thumbnail_id" value="<?php echo $thumb_id; ?>">
                        <button type="button" class="btn btn-secondary" onclick="document.getElementById('thumbnail-input').click()">Escolher Imagem</button>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label>Título do Curso *</label>
                <input type="text" name="titulo" value="<?php echo $curso ? esc_attr($curso->post_title) : ''; ?>" required>
            </div>
            
            <div class="form-group">
                <label>Descrição do Curso (Conteúdo)</label>
                <textarea name="descricao" id="descricao" rows="12"><?php echo $curso ? esc_textarea($curso->post_excerpt) : ''; ?></textarea>
            </div>

            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-top:20px;">
                <div class="form-group">
                    <label>Cor do Header</label>
                    <input type="color" name="cor_header" id="cor_header" value="<?php echo esc_attr($cor_header); ?>">
                </div>
                <div class="form-group">
                    <label>Cor dos Controles</label>
                    <input type="color" name="cor_controls" id="cor_controls" value="<?php echo esc_attr($cor_controls); ?>">
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary" style="margin-top:10px;">Salvar Curso</button>
        </form>
    </div>
</div>

<?php if ($curso_id) : ?>
<div id="tab-conteudo" class="tab-content" style="<?php echo $active_tab === 'conteudo' ? 'display:block;' : 'display:none;'; ?>">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
        <h3>Módulos e Aulas</h3>
        <div style="display:flex;gap:10px;">
            <button type="button" class="btn btn-secondary" id="toggle-sorting-btn" onclick="toggleGlobalSorting()">
                <span id="lock-icon">🔒</span> <span id="lock-text">Destravar Ordenação</span>
            </button>
            <button class="btn btn-primary" onclick="openModuloModal()">Novo Módulo</button>
        </div>
    </div>
    
    <div class="item-list sorting-disabled" id="modulos-list">
        <?php if (empty($modulos)) : ?>
        <div class="empty-state" style="padding:40px; text-align:center; background:#fff; border-radius:8px; border:1px dashed #cbd5e1;">
            <p>Nenhum módulo criado ainda.</p>
        </div>
        <?php else : 
            foreach ($modulos as $modulo) : 
                $aulas = raz_lms_get_aulas($modulo->ID); 
        ?>
        <div class="modulo-item sortable-item" data-id="<?php echo $modulo->ID; ?>">
            <div class="item-header" onclick="toggleModulo(this)">
                <div style="display:flex;align-items:center;gap:12px;">
                    <span class="item-drag" onclick="event.stopPropagation();">☰</span>
                    <strong><?php echo esc_html($modulo->post_title); ?></strong>
                    <span class="badge"><?php echo count($aulas); ?> aulas</span>
                </div>
                <div style="display:flex;gap:8px;">
                    <button class="btn btn-sm btn-secondary" onclick="event.stopPropagation();editModulo(<?php echo $modulo->ID; ?>,'<?php echo esc_js($modulo->post_title); ?>')">Editar</button>
                    <button class="btn btn-sm btn-secondary" onclick="event.stopPropagation();razOpenDuplicateModule(<?php echo $modulo->ID; ?>)">Duplicar</button>
                    <a href="<?php echo home_url('/gestao-cursos/aula-editar/?modulo=' . $modulo->ID . '&curso=' . $curso_id); ?>" class="btn btn-sm btn-primary" onclick="event.stopPropagation();">+ Aula</a>
                    <button class="btn btn-sm btn-danger" onclick="event.stopPropagation();deleteItem(<?php echo $modulo->ID; ?>,'modulo',this)">×</button>
                </div>
            </div>
            <div class="item-content aulas-list" id="aulas-<?php echo $modulo->ID; ?>" style="display:none;">
                <?php if (empty($aulas)) : ?>
                <div style="padding:15px;text-align:center;color:#94a3b8;font-size:13px;">Sem aulas neste módulo</div>
                <?php else : foreach ($aulas as $aula) : ?>
                <div class="item-row sortable-item" data-id="<?php echo $aula->ID; ?>">
                    <div style="display:flex; align-items:center; gap:12px; flex:1;">
                        <span class="item-drag">☰</span>
                        <span style="font-size:14px; text-align:left; flex:1;"><?php echo esc_html($aula->post_title); ?></span>
                    </div>
                    <div style="display:flex; gap:6px;">
                        <a href="<?php echo home_url('/gestao-cursos/aula-editar/' . $aula->ID . '?curso=' . $curso_id); ?>" class="btn btn-sm btn-secondary">Editar</a>
                        <button class="btn btn-sm btn-secondary" onclick="razOpenDuplicateLesson(<?php echo $aula->ID; ?>)">Duplicar</button>
                        <button class="btn btn-sm btn-danger" onclick="deleteItem(<?php echo $aula->ID; ?>,'aula',this)">×</button>
                    </div>
                </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
        <?php endforeach; endif; ?>
    </div>
    
    <!-- ============================================================
     GRUPOS DE ACESSO DO CURSO
     Sistema v2.0 - Controle por módulos
     ============================================================ -->
    <?php if ($curso_id) : ?>
        <?php include get_template_directory() . '/templates/grupos-acesso-component.php'; ?>
    <?php endif; ?>
    
</div>

<div id="tab-config" class="tab-content" style="<?php echo $active_tab === 'config' ? 'display:block;' : 'display:none;'; ?>">
    <div class="form-card" style="max-width:700px;">
        <form id="form-config">
            <input type="hidden" name="curso_id" value="<?php echo $curso_id; ?>">
            <h3 style="margin-bottom:20px;">Integração e Acesso</h3>
            <div class="form-group">
                <label>ID do Produto Kiwify</label>
                <input type="text" name="kiwify_id" value="<?php echo esc_attr($kiwify_id); ?>" placeholder="P_XXXXXXX">
            </div>
            <div class="form-row" style="display:flex; gap:20px;">
                <div class="form-group" style="flex:1;">
                    <label>Tipo de Acesso</label>
                    <select name="tipo" id="conf_tipo" onchange="toggleAccessDays()">
                        <option value="avulso" <?php selected($tipo_acesso, 'avulso'); ?>>Avulso</option>
                        <option value="assinatura" <?php selected($tipo_acesso, 'assinatura'); ?>>Assinatura</option>
                        <option value="vitalicio" <?php selected($tipo_acesso, 'vitalicio'); ?>>Vitalício</option>
                    </select>
                </div>
                <div class="form-group" id="conf_dias_group" style="flex:1;">
                    <label>Dias de Acesso</label>
                    <input type="number" name="dias_acesso" value="<?php echo intval($dias_acesso); ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Salvar Configurações</button>
        </form>

        <div class="webhook-tutorial">
            <h4 style="color:#0369a1;">🚀 Integração Automática (Kiwify Webhook)</h4>
            <p style="font-size:13px; color:#475569;">Copie a URL abaixo e cole nas configurações de Webhook do seu produto na Kiwify:</p>
            <div class="webhook-url-box">
                <span id="webhook-url-text"><?php echo get_rest_url(null, 'raz-lms/v1/kiwify'); ?></span>
                <button type="button" class="btn btn-sm btn-secondary" onclick="copyWebhookUrl()">Copiar</button>
            </div>
            <ul class="tutorial-steps">
                <li>1. No painel <strong>Kiwify</strong>, vá em <strong>Produtos</strong> e selecione este curso.</li>
                <li>2. Vá na aba <strong>Configurações</strong> > seção <strong>Webhooks</strong>.</li>
                <li>3. Clique em "Adicionar Webhook" e cole a URL acima.</li>
                <li>4. Selecione: <strong>Compra aprovada</strong>, <strong>Reembolso</strong> e <strong>Cancelamento</strong>.</li>
                <li>5. <strong>Importante para Assinaturas:</strong> Selecione também <strong>Assinatura renovada</strong> e <strong>Assinatura cancelada</strong>.</li>
                <li>6. Salve. O sistema agora criará e removerá alunos automaticamente.</li>
            </ul>
        </div>
    </div>
</div>

<div class="modal-overlay" id="modal-modulo">
    <div class="modal">
        <div class="modal-header">
            <h3 id="modal-modulo-title">Módulo</h3>
            <span onclick="closeModal('modal-modulo')" style="cursor:pointer; font-size:20px;">×</span>
        </div>
        <form id="form-modulo">
            <input type="hidden" name="modulo_id" id="modulo_id">
            <input type="hidden" name="curso_id" value="<?php echo $curso_id; ?>">
            <div class="form-group">
                <label>Nome do Módulo</label>
                <input type="text" name="titulo" id="modulo_titulo" required>
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
        </form>
    </div>
</div>

<div class="modal-overlay" id="modal-dup-aula">
    <div class="modal">
        <div class="modal-header"><h3>Duplicar Aula</h3><span onclick="closeModal('modal-dup-aula')" style="cursor:pointer;">×</span></div>
        <form id="form-dup-aula">
            <input type="hidden" name="source_id" id="dup_aula_source_id">
            <input type="hidden" name="type" value="aula">
            <div class="form-group">
                <label>Curso Destino</label>
                <select name="target_course_id" id="dup_aula_course_select" onchange="razLoadModulesForDup(this.value)">
                    <option value="">Selecione um curso...</option>
                    <?php foreach ($all_courses as $c): ?>
                        <option value="<?php echo $c->ID; ?>" <?php selected($c->ID, $curso_id); ?>><?php echo esc_html($c->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><label>Módulo Destino</label><select name="target_module_id" id="dup_aula_module_select" required></select></div>
            <button type="submit" class="btn btn-primary">Duplicar</button>
        </form>
    </div>
</div>

<div class="modal-overlay" id="modal-dup-modulo">
    <div class="modal">
        <div class="modal-header"><h3>Duplicar Módulo</h3><span onclick="closeModal('modal-dup-modulo')" style="cursor:pointer;">×</span></div>
        <form id="form-dup-modulo">
            <input type="hidden" name="source_id" id="dup_mod_source_id">
            <input type="hidden" name="type" value="modulo">
            <div class="form-group">
                <label>Curso Destino</label>
                <select name="target_course_id">
                    <?php foreach ($all_courses as $c): ?>
                        <option value="<?php echo $c->ID; ?>" <?php selected($c->ID, $curso_id); ?>><?php echo esc_html($c->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Duplicar Módulo</button>
        </form>
    </div>
</div>
<?php endif; ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js"></script>
<script>
var cursoId = <?php echo $curso_id ?: 0; ?>;
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
var nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';
var isSortingEnabled = false;
var sortableInstances = [];

function showTab(t, el) {
    document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(x => x.style.display = 'none');
    el.classList.add('active');
    document.getElementById('tab-' + t).style.display = 'block';
}

function toggleModulo(el) {
    var content = el.nextElementSibling;
    content.style.display = (content.style.display === 'none') ? 'block' : 'none';
}

function toggleAccessDays() {
    var type = document.getElementById('conf_tipo').value;
    document.getElementById('conf_dias_group').style.display = (type === 'vitalicio') ? 'none' : 'block';
}

function openModal(id) { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }

function openModuloModal(id, titulo) {
    document.getElementById('modulo_id').value = id || '';
    document.getElementById('modulo_titulo').value = titulo || '';
    document.getElementById('modal-modulo-title').textContent = id ? 'Editar Módulo' : 'Novo Módulo';
    openModal('modal-modulo');
}

function editModulo(id, title) { openModuloModal(id, title); }

function razOpenDuplicateModule(id) { 
    document.getElementById('dup_mod_source_id').value = id; 
    openModal('modal-dup-modulo'); 
}

function razOpenDuplicateLesson(id) {
    document.getElementById('dup_aula_source_id').value = id;
    document.getElementById('dup_aula_course_select').value = cursoId;
    razLoadModulesForDup(cursoId);
    openModal('modal-dup-aula');
}

function razLoadModulesForDup(cId) {
    var sel = document.getElementById('dup_aula_module_select');
    if(!cId) { sel.innerHTML = ''; return; }
    sel.innerHTML = '<option>Carregando...</option>';
    fetch(ajaxurl + '?action=raz_get_modules_by_course&nonce='+nonce+'&curso_id='+cId)
    .then(r=>r.json()).then(d=>{
        sel.innerHTML = '';
        if(d.success) d.data.forEach(m=>{
            var opt=document.createElement('option'); opt.value=m.id; opt.textContent=m.title; sel.appendChild(opt);
        });
    });
}

function toggleGlobalSorting() {
    isSortingEnabled = !isSortingEnabled;
    var btn = document.getElementById('toggle-sorting-btn');
    document.getElementById('lock-icon').innerText = isSortingEnabled ? '🔓' : '🔒';
    document.getElementById('lock-text').innerText = isSortingEnabled ? 'Bloquear Ordenação' : 'Destravar Ordenação';
    btn.classList.toggle('btn-warning');
    document.getElementById('modulos-list').classList.toggle('sorting-disabled');
    sortableInstances.forEach(i => i.option("disabled", !isSortingEnabled));
}

function copyWebhookUrl() {
    navigator.clipboard.writeText(document.getElementById('webhook-url-text').innerText).then(() => {
        showToast('URL copiada!');
    });
}

function deleteItem(id, type, btn) {
    if(!confirm('Tem certeza que deseja excluir?')) return;
    var fd = new FormData();
    fd.append('action', 'raz_delete_item');
    fd.append('nonce', nonce);
    fd.append('item_id', id);
    fd.append('type', type);
    fetch(ajaxurl, {method:'POST', body:fd}).then(r=>r.json()).then(d=>{
        if(d.success) location.reload(); else alert(d.data.message);
    });
}

function saveOrder(items, tipo) {
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_reorder&nonce=' + nonce + '&tipo=' + tipo + '&items=' + JSON.stringify(items)
    }).then(r => r.json()).then(d => { 
        if (d.success) showToast('Ordem atualizada!'); 
    });
}

function updateLessonParent(lessonId, newModId) {
    var fd = new FormData();
    fd.append('action', 'raz_save_aula');
    fd.append('nonce', nonce);
    fd.append('aula_id', lessonId);
    fd.append('modulo_id', newModId);
    fetch(ajaxurl, {method:'POST', body:fd});
}

document.getElementById('form-curso').onsubmit = function(e){
    e.preventDefault();
    var fd = new FormData(this);
    fetch(ajaxurl, {method:'POST', body:fd}).then(r=>r.json()).then(d=>{
        if(d.success) { 
            showToast('Curso Salvo!'); 
            if(!cursoId) window.location.href=razAdmin.homeUrl+'/gestao-cursos/curso-editar/'+d.data.curso_id; 
        }
    });
};

document.getElementById('form-config').onsubmit = function(e){
    e.preventDefault();
    var fd = new FormData(this);
    fd.append('action', 'raz_save_curso');
    fd.append('nonce', nonce);
    fetch(ajaxurl, {method:'POST', body:fd}).then(r=>r.json()).then(d=>{
        if(d.success) showToast('Configurações salvas!');
    });
};

document.getElementById('form-dup-aula').onsubmit = function(e){
    e.preventDefault();
    var btn = this.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.innerText = 'Processando...';
    
    var fd = new FormData(this);
    fd.append('action', 'raz_duplicate_content');
    fd.append('nonce', nonce);
    fetch(ajaxurl, {method:'POST', body:fd}).then(r=>r.json()).then(d=>{
        if(d.success) { 
            showToast('Aula duplicada!'); 
            setTimeout(function() {
                location.href = location.pathname + '?tab=conteudo';
            }, 3000);
        } else {
            btn.disabled = false;
            btn.innerText = 'Duplicar';
            alert(d.data.message || 'Erro ao duplicar');
        }
    });
};

document.getElementById('form-dup-modulo').onsubmit = function(e){
    e.preventDefault();
    var btn = this.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.innerText = 'Processando...';
    
    var fd = new FormData(this);
    fd.append('action', 'raz_duplicate_content');
    fd.append('nonce', nonce);
    fetch(ajaxurl, {method:'POST', body:fd}).then(r=>r.json()).then(d=>{
        if(d.success) { 
            showToast('Módulo duplicado!'); 
            setTimeout(function() {
                location.href = location.pathname + '?tab=conteudo';
            }, 3000);
        } else {
            btn.disabled = false;
            btn.innerText = 'Duplicar Módulo';
            alert(d.data.message || 'Erro ao duplicar');
        }
    });
};

document.addEventListener('DOMContentLoaded', function() {
    if(document.getElementById('conf_tipo')) toggleAccessDays();
    
    const urlParams = new URLSearchParams(window.location.search);
    const activeTabParam = urlParams.get('tab');
    
    if(activeTabParam === 'conteudo') {
        const tabBtn = document.querySelector('.tab:nth-child(2)');
        if(tabBtn) showTab('conteudo', tabBtn);
    } else if(activeTabParam === 'config') {
        const tabBtn = document.querySelector('.tab:nth-child(3)');
        if(tabBtn) showTab('config', tabBtn);
    } else {
        const tabBtn = document.querySelector('.tab:first-child');
        if(tabBtn) showTab('info', tabBtn);
    }

    var modList = document.getElementById('modulos-list');
    if (modList && typeof Sortable !== 'undefined') {
        sortableInstances.push(new Sortable(modList, {
            animation: 150, handle: '.item-drag', disabled: true,
            onEnd: function() { 
                var items = []; 
                modList.querySelectorAll('.modulo-item').forEach(el => items.push(el.dataset.id));
                saveOrder(items, 'modulo');
            }
        }));
        document.querySelectorAll('.aulas-list').forEach(list => {
            sortableInstances.push(new Sortable(list, {
                animation: 150, handle: '.item-drag', group: 'lessons', disabled: true,
                onEnd: function(evt) {
                    var items = []; 
                    list.querySelectorAll('.item-row').forEach(el => items.push(el.dataset.id));
                    if(evt.from !== evt.to) updateLessonParent(evt.item.dataset.id, evt.to.id.replace('aulas-', ''));
                    saveOrder(items, 'aula');
                }
            }));
        });
    }
});
</script>