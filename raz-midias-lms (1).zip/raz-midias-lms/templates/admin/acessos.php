<?php
/**
 * Admin: Acessos com filtros e paginação
 */
$per_page = 10;
$current_page = isset($_GET['pag']) ? max(1, intval($_GET['pag'])) : 1;
$filter_status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'todos';
$search_term = isset($_GET['s_acesso']) ? sanitize_text_field($_GET['s_acesso']) : '';
$offset = ($current_page - 1) * $per_page;

$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

// Buscar todos os usuários para select com busca
$all_users = get_users(array('orderby' => 'display_name', 'order' => 'ASC', 'number' => 500));
?>

<style>
    .access-tabs {
        display: flex;
        gap: 20px;
        margin-bottom: 20px;
        border-bottom: 1px solid #e2e8f0;
    }

    .access-tab-btn {
        padding: 10px 16px;
        cursor: pointer;
        font-weight: 500;
        color: var(--muted);
        border-bottom: 2px solid transparent;
        transition: all 0.2s;
    }

    .access-tab-btn.active {
        color: var(--primary);
        border-bottom-color: var(--primary);
    }

    .access-tab-content {
        display: none;
    }

    .access-tab-content.active {
        display: block;
    }

    .search-user-container {
        padding: 20px 0;
    }

    .search-results-list {
        margin-top: 15px;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        overflow: hidden;
    }

    .search-result-item {
        padding: 12px 16px;
        background: #fff;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .search-result-item:last-child {
        border-bottom: none;
    }

    .table-search-form {
        margin-bottom: 20px;
        display: flex;
        gap: 10px;
    }

    .table-search-input {
        flex: 1;
        padding: 10px 14px;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        font-size: 14px;
    }
</style>

<div class="admin-header">
    <h2>Gerenciar Acessos</h2>
</div>

<div class="tabs">
    <a href="<?php echo add_query_arg('status', 'todos', remove_query_arg('pag')); ?>" class="tab <?php echo $filter_status === 'todos' ? 'active' : ''; ?>">Todos</a>
    <a href="<?php echo add_query_arg('status', 'ativos', remove_query_arg('pag')); ?>" class="tab <?php echo $filter_status === 'ativos' ? 'active' : ''; ?>">Ativos</a>
    <a href="<?php echo add_query_arg('status', 'expirados', remove_query_arg('pag')); ?>" class="tab <?php echo $filter_status === 'expirados' ? 'active' : ''; ?>">Expirados</a>
</div>

<div class="form-card" style="max-width:700px;margin-bottom:32px;">
    <div class="access-tabs">
        <div class="access-tab-btn active" onclick="switchAccessTab('liberar')">Liberar Acesso</div>
        <div class="access-tab-btn" onclick="switchAccessTab('pesquisar')">Pesquisar Usuário</div>
    </div>

    <div id="tab-liberar" class="access-tab-content active">
        <h3 style="margin-bottom:20px;">Liberar Acesso Manual</h3>
        <form id="form-acesso">
            <div class="form-row">
                <div class="form-group">
                    <label>Aluno *</label>
                    <div class="searchable-select">
                        <input type="text" id="user-search" placeholder="Digite para buscar por email..." autocomplete="off">
                        <input type="hidden" name="user_id" id="user_id">
                        <div class="searchable-dropdown" id="user-dropdown"></div>
                    </div>
                </div>
                <div class="form-group">
                    <label>Curso *</label>
                    <select name="curso_id" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($cursos as $c) : ?>
                            <option value="<?php echo $c->ID; ?>"><?php echo esc_html($c->post_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group" id="group-dias">
                    <label>Dias de Acesso</label>
                    <input type="number" name="dias" id="input-dias" value="365" min="1">
                </div>

                <div class="form-group">
                    <label>Tipo de Acesso</label>
                    <select name="tipo" id="input-tipo" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;background:#fff;">
                        <option value="avulso">Avulso (Dias Corridos)</option>
                        <option value="vitalicio">Vitalício</option>
                        <option value="assinatura">Assinatura (Recorrente)</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Liberar Acesso</button>
        </form>
    </div>

    <div id="tab-pesquisar" class="access-tab-content">
        <h3 style="margin-bottom:20px;">Pesquisar Usuário</h3>
        <div class="search-user-container">
            <div class="form-group">
                <label>E-mail do Usuário</label>
                <input type="text" id="global-user-search" placeholder="Digite o e-mail para buscar..." style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
            </div>
            <div id="global-search-results" class="search-results-list" style="display:none;"></div>
        </div>
    </div>
</div>

<h3 style="margin-bottom:16px;">Lista de Acessos</h3>

<form method="get" class="table-search-form">
    <input type="hidden" name="status" value="<?php echo esc_attr($filter_status); ?>">
    <input type="text" name="s_acesso" class="table-search-input" placeholder="Pesquisar aluno por nome ou e-mail na tabela..." value="<?php echo esc_attr($search_term); ?>">
    <button type="submit" class="btn btn-secondary">Pesquisar</button>
    <?php if ($search_term) : ?>
        <a href="<?php echo remove_query_arg(array('s_acesso', 'pag')); ?>" class="btn btn-sm" style="display:flex; align-items:center; color:var(--muted);">Limpar</a>
    <?php endif; ?>
</form>

<?php
// Buscar acessos
global $wpdb;
$acessos_raw = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%' ORDER BY umeta_id DESC");

// Filtrar por status e busca
$acessos_filtered = array();
foreach ($acessos_raw as $a) {
    $uid = $a->user_id;
    $cid = str_replace('_raz_curso_acesso_', '', $a->meta_key);
    $data = maybe_unserialize($a->meta_value);
    $u = get_userdata($uid);
    $c = get_post($cid);
    if (!$u || !$c) continue;

    // Filtro de Busca na Tabela
    if ($search_term) {
        $found_name = stripos($u->display_name, $search_term) !== false;
        $found_email = stripos($u->user_email, $search_term) !== false;
        if (!$found_name && !$found_email) continue;
    }

    $ativo = raz_lms_user_has_access($uid, $cid);

    if ($filter_status === 'ativos' && !$ativo) continue;
    if ($filter_status === 'expirados' && $ativo) continue;

    $acessos_filtered[] = array(
        'user' => $u,
        'curso' => $c,
        'data' => $data,
        'ativo' => $ativo
    );
}

$total_acessos = count($acessos_filtered);
$total_pages = ceil($total_acessos / $per_page);
$acessos_page = array_slice($acessos_filtered, $offset, $per_page);
?>

<?php if (empty($acessos_page)) : ?>
    <div class="empty-state">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
            <path d="M7 11V7a5 5 0 0 1 10 0v4" />
        </svg>
        <h3>Nenhum acesso encontrado <?php echo $filter_status !== 'todos' ? 'com status ' . $filter_status : ''; ?></h3>
    </div>
<?php else : ?>
    <table class="data-table">
        <thead>
            <tr>
                <th>Aluno</th>
                <th>Curso</th>
                <th>Início</th>
                <th>Expiração / Tipo</th>
                <th>Status</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($acessos_page as $acesso) :
                $u = $acesso['user'];
                $c = $acesso['curso'];
                $data = $acesso['data'];
                $ativo = $acesso['ativo'];

                // Determinar tipo visual
                $tipo_label = 'Avulso';
                $is_vitalicio = isset($data['vitalicio']) && $data['vitalicio'];
                $is_assinatura = isset($data['tipo']) && $data['tipo'] === 'assinatura';

                if ($is_vitalicio) $tipo_label = 'Vitalício';
                elseif ($is_assinatura) $tipo_label = 'Assinatura';
            ?>
                <tr>
                    <td>
                        <strong><?php echo esc_html($u->display_name); ?></strong>
                        <br><small style="color:var(--muted);"><?php echo esc_html($u->user_email); ?></small>
                    </td>
                    <td><?php echo esc_html($c->post_title); ?></td>
                    <td style="color:var(--muted);"><?php echo isset($data['inicio']) ? date_i18n('d/m/Y', strtotime($data['inicio'])) : '-'; ?></td>
                    <td>
                        <?php if ($is_vitalicio) : ?>
                            <span class="badge badge-success">Vitalício</span>
                        <?php elseif ($is_assinatura) : ?>
                            <span class="badge" style="background:#e0f2fe;color:#0284c7;border:1px solid #bae6fd;">Assinatura</span>
                            <div style="font-size:11px;color:var(--muted);margin-top:2px;">Renova: <?php echo isset($data['expiracao']) ? date_i18n('d/m/Y', strtotime($data['expiracao'])) : '-'; ?></div>
                        <?php else : ?>
                            <?php echo isset($data['expiracao']) ? date_i18n('d/m/Y', strtotime($data['expiracao'])) : '-'; ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge <?php echo $ativo ? 'badge-success' : 'badge-danger'; ?>">
                            <?php echo $ativo ? 'Ativo' : 'Expirado'; ?>
                        </span>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-danger" onclick="revokeAccess(<?php echo $u->ID; ?>,<?php echo $c->ID; ?>)">Revogar</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if ($total_pages > 1) : ?>
        <div class="pagination">
            <?php if ($current_page > 1) : ?>
                <a href="<?php echo add_query_arg('pag', $current_page - 1); ?>" class="btn btn-sm btn-secondary">← Anterior</a>
            <?php endif; ?>

            <span class="pagination-info">Página <?php echo $current_page; ?> de <?php echo $total_pages; ?> (<?php echo $total_acessos; ?> registros)</span>

            <?php if ($current_page < $total_pages) : ?>
                <a href="<?php echo add_query_arg('pag', $current_page + 1); ?>" class="btn btn-sm btn-secondary">Próxima →</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<script>
    // Gerenciamento de Abas
    function switchAccessTab(tab) {
        document.querySelectorAll('.access-tab-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.access-tab-content').forEach(content => content.classList.remove('active'));

        if (tab === 'liberar') {
            document.querySelector('.access-tab-btn:nth-child(1)').classList.add('active');
            document.getElementById('tab-liberar').classList.add('active');
        } else {
            document.querySelector('.access-tab-btn:nth-child(2)').classList.add('active');
            document.getElementById('tab-pesquisar').classList.add('active');
        }
    }

    // Searchable user select
    var allUsers = <?php echo json_encode(array_map(function($u) {
                        return array('id' => $u->ID, 'name' => $u->display_name, 'email' => $u->user_email);
                    }, $all_users)); ?>;

    var userSearch = document.getElementById('user-search');
    var userDropdown = document.getElementById('user-dropdown');
    var userIdInput = document.getElementById('user_id');

    userSearch.addEventListener('focus', function() {
        showUserDropdown('');
    });

    userSearch.addEventListener('input', function() {
        showUserDropdown(this.value.toLowerCase());
    });

    // Pesquisa Global de Usuário (Aba Pesquisar)
    var globalUserSearch = document.getElementById('global-user-search');
    var globalSearchResults = document.getElementById('global-search-results');

    globalUserSearch.addEventListener('input', function() {
        var filter = this.value.toLowerCase();
        if (filter.length < 2) {
            globalSearchResults.style.display = 'none';
            return;
        }

        var html = '';
        var found = 0;
        allUsers.forEach(function(u) {
            if (found >= 10) return;
            if (u.email.toLowerCase().includes(filter) || u.name.toLowerCase().includes(filter)) {
                html += '<div class="search-result-item">';
                html += '<div><strong>' + escapeHtml(u.name) + '</strong><br><small>' + escapeHtml(u.email) + '</small></div>';
                html += '<button class="btn btn-sm btn-secondary" onclick="selectUserForGrant(' + u.id + ', \'' + escapeHtml(u.name) + '\', \'' + escapeHtml(u.email) + '\')">Selecionar</button>';
                html += '</div>';
                found++;
            }
        });

        if (html) {
            globalSearchResults.innerHTML = html;
            globalSearchResults.style.display = 'block';
        } else {
            globalSearchResults.innerHTML = '<div style="padding:15px;text-align:center;color:var(--muted);">Nenhum usuário encontrado</div>';
            globalSearchResults.style.display = 'block';
        }
    });

    function selectUserForGrant(id, name, email) {
        selectUser(id, name, email);
        switchAccessTab('liberar');
        globalUserSearch.value = '';
        globalSearchResults.style.display = 'none';
    }

    document.addEventListener('click', function(e) {
        if (!e.target.closest('.searchable-select')) {
            userDropdown.classList.remove('show');
        }
    });

    function showUserDropdown(filter) {
        var html = '';
        var count = 0;
        allUsers.forEach(function(u) {
            if (count >= 50) return;
            if (filter && !u.email.toLowerCase().includes(filter) && !u.name.toLowerCase().includes(filter)) return;
            html += '<div class="searchable-option" onclick="selectUser(' + u.id + ', \'' + escapeHtml(u.name) + '\', \'' + escapeHtml(u.email) + '\')">' + escapeHtml(u.name) + ' <small style="color:var(--muted);">(' + escapeHtml(u.email) + ')</small></div>';
            count++;
        });
        if (!html) html = '<div style="padding:10px 16px;color:var(--muted);">Nenhum usuário encontrado</div>';
        userDropdown.innerHTML = html;
        userDropdown.classList.add('show');
    }

    function selectUser(id, name, email) {
        userIdInput.value = id;
        userSearch.value = name + ' (' + email + ')';
        userDropdown.classList.remove('show');
    }

    function escapeHtml(str) {
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    // Lógica de Tipo de Acesso
    var inputTipo = document.getElementById('input-tipo');
    var inputDias = document.getElementById('input-dias');
    var groupDias = document.getElementById('group-dias');

    if (inputTipo) {
        inputTipo.addEventListener('change', function() {
            if (this.value === 'vitalicio') {
                groupDias.style.display = 'none';
            } else if (this.value === 'assinatura') {
                groupDias.style.display = 'block';
                inputDias.value = 30; // Padrão mensal
            } else {
                groupDias.style.display = 'block';
                inputDias.value = 365; // Padrão anual
            }
        });
    }

    // Form submit
    document.getElementById('form-acesso').onsubmit = function(e) {
        e.preventDefault();
        if (!userIdInput.value) {
            showToast('Selecione um aluno', 'error');
            return;
        }
        var fd = new FormData(this);
        fd.append('action', 'raz_grant_access');
        fd.append('nonce', razAdmin.nonce);

        fetch(razAdmin.ajaxurl, {
                method: 'POST',
                body: fd
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('Acesso liberado!', 'success');
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    showToast(data.data.message || 'Erro', 'error');
                }
            });
    };

    function revokeAccess(userId, cursoId) {
        if (!confirm('Revogar acesso deste aluno?')) return;
        fetch(razAdmin.ajaxurl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'action=raz_revoke_access&nonce=' + razAdmin.nonce + '&user_id=' + userId + '&curso_id=' + cursoId
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('Acesso revogado!', 'success');
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                }
            });
    }
</script>