<?php
/**
 * Admin: Exportar Dados - UX Premium Version
 * Foco: Limpeza visual, aus��ncia de caracteres especiais e alinhamento preciso.
 */
global $wpdb;

// 1. Parametros e Filtros
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

$filter_curso = isset($_GET['curso']) ? intval($_GET['curso']) : 0;
$filter_periodo_de = isset($_GET['periodo_de']) ? sanitize_text_field($_GET['periodo_de']) : '';
$filter_periodo_ate = isset($_GET['periodo_ate']) ? sanitize_text_field($_GET['periodo_ate']) : '';
$current_page_slug = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : 'gestao-cursos';
?>

<style>
    /* Variaveis de Design System UX */
    :root {
        --raz-primary: #4F46E5;
        --raz-success: #10B981;
        --raz-text-dark: #1F2937;
        --raz-text-light: #6B7280;
        --raz-border: #E5E7EB;
        --raz-bg-muted: #F9FAFB;
    }

    .raz-admin-wrapper {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        color: var(--raz-text-dark);
        max-width: 1200px;
    }

    /* Cabecalho */
    .raz-page-header {
        margin-bottom: 30px;
    }

    .raz-page-header h2 {
        font-size: 24px;
        font-weight: 700;
        margin: 0 0 8px 0;
    }

    .raz-page-header p {
        color: var(--raz-text-light);
        margin: 0;
        font-size: 14px;
    }

    /* Barra de Filtros Estilosa */
    .raz-filter-card {
        background: #fff;
        padding: 24px;
        border-radius: 12px;
        border: 1px solid var(--raz-border);
        box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        margin-bottom: 30px;
    }

    .raz-filter-card h3 {
        font-size: 14px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--raz-text-light);
        margin: 0 0 20px 0;
    }

    .raz-filter-form {
        display: flex;
        flex-wrap: wrap;
        align-items: flex-end;
        gap: 20px;
    }

    .raz-form-control {
        flex: 1;
        min-width: 220px;
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .raz-form-control label {
        font-size: 13px;
        font-weight: 600;
        color: var(--raz-text-dark);
    }

    .raz-form-control select,
    .raz-form-control input[type="date"] {
        height: 44px;
        padding: 0 12px;
        border: 1px solid var(--raz-border);
        border-radius: 8px;
        background: #fff;
        font-size: 14px;
        transition: border-color 0.2s, box-shadow 0.2s;
    }

    .raz-form-control select:focus,
    .raz-form-control input:focus {
        border-color: var(--raz-primary);
        box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        outline: none;
    }

    .raz-filter-buttons {
        display: flex;
        gap: 12px;
    }

    .raz-btn {
        height: 44px;
        padding: 0 24px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s;
        text-decoration: none;
        border: none;
    }

    .raz-btn-primary {
        background: var(--raz-primary);
        color: #fff;
    }

    .raz-btn-primary:hover {
        background: #4338ca;
    }

    .raz-btn-secondary {
        background: #fff;
        color: var(--raz-text-dark);
        border: 1px solid var(--raz-border);
    }

    .raz-btn-secondary:hover {
        background: var(--raz-bg-muted);
        border-color: #d1d5db;
    }

    /* Lista de Exportacao - UX de Cards Modernos */
    .raz-export-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 20px;
    }

    .raz-export-card {
        background: #fff;
        border: 1px solid var(--raz-border);
        border-radius: 12px;
        padding: 24px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        transition: transform 0.2s, box-shadow 0.2s;
    }

    .raz-export-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    }

    .raz-export-content h4 {
        font-size: 16px;
        margin: 0 0 8px 0;
        color: var(--raz-text-dark);
    }

    .raz-export-content p {
        font-size: 13px;
        color: var(--raz-text-light);
        margin: 0 0 24px 0;
        line-height: 1.5;
    }

    .raz-btn-download {
        width: 100%;
        background: var(--raz-success);
        color: #fff;
        height: 40px;
    }

    .raz-btn-download:hover {
        background: #059669;
    }

    /* Mobile */
    @media (max-width: 640px) {
        .raz-filter-form { flex-direction: column; align-items: stretch; }
        .raz-filter-buttons { flex-direction: column; }
    }
</style>

<div class="raz-admin-wrapper">
    
    <div class="raz-page-header">
        <h2>Exportar Relatorios</h2>
        <p>Gere e baixe dados estrategicos em formato CSV para analise no Excel ou Google Sheets.</p>
    </div>

    <div class="raz-filter-card">
        <h3>Filtrar Resultados</h3>
        <form method="get" class="raz-filter-form">
            <input type="hidden" name="page" value="<?php echo esc_attr($current_page_slug); ?>">
            <input type="hidden" name="tab" value="exportar">

            <div class="raz-form-control">
                <label>Curso</label>
                <select name="curso" id="filter-curso">
                    <option value="">Todos os cursos</option>
                    <?php foreach ($cursos as $c) : ?>
                    <option value="<?php echo $c->ID; ?>" <?php selected($filter_curso, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="raz-form-control">
                <label>Data Inicial</label>
                <input type="date" name="periodo_de" id="periodo_de" value="<?php echo esc_attr($filter_periodo_de); ?>">
            </div>

            <div class="raz-form-control">
                <label>Data Final</label>
                <input type="date" name="periodo_ate" id="periodo_ate" value="<?php echo esc_attr($filter_periodo_ate); ?>">
            </div>

            <div class="raz-filter-buttons">
                <button type="submit" class="raz-btn raz-btn-primary">Aplicar Filtros</button>
                <a href="?page=<?php echo esc_attr($current_page_slug); ?>&tab=exportar" class="raz-btn raz-btn-secondary">Limpar</a>
            </div>
        </form>
    </div>

    <div class="raz-export-grid">
        
        <div class="raz-export-card">
            <div class="raz-export-content">
                <h4>Lista de Alunos</h4>
                <p>Dados cadastrais completos: Nome, Email, Telefone, Status da conta e Origem do cadastro.</p>
            </div>
            <button class="raz-btn raz-btn-download" onclick="exportAlunos()">Baixar CSV</button>
        </div>

        <div class="raz-export-card">
            <div class="raz-export-content">
                <h4>Progresso Academico</h4>
                <p>Relatorio de engajamento: Porcentagem de conclusao por aluno, total de aulas e ultimo acesso.</p>
            </div>
            <button class="raz-btn raz-btn-download" onclick="exportProgresso()">Baixar CSV</button>
        </div>

        <div class="raz-export-card">
            <div class="raz-export-content">
                <h4>Metricas por Aula</h4>
                <p>Analise de conteudo: Total de conclusoes por videoaula e taxa de retencao por modulo.</p>
            </div>
            <button class="raz-btn raz-btn-download" onclick="exportConclusoes()">Baixar CSV</button>
        </div>

        <div class="raz-export-card" style="border-top: 4px solid var(--raz-primary);">
            <div class="raz-export-content">
                <h4>Relatorio Geral</h4>
                <p>Consolidado estrategico contendo todas as variaveis do sistema em um unico arquivo.</p>
            </div>
            <button class="raz-btn raz-btn-primary" style="height: 40px;" onclick="exportCompleto()">Baixar CSV Completo</button>
        </div>

    </div>
</div>

<script>
    var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
    var nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';

    function getFilters() {
        return {
            curso: document.getElementById('filter-curso').value,
            periodo_de: document.getElementById('periodo_de').value,
            periodo_ate: document.getElementById('periodo_ate').value
        };
    }

    function exportAlunos() {
        var f = getFilters();
        window.location.href = ajaxurl + '?action=raz_export_alunos&nonce=' + nonce + 
            '&curso=' + f.curso + '&periodo_de=' + f.periodo_de + '&periodo_ate=' + f.periodo_ate;
    }

    function exportProgresso() {
        var f = getFilters();
        window.location.href = ajaxurl + '?action=raz_export_progresso&nonce=' + nonce + 
            '&curso=' + f.curso + '&periodo_de=' + f.periodo_de + '&periodo_ate=' + f.periodo_ate;
    }

    function exportConclusoes() {
        var f = getFilters();
        window.location.href = ajaxurl + '?action=raz_export_conclusoes&nonce=' + nonce + 
            '&curso=' + f.curso;
    }

    function exportCompleto() {
        var f = getFilters();
        window.location.href = ajaxurl + '?action=raz_export_completo&nonce=' + nonce + 
            '&curso=' + f.curso + '&periodo_de=' + f.periodo_de + '&periodo_ate=' + f.periodo_ate;
    }
</script>