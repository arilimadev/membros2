<?php
/**
 * Admin Dashboard - Com gráficos e alertas
 */
global $wpdb;

$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'date', 'order' => 'DESC'));
$total_cursos = count($cursos);
$total_modulos = wp_count_posts('modulo')->publish;
$total_aulas = wp_count_posts('aula')->publish;

/**
 * CORREÇÃO: Contagem de alunos
 * Busca todos os usuários cadastrados, excluindo o administrador (ID 1)
 */
$total_alunos = $wpdb->get_var("
    SELECT COUNT(ID) 
    FROM {$wpdb->users} 
    WHERE ID != 1
");

// Alunos com acesso expirando nos próximos 7 dias
$expirando_soon = array();
$all_acessos = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%'");
foreach ($all_acessos as $acesso) {
    $data = maybe_unserialize($acesso->meta_value);
    if (isset($data['vitalicio']) && $data['vitalicio']) {
        continue;
    }
    if (isset($data['expiracao'])) {
        $exp_date = strtotime($data['expiracao']);
        $now = time();
        $diff_days = ($exp_date - $now) / (60 * 60 * 24);
        if ($diff_days > 0 && $diff_days <= 7) {
            $user = get_userdata($acesso->user_id);
            $curso_id = str_replace('_raz_curso_acesso_', '', $acesso->meta_key);
            $curso = get_post($curso_id);
            if ($user && $curso) {
                $expirando_soon[] = array(
                    'user' => $user,
                    'curso' => $curso,
                    'dias' => ceil($diff_days),
                    'expiracao' => $data['expiracao']
                );
            }
        }
    }
}

// Últimas matrículas (apenas as últimas 5)
$ultimas_matriculas = array();
$recent_acessos = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%' ORDER BY umeta_id DESC LIMIT 5");
foreach ($recent_acessos as $acesso) {
    $data = maybe_unserialize($acesso->meta_value);
    $user = get_userdata($acesso->user_id);
    $curso_id = str_replace('_raz_curso_acesso_', '', $acesso->meta_key);
    $curso = get_post($curso_id);
    if ($user && $curso) {
        $ultimas_matriculas[] = array(
            'user' => $user,
            'curso' => $curso,
            'data' => isset($data['inicio']) ? $data['inicio'] : ''
        );
    }
}

/**
 * CORREÇÃO: Dados para gráfico
 * Filtra apenas a primeira matrícula de cada aluno para evitar duplicidade no gráfico diário
 */
$chart_data = array();
for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $chart_data[$date] = 0;
}

$processed_users = array();
// Ordena por ID do metadado para pegar a primeira inserção (matrícula original)
$all_acessos_ordered = $wpdb->get_results("SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%' ORDER BY umeta_id ASC");

foreach ($all_acessos_ordered as $acesso) {
    // Se o aluno já foi contado em algum dia, ignora as outras matrículas dele
    if (in_array($acesso->user_id, $processed_users)) {
        continue;
    }

    $data = maybe_unserialize($acesso->meta_value);
    if (isset($data['inicio'])) {
        $data_inicio = date('Y-m-d', strtotime($data['inicio']));
        if (isset($chart_data[$data_inicio])) {
            $chart_data[$data_inicio]++;
            $processed_users[] = $acesso->user_id;
        }
    }
}

// Cursos mais populares
$cursos_populares = array();
foreach ($cursos as $curso) {
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s",
        '_raz_curso_acesso_' . $curso->ID
    ));
    $cursos_populares[] = array('curso' => $curso, 'alunos' => intval($count));
}
usort($cursos_populares, function ($a, $b) {
    return $b['alunos'] - $a['alunos'];
});
$cursos_populares = array_slice($cursos_populares, 0, 5);
?>

<div class="admin-header">
    <h2>Dashboard</h2>
    <a href="<?php echo home_url('/gestao-cursos/curso-editar'); ?>" class="btn btn-primary">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
            <line x1="12" y1="5" x2="12" y2="19" />
            <line x1="5" y1="12" x2="19" y2="12" />
        </svg>
        Novo Curso
    </a>
</div>

<div class="stats-row">
    <div class="stat-item">
        <h4>Cursos</h4>
        <div class="value"><?php echo $total_cursos; ?></div>
    </div>
    <div class="stat-item">
        <h4>Módulos</h4>
        <div class="value"><?php echo $total_modulos; ?></div>
    </div>
    <div class="stat-item">
        <h4>Aulas</h4>
        <div class="value"><?php echo $total_aulas; ?></div>
    </div>
    <div class="stat-item">
        <h4>Alunos</h4>
        <div class="value"><?php echo $total_alunos ?: 0; ?></div>
    </div>
</div>

<?php if (!empty($expirando_soon)) : ?>
    <div class="alert-card" style="background:linear-gradient(135deg,#fef3c7,#fde68a);border-radius:12px;padding:20px;margin-bottom:24px;">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
            <svg viewBox="0 0 24 24" fill="none" stroke="#b45309" stroke-width="2" width="24" height="24">
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
                <line x1="12" y1="9" x2="12" y2="13" />
                <line x1="12" y1="17" x2="12.01" y2="17" />
            </svg>
            <h3 style="color:#b45309;margin:0;">⚠️ <?php echo count($expirando_soon); ?> aluno(s) com acesso expirando em até 7 dias</h3>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:12px;">
            <?php foreach (array_slice($expirando_soon, 0, 5) as $item) : ?>
                <div style="background:#fff;padding:12px 16px;border-radius:8px;font-size:14px;">
                    <a href="<?php echo home_url('/gestao-cursos/alunos/?s=' . urlencode($item['user']->user_email)); ?>" style="text-decoration:none; color:inherit; cursor:pointer;">
                        <strong><?php echo esc_html($item['user']->display_name); ?></strong>
                    </a>
                    <br><span style="color:#92400e;"><?php echo esc_html($item['curso']->post_title); ?> - <?php echo $item['dias']; ?> dia(s)</span>
                </div>
            <?php endforeach; ?>
            <?php if (count($expirando_soon) > 5) : ?>
                <a href="<?php echo home_url('/gestao-cursos/acessos?status=ativos'); ?>" style="background:#fff;padding:12px 16px;border-radius:8px;font-size:14px;text-decoration:none;color:#b45309;">
                    +<?php echo count($expirando_soon) - 5; ?> mais...
                </a>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:24px;margin-bottom:32px;">
    <div class="form-card">
        <h3 style="margin-bottom:20px;">📈 Novos Alunos (últimos 30 dias)</h3>
        <div style="height:250px;position:relative;">
            <canvas id="chart-alunos"></canvas>
        </div>
    </div>

    <div class="form-card">
        <h3 style="margin-bottom:20px;">🏆 Cursos Mais Populares</h3>
        <?php if (empty($cursos_populares)) : ?>
            <p style="color:var(--muted);">Nenhum dado ainda</p>
        <?php else : ?>
            <div style="display:flex;flex-direction:column;gap:12px;">
                <?php foreach ($cursos_populares as $index => $item) : ?>
                    <div style="display:flex;align-items:center;gap:12px;">
                        <span style="width:24px;height:24px;background:<?php echo $index === 0 ? '#fbbf24' : ($index === 1 ? '#9ca3af' : ($index === 2 ? '#cd7c2f' : 'var(--bg)')); ?>;color:<?php echo $index < 3 ? '#fff' : 'var(--text)'; ?>;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;"><?php echo $index + 1; ?></span>
                        <div style="flex:1;">
                            <div style="font-weight:500;font-size:14px;"><?php echo esc_html($item['curso']->post_title); ?></div>
                            <div style="font-size:12px;color:var(--muted);"><?php echo $item['alunos']; ?> alunos</div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">
    <div class="form-card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
            <h3>🆕 Últimas Matrículas</h3>
            <a href="<?php echo home_url('/gestao-cursos/acessos'); ?>" style="font-size:13px;color:var(--primary);">Ver todas →</a>
        </div>
        <?php if (empty($ultimas_matriculas)) : ?>
            <p style="color:var(--muted);">Nenhuma matrícula ainda</p>
        <?php else : ?>
            <div style="display:flex;flex-direction:column;gap:8px;">
                <?php foreach ($ultimas_matriculas as $item) : ?>
                    <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border);">
                        <div>
                            <div style="font-weight:500;font-size:14px;"><?php echo esc_html($item['user']->display_name); ?></div>
                            <div style="font-size:12px;color:var(--muted);"><?php echo esc_html($item['curso']->post_title); ?></div>
                        </div>
                        <span style="font-size:12px;color:var(--muted);"><?php echo $item['data'] ? date_i18n('d/m', strtotime($item['data'])) : ''; ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="form-card">
        <h3 style="margin-bottom:20px;">⚡ Ações Rápidas</h3>
        <div style="display:flex;flex-direction:column;gap:12px;">
            <a href="<?php echo home_url('/gestao-cursos/curso-editar'); ?>" class="btn btn-primary" style="justify-content:flex-start;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                    <line x1="12" y1="5" x2="12" y2="19" />
                    <line x1="5" y1="12" x2="19" y2="12" />
                </svg>
                Criar Novo Curso
            </a>
            <a href="<?php echo home_url('/gestao-cursos/acessos'); ?>" class="btn btn-secondary" style="justify-content:flex-start;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg>
                Liberar Acesso Manual
            </a>
            <a href="<?php echo home_url('/gestao-cursos/relatorios'); ?>" class="btn btn-secondary" style="justify-content:flex-start;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                    <path d="M21.21 15.89A10 10 0 1 1 8 2.83" />
                    <path d="M22 12A10 10 0 0 0 12 2v10z" />
                </svg>
                Ver Relatórios
            </a>
            <a href="<?php echo home_url('/gestao-cursos/exportar'); ?>" class="btn btn-secondary" style="justify-content:flex-start;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                    <polyline points="7 10 12 15 17 10" />
                    <line x1="12" y1="15" x2="12" y2="3" />
                </svg>
                Exportar Alunos
            </a>
            <a href="<?php echo home_url('/gestao-cursos/emails'); ?>" class="btn btn-secondary" style="justify-content:flex-start;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                    <polyline points="22,6 12,13 2,6" />
                </svg>
                Configurar Emails
            </a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var ctx = document.getElementById('chart-alunos');
        if (!ctx) return;

        var chartData = <?php echo json_encode(array_values($chart_data)); ?>;
        var chartLabels = <?php echo json_encode(array_map(function($d) {
                                return date_i18n('d/m', strtotime($d));
                            }, array_keys($chart_data))); ?>;

        new Chart(ctx.getContext('2d'), {
            type: 'line',
            data: {
                labels: chartLabels,
                datasets: [{
                    label: 'Novos Alunos',
                    data: chartData,
                    borderColor: '#6366f1',
                    backgroundColor: 'rgba(99, 102, 241, 0.1)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 3,
                    pointBackgroundColor: '#6366f1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    });
</script>