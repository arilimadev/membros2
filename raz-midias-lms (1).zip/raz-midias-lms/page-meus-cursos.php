<?php
/**
 * Template Name: Meus Cursos
 * @package RazMidiasLMS
 */

if (!is_user_logged_in()) {
    wp_redirect(home_url('/login'));
    exit;
}

get_header();

$user_id = get_current_user_id();
$user = wp_get_current_user();
$cursos = raz_lms_get_user_courses($user_id);
?>

<div class="raz-dashboard">
    <header class="raz-dashboard-header">
        <div class="raz-dashboard-header-content">
            <div class="raz-dashboard-logo">
                <?php
                if (has_custom_logo()) {
                    the_custom_logo();
                } else {
                    echo '<a href="' . home_url() . '" style="font-weight:700;font-size:1.5rem;color:var(--primary);text-decoration:none;">' . get_bloginfo('name') . '</a>';
                }
                ?>
            </div>

            <div class="raz-dashboard-user">
                <span style="font-weight:500;"><?php echo esc_html($user->display_name); ?></span>
                <div class="raz-dashboard-avatar">
                    <?php echo strtoupper(substr($user->display_name, 0, 1)); ?>
                </div>
                <a href="<?php echo wp_logout_url(home_url()); ?>"
                   style="font-size:0.875rem;color:var(--error);margin-left:0.5rem;">Sair</a>
            </div>
        </div>
    </header>

    <div class="raz-dashboard-content">
        <div class="raz-dashboard-welcome">
            <h1>Meus Cursos</h1>
            <p>Continue de onde parou e acompanhe seu progresso.</p>
        </div>

        <?php if (empty($cursos)) : ?>
            <div class="raz-empty-state"
                 style="text-align:center;padding:4rem 2rem;background:var(--bg-primary);border-radius:12px;border:1px solid var(--border);">
                <div style="width:64px;height:64px;background:var(--bg-tertiary);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1.5rem;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2" style="color:var(--text-secondary);">
                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
                    </svg>
                </div>
                <h3 style="margin-bottom:0.5rem;">Nenhum curso encontrado</h3>
                <p style="color:var(--text-secondary);margin-bottom:1.5rem;">Você ainda não está matriculado em nenhum
                    curso.</p>
                <a href="<?php echo home_url('/cursos/'); ?>" class="raz-btn raz-btn-primary">Ver Cursos Disponíveis</a>
            </div>
        <?php else : ?>

            <div class="raz-dashboard-courses">
                <?php foreach ($cursos as $curso) :
                    $thumbnail = get_the_post_thumbnail_url($curso->ID, 'raz-course-card');
                    $tipo_curso = get_post_meta($curso->ID, '_raz_curso_tipo', true);

                    // Formatar texto de validade
                    $validade_html = '';
                    $acesso = $curso->acesso;

                    if (isset($acesso['vitalicio']) && $acesso['vitalicio']) {
                        $validade_html = '<span class="status-badge vitalicio">Vitalício</span>';
                    } elseif (isset($acesso['expiracao'])) {
                        $data_exp = strtotime($acesso['expiracao']);
                        $dias_restantes = ceil(($data_exp - time()) / 86400);
                        $data_fmt = date_i18n('d/m/Y', $data_exp);

                        if ($tipo_curso === 'assinatura') {
                            // Badge de Assinatura - CENTRALIZADO E FONTE MENOR
                            $validade_html = '<div style="display:flex;flex-direction:column;align-items:center;">';
                            $validade_html .= '<span class="status-badge assinatura">Assinatura Ativa</span>';
                            $validade_html .= '<span style="font-size:9px;color:var(--text-muted);margin-top:2px;">Renova em: ' . $data_fmt . '</span>';
                            $validade_html .= '</div>';
                        } else {
                            // Badge de Acesso com data limite - MANTIDO CENTRALIZADO PARA PADRÃO
                            $class = $dias_restantes < 7 ? 'expirando' : 'ativo';
                            $validade_html = '<div style="display:flex;flex-direction:column;align-items:center;">';
                            $validade_html .= '<span style="font-size:10px;color:var(--text-secondary);">Expira em ' . $data_fmt . '</span>';
                            if ($dias_restantes < 7 && $dias_restantes > 0) {
                                $validade_html .= '<span style="font-size:10px;color:#ef4444;font-weight:600;">Expira em breve!</span>';
                            }
                            $validade_html .= '</div>';
                        }
                    }
                    ?>
                    <div class="raz-course-card">
                        <a href="<?php echo get_permalink($curso->ID); ?>" class="raz-course-card-image">
                            <?php if ($thumbnail) : ?>
                                <img src="<?php echo esc_url($thumbnail); ?>"
                                     alt="<?php echo esc_attr($curso->post_title); ?>">
                            <?php else : ?>
                                <div style="width:100%;height:100%;background:linear-gradient(135deg,var(--bg-dark),#1a365d);display:flex;align-items:center;justify-content:center;color:white;">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24"
                                         fill="none" stroke="currentColor" stroke-width="1">
                                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
                                    </svg>
                                </div>
                            <?php endif; ?>

                            <div class="card-overlay">
                                <div class="play-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"
                                         width="24" height="24">
                                        <polygon points="5 3 19 12 5 21 5 3"/>
                                    </svg>
                                </div>
                            </div>
                        </a>

                        <div class="raz-course-card-content">
                            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;">
                                <h3 class="raz-course-card-title">
                                    <a href="<?php echo get_permalink($curso->ID); ?>"><?php echo esc_html($curso->post_title); ?></a>
                                </h3>
                                <?php echo $validade_html; ?>
                            </div>

                            <div class="raz-course-card-progress">
                                <div class="raz-course-card-progress-header">
                                    <span>Progresso</span>
                                    <span><?php echo $curso->progresso['percent']; ?>%</span>
                                </div>
                                <div class="raz-course-card-progress-bar">
                                    <div class="raz-course-card-progress-fill"
                                         style="width:<?php echo $curso->progresso['percent']; ?>%;"></div>
                                </div>
                            </div>

                            <a href="<?php echo get_permalink($curso->ID); ?>" class="raz-course-card-action">
                                <?php echo $curso->progresso['percent'] > 0 ? 'Continuar Curso' : 'Iniciar Curso'; ?>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
    /* Estilos Específicos para Status */
    .status-badge {
        font-size: 10px; /* Reduzido de 11px */
        font-weight: 600;
        padding: 2px 8px;
        border-radius: 99px;
        text-transform: uppercase;
    }

    .status-badge.vitalicio {
        background: #dcfce7;
        color: #166534;
    }

    .status-badge.assinatura {
        background: #e0f2fe;
        color: #0369a1;
        font-size: 8px !important;
    }

    .status-badge.expirando {
        background: #fee2e2;
        color: #991b1b;
    }

    /* Hover effect na imagem */
    .raz-course-card-image {
        position: relative;
        display: block;
    }

    .card-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: opacity 0.2s;
    }

    .raz-course-card:hover .card-overlay {
        opacity: 1;
    }

    .play-icon {
        width: 48px;
        height: 48px;
        background: var(--primary);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        transform: scale(0.8);
        transition: transform 0.2s;
    }

    .raz-course-card:hover .play-icon {
        transform: scale(1);
    }
</style>

<?php get_footer(); ?>