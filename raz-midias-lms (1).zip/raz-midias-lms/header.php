<?php
/**
 * Header Template
 * @package RazMidiasLMS
 */

// Pegar cor do header se estivermos em um curso
$header_btn_color = '#667eea'; // cor padrão
if (is_singular('curso')) {
    $curso_id = get_the_ID();
    $cor = get_post_meta($curso_id, '_raz_curso_cor_header', true);
    if ($cor) $header_btn_color = $cor;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php if (!is_singular('aula') && !is_page_template('page-meus-cursos.php')) : ?>
<header class="raz-site-header">
    <div class="raz-header-content">
        <div class="raz-header-logo">
            <?php if (has_custom_logo()) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
            <?php endif; ?>
        </div>
        
        <?php if (has_nav_menu('primary')) : ?>
        <nav class="raz-header-nav">
            <?php wp_nav_menu(array(
                'theme_location' => 'primary',
                'container' => false,
                'menu_class' => 'raz-menu',
            )); ?>
        </nav>
        <?php endif; ?>
        
        <div class="raz-header-actions">
            <?php if (is_user_logged_in()) : ?>
                <a href="<?php echo esc_url(home_url('/meus-cursos/')); ?>" class="raz-header-btn raz-btn-dynamic" style="background:<?php echo esc_attr($header_btn_color); ?>;">Meus Cursos</a>
                <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="raz-header-btn-outline">Sair</a>
            <?php else : ?>
                <a href="<?php echo esc_url(wp_login_url()); ?>" class="raz-header-btn raz-btn-dynamic" style="background:<?php echo esc_attr($header_btn_color); ?>;">Entrar</a>
            <?php endif; ?>
        </div>
    </div>
</header>

<?php if (is_singular('curso')) : ?>
<style>
.raz-btn-dynamic:hover {
    background: <?php 
        // Escurecer a cor em 10%
        $hex = str_replace('#', '', $header_btn_color);
        if (strlen($hex) == 3) {
            $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        }
        $r = max(0, hexdec(substr($hex, 0, 2)) - 25);
        $g = max(0, hexdec(substr($hex, 2, 2)) - 25);
        $b = max(0, hexdec(substr($hex, 4, 2)) - 25);
        echo sprintf('#%02x%02x%02x', $r, $g, $b);
    ?> !important;
}
</style>
<?php endif; ?>

<?php endif; ?>
