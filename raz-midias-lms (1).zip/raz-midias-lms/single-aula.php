<?php
/**
 * Template: Single Aula (Player) - Ajustes Mobile Finais (Posição e Bordas)
 * @package RazMidiasLMS
 */
 
// Validação de acesso
if (!raz_validate_access_or_redirect('aula')) {
    return; // Para a execução se não tiver acesso
}

$aula = get_post();
$aula_id = $aula->ID;
$modulo = raz_lms_get_modulo_from_aula($aula_id);
$curso = raz_lms_get_curso_from_aula($aula_id);
$user_id = get_current_user_id();

// Verificar Rotina de Estudos (Drip Content)
$rotina_status = raz_lms_check_routine_access($user_id, $aula_id);
$is_locked = $rotina_status['locked'];

// Dados do vídeo
$video_url = get_post_meta($aula_id, '_raz_aula_video_url', true);
$video_provider = get_post_meta($aula_id, '_raz_aula_video_provider', true) ?: '';
$has_video = !empty($video_url) && !empty($video_provider) && !$is_locked; // Só mostra vídeo se não estiver travado

// --- 1. FILTRAGEM DE MÓDULOS E AULAS (GRUPO DE ACESSO) ---
$all_modulos = $curso ? raz_lms_get_modulos($curso->ID) : array();
$modulos = array();
$all_aulas_visible = array(); // Lista plana de todas as aulas visíveis para navegação

if ($curso) {
    foreach ($all_modulos as $mod) {
        // Verifica se o usuário tem permissão para este módulo
        if (raz_user_can_access_modulo($user_id, $mod->ID, $curso->ID)) {
            $modulos[] = $mod;
            
            // Adiciona aulas deste módulo à lista plana
            $aulas_do_modulo = raz_lms_get_aulas($mod->ID);
            foreach($aulas_do_modulo as $am) {
                $all_aulas_visible[] = $am;
            }
        }
    }
}

// --- 2. NAVEGAÇÃO INTELIGENTE (Substitui a função padrão) ---
$prev_aula = null;
$next_aula = null;

if (!empty($all_aulas_visible)) {
    $current_index = -1;
    
    // Encontra a posição da aula atual na lista de aulas PERMITIDAS
    foreach ($all_aulas_visible as $index => $item) {
        if ($item->ID == $aula_id) {
            $current_index = $index;
            break;
        }
    }

    if ($current_index !== -1) {
        // Define Anterior (se existir na lista permitida)
        if (isset($all_aulas_visible[$current_index - 1])) {
            $prev_aula = $all_aulas_visible[$current_index - 1];
        }
        
        // Define Próxima (se existir na lista permitida)
        if (isset($all_aulas_visible[$current_index + 1])) {
            $next_aula = $all_aulas_visible[$current_index + 1];
        }
    }
}
// -------------------------------------------------------------

$is_completed = raz_lms_is_lesson_completed($user_id, $aula_id);
$user_rating = get_user_meta($user_id, '_raz_lesson_rating_' . $aula_id, true) ?: 0;

// Cores personalizadas
$cor_header = $curso ? get_post_meta($curso->ID, '_raz_curso_cor_header', true) : '#667eea';
$cor_controls = $curso ? get_post_meta($curso->ID, '_raz_curso_cor_controls', true) : '#1e293b';
if (!$cor_header) {
    $cor_header = '#667eea';
}
if (!$cor_controls) {
    $cor_controls = '#1e293b';
}

// Materiais
$materiais = get_post_meta($aula_id, '_raz_aula_materiais', true);
$has_materials = !empty($materiais) && is_array($materiais) && !$is_locked; // Materiais bloqueados também

// Registrar acesso
if ($user_id) {
    raz_lms_log_user_access($user_id, $aula_id, $curso ? $curso->ID : 0);
    update_user_meta($user_id, '_raz_last_aula_' . $curso->ID, $aula_id);
    update_user_meta($user_id, '_raz_last_curso', $curso->ID);
}

// Helper para verificar materiais
function raz_aula_has_materials($aula_id)
{
    $mat = get_post_meta($aula_id, '_raz_aula_materiais', true);
    return !empty($mat) && is_array($mat);
}

// Helper para embed de vídeo
function raz_get_video_embed_v5($url, $provider)
{
    if (empty($url) || empty($provider)) {
        return '';
    }

    switch ($provider) {
        case 'youtube':
            preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $url, $matches);
            $video_id = isset($matches[1]) ? $matches[1] : '';
            if ($video_id) {
                return '<iframe src="https://www.youtube.com/embed/' . $video_id . '?rel=0&enablejsapi=1" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen id="raz-video-iframe" data-provider="youtube"></iframe>';
            }
            break;
        case 'vimeo':
            preg_match('/vimeo\.com\/(?:video\/)?(\d+)/', $url, $matches);
            $video_id = isset($matches[1]) ? $matches[1] : '';
            if ($video_id) {
                return '<iframe src="https://player.vimeo.com/video/' . $video_id . '" frameborder="0" allow="autoplay; fullscreen" allowfullscreen id="raz-video-iframe" data-provider="vimeo"></iframe>';
            }
            break;
        case 'panda':
        case 'bunny':
            return '<iframe src="' . esc_url($url) . '" frameborder="0" allow="autoplay; fullscreen" allowfullscreen id="raz-video-iframe" data-provider="' . $provider . '"></iframe>';
        case 'custom':
            return '<video src="' . esc_url($url) . '" controls playsinline id="raz-video-element" data-provider="custom"></video>';
    }
    return '';
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <?php wp_head(); ?>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --primary: #0891b2;
            --bg-controls: <?php echo esc_attr($cor_controls); ?>;
            --border: #e2e8f0;
            --success: #10b981;
            --sidebar-width: 380px;
            --bg-main: #ffffff;
            --bg-sidebar: #ffffff;
            --bg-content: #f8fafc;
            --bg-card: #f8fafc;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
        }

        [data-theme="dark"] {
            --bg-main: #0f172a;
            --bg-sidebar: #1e293b;
            --bg-content: #1e293b;
            --bg-card: #334155;
            --text-primary: #f1f5f9;
            --text-secondary: #94a3b8;
            --border: #334155;
        }

        body { font-family: 'Inter', -apple-system, sans-serif; background: var(--bg-main); color: var(--text-primary); transition: background 0.3s, color 0.3s; -webkit-tap-highlight-color: transparent; }

        .raz-wrapper { display: flex; min-height: 100vh; }
        .raz-main { flex: 1; display: flex; flex-direction: column; overflow-x: hidden; background: var(--bg-main); }

        .raz-wrapper.sidebar-hidden .raz-sidebar { width: 0; min-width: 0; padding: 0; overflow: hidden; border: none; }
        .raz-wrapper.sidebar-hidden .raz-show-sidebar { display: flex; }

        .raz-player-header {
            position: absolute; top: 0; left: 0; right: 0; z-index: 100;
            display: flex; justify-content: space-between; align-items: center;
            padding: 12px 16px; 
            background: transparent;
        }

        /* Estilos do Botao Voltar/Acoes no Player */
        .raz-back-btn {
            width: 36px; height: 36px; min-width: 36px;
            display: flex; align-items: center; justify-content: center;
            border-radius: 8px; cursor: pointer; transition: all 0.2s;
            text-decoration: none;
                backdrop-filter: blur(10px);
            background: rgb(238 238 238 / 57%); /* Background cinza clarinho solicitado */
            color: #1e293b;
        }

        /* Quando Dark Mode esta ATIVO, o botao fica claro */
        [data-theme="dark"] .raz-back-btn {
            background: rgba(255,255,255,0.2);
            border: none;
            color: #fff;
            backdrop-filter: blur(10px);
        }

        .raz-back-btn:hover { 
            background: rgba(0,0,0,0.1); 
        }

        [data-theme="dark"] .raz-back-btn:hover { 
            background: rgba(255,255,255,0.3); 
        }
        
        .raz-back-btn svg { 
            width: 18px; 
            height: 18px; 
            filter: drop-shadow(0px 1px 1px rgba(0,0,0,0.1));
        }

        [data-theme="dark"] .raz-back-btn svg {
            filter: drop-shadow(0px 1px 2px rgba(0,0,0,0.5));
        }

        .raz-player-container { position: relative; width: 100%; background: #000; height: auto; min-height: 0; }
        .raz-player-container.has-video { aspect-ratio: 16/9; }
        .raz-video-wrapper { width: 100%; height: 100%; }
        .raz-video-wrapper iframe, .raz-video-wrapper video { width: 100%; height: 100%; }

        .raz-lesson-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 16px;
            background: transparent;
            flex-wrap: wrap;
            gap: 10px;
        }

        /* Wrapper do Título para organizar Módulo + Título */
        .raz-title-group {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            margin-right: 12px;
        }

        /* MÓDULO VISÍVEL (Desktop e Mobile) */
        .raz-lesson-module-label {
            display: block; /* Visível sempre */
            font-size: 11px;
            font-weight: 600;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 4px;
        }

        /* TÍTULO COMPLETO (Desktop e Mobile) */
        .raz-lesson-title {
            color: var(--text-primary);
            font-size: 18px;
            font-weight: 600;
            line-height: 1.3;
            /* Forçar quebra de linha e visibilidade completa */
            white-space: normal;
            overflow: visible;
            text-overflow: clip;
        }

        [data-theme="dark"] .raz-lesson-title {
            color: #f1f5f9;
        }

        .raz-lesson-actions { display: flex; gap: 8px; align-items: center; flex-shrink: 0; }

        .raz-nav-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 14px;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            border-radius: 8px;
            color: #1e293b;
            font-size: 12px;
            cursor: pointer;
            text-decoration: none;
            white-space: nowrap;
            min-width: 85px;
            justify-content: center;
        }

        .raz-nav-btn.primary {
            background: #ffffff;
            border: 1px solid var(--border);
        }

        .raz-nav-btn.success { background: var(--success); color: #fff; }
        .raz-nav-btn:hover { opacity: 0.9; }
        .raz-nav-btn svg { width: 14px; height: 14px; flex-shrink: 0; }

        .raz-rating { display: flex; gap: 2px; }
        .raz-rating .star { cursor: pointer; color: #64748b; transition: color 0.15s; padding: 4px; }
        .raz-rating .star.active, .raz-rating .star:hover { color: #fbbf24; }
        .raz-rating .star svg { width: 18px; height: 18px; }

        .raz-tabs { display: flex; gap: 0; border-bottom: 1px solid var(--border); background: var(--bg-main); overflow-x: auto; -webkit-overflow-scrolling: touch; }
        .raz-tab {
            padding: 12px 20px; cursor: pointer; font-size: 13px; font-weight: 500;
            color: var(--text-secondary); border-bottom: 2px solid transparent;
            transition: all 0.2s; display: flex; align-items: center; gap: 6px; white-space: nowrap;
        }
        .raz-tab:hover { color: var(--text-primary); }
        .raz-tab.active { color: var(--primary); border-bottom-color: var(--primary); }
        .raz-tab svg { width: 14px; height: 14px; }
        .raz-tab-content { display: none; }
        .raz-tab-content.active { display: block; }

        .raz-lesson-content {
            padding: 24px 16px; max-width: 800px; width: 100%; margin: 0 auto;
            line-height: 1.7; color: var(--text-primary);
        }
        .raz-lesson-content h1, .raz-lesson-content h2, .raz-lesson-content h3 { margin: 20px 0 10px; }
        .raz-lesson-content p { margin-bottom: 14px; color: var(--text-secondary); }
        .raz-lesson-content img { max-width: 100%; border-radius: 8px; height: auto; }
        .raz-lesson-content audio { width: 100%; margin: 10px 0; }

        .raz-materials { padding: 24px 16px; max-width: 800px; width: 100%; margin: 0 auto; }
        .raz-materials-title { font-size: 15px; font-weight: 600; margin-bottom: 14px; }
        .raz-materials-list { display: flex; flex-direction: column; gap: 8px; }
        .raz-material-item { display: flex; align-items: center; gap: 12px; padding: 14px; background: var(--bg-card); border-radius: 8px; text-decoration: none; transition: background 0.15s; }
        .raz-material-item:hover { background: var(--border); }
        .raz-material-item:active { transform: scale(0.98); }
        .raz-material-item svg { color: var(--primary); flex-shrink: 0; }
        .raz-material-name { font-size: 13px; font-weight: 500; color: var(--text-primary); }
        .raz-material-type { font-size: 10px; color: var(--text-secondary); text-transform: uppercase; }

        .raz-sidebar {
            width: var(--sidebar-width); min-width: var(--sidebar-width);
            background: var(--bg-sidebar); border-left: 1px solid var(--border);
            display: flex; flex-direction: column; transition: all 0.3s;
        }
        .raz-sidebar-header { padding: 16px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }
        .raz-sidebar-title { font-size: 15px; font-weight: 600; }
        .raz-sidebar-close { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; background: var(--bg-card); border: none; border-radius: 8px; cursor: pointer; color: var(--text-secondary); }
        .raz-sidebar-content { flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch; }

        .raz-module { border-bottom: 1px solid var(--border); }
        .raz-module-header { padding: 14px 16px; cursor: pointer; display: flex; justify-content: space-between; align-items: center; }
        .raz-module-title { font-weight: 500; font-size: 13px; }
        .raz-module-lessons { display: none; background: var(--bg-content); }
        .raz-module.open .raz-module-lessons { display: block; }

        .raz-lesson-item { display: flex; align-items: center; gap: 10px; padding: 10px 16px; transition: background 0.15s; }
        .raz-lesson-item:hover { background: var(--bg-card); }
        .raz-lesson-item.active { background: rgba(8, 145, 178, 0.15); }
        
        .raz-lesson-item.locked { opacity: 1; background: var(--bg-card); cursor: not-allowed; }
        .raz-lesson-item.locked .raz-lesson-item-title { color: var(--text-secondary); }
        .raz-lock-badge { font-size: 14px; margin-right: 5px; }
        
        .raz-release-info {
            display: block;
            font-size: 10px;
            color: #c2410c;
            background: #fff7ed;
            border: 1px solid #fed7aa;
            padding: 2px 6px;
            border-radius: 4px;
            margin-top: 4px;
            width: fit-content;
            font-weight: 600;
        }

        .raz-lesson-check { 
            width: 22px; height: 22px; border: 2px solid var(--border); border-radius: 6px; 
            display: flex; align-items: center; justify-content: center; flex-shrink: 0; 
            cursor: pointer; transition: all 0.2s; background: var(--bg-main);
        }
        .raz-lesson-check:hover { border-color: var(--success); }
        .raz-lesson-check.completed { background: var(--success); border-color: var(--success); color: #fff; }
        
        .raz-lesson-item-title { font-size: 12px; flex: 1; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; line-height: 1.3; }
        
        .raz-lesson-link { 
            flex: 1; 
            text-decoration: none; 
            color: inherit; 
            display: flex; 
            align-items: center; 
            justify-content: space-between; 
            min-width: 0;
            gap: 8px;
        } 
        
        .raz-lesson-item.locked .raz-lesson-link {
            flex-direction: column;
            align-items: flex-start;
            justify-content: center;
            gap: 2px;
        }
        
        .raz-material-icon { color: var(--primary); flex-shrink: 0; margin-left: auto; }

        .raz-theme-toggle {
            display: flex; align-items: center; gap: 8px; padding: 12px 16px;
            border-top: 1px solid var(--border); cursor: pointer;
        }
        .raz-theme-toggle-label { font-size: 12px; color: var(--text-secondary); }
        .raz-theme-switch {
            width: 40px; height: 22px; background: var(--border); border-radius: 11px;
            position: relative; transition: background 0.3s; cursor: pointer; margin-left: auto;
        }
        .raz-theme-switch::after {
            content: ''; position: absolute; top: 2px; left: 2px;
            width: 18px; height: 18px; background: #fff; border-radius: 50%;
            transition: transform 0.3s;
        }
        [data-theme="dark"] .raz-theme-switch { background: var(--primary); }
        [data-theme="dark"] .raz-theme-switch::after { transform: translateX(18px); }

        .raz-show-sidebar {
            display: none; position: fixed; right: 16px; top: 50%; transform: translateY(-50%);
            width: 44px; height: 44px; background: var(--primary); color: #fff; border: none;
            border-radius: 50%; cursor: pointer; z-index: 200; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
        .raz-show-sidebar svg { width: 22px; height: 22px; }

        .raz-sidebar-toggle-btn {
            position: fixed; bottom: 16px; right: 16px; z-index: 200;
            display: none; flex-direction: column; align-items: center; justify-content: center;
            background: var(--primary); color: #fff; border: none; cursor: pointer;
            width: 56px; height: 56px; border-radius: 50%;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }
        .raz-sidebar-toggle-btn svg { width: 20px; height: 20px; }
        .raz-sidebar-toggle-btn span { font-size: 8px; font-weight: 600; margin-top: 2px; }

        .raz-sidebar-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 499; display: none; }

        .raz-notif-btn { position: relative; }
        .notif-badge { position: absolute; top: -4px; right: -4px; background: #ef4444; color: #fff; font-size: 10px; font-weight: 600; min-width: 18px; height: 18px; border-radius: 9px; display: flex; align-items: center; justify-content: center; }

        .raz-notif-modal { position: fixed; top: 60px; right: 16px; width: 350px; max-width: calc(100vw - 32px); max-height: 70vh; background: var(--bg-sidebar); border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); z-index: 700; display: none; overflow: hidden; }
        .raz-notif-modal.open { display: block; }
        .raz-notif-header { display: flex; justify-content: space-between; align-items: center; padding: 16px; border-bottom: 1px solid var(--border); }
        .raz-notif-header h4 { margin: 0; font-size: 15px; }
        .raz-notif-list { max-height: 400px; overflow-y: auto; }
        .raz-notif-item { padding: 14px 16px; border-bottom: 1px solid var(--border); cursor: pointer; transition: background 0.15s; }
        .raz-notif-item:hover { background: var(--bg-card); }
        .raz-notif-item.unread { background: rgba(8, 145, 178, 0.1); }
        .raz-notif-item h5 { margin: 0 0 4px; font-size: 14px; font-weight: 600; }
        .raz-notif-item p { margin: 0; font-size: 13px; color: var(--text-secondary); }
        .raz-notif-item small { font-size: 11px; color: var(--text-secondary); }
        .raz-notif-empty { padding: 40px 16px; text-align: center; color: var(--text-secondary); }

        .raz-search-modal { position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 600; display: none; align-items: flex-start; justify-content: center; padding: 10vh 16px 0; }
        .raz-search-modal.open { display: flex; }
        .raz-search-box { background: var(--bg-sidebar); border-radius: 12px; width: 100%; max-width: 500px; max-height: 70vh; overflow: hidden; }
        .raz-search-input { width: 100%; padding: 14px 16px; border: none; font-size: 15px; outline: none; border-bottom: 1px solid var(--border); background: var(--bg-sidebar); color: var(--text-primary); }
        .raz-search-results { max-height: 50vh; overflow-y: auto; -webkit-overflow-scrolling: touch; }
        .raz-search-item { display: block; padding: 12px 16px; text-decoration: none; color: var(--text-primary); transition: background 0.15s; }
        .raz-search-item:hover, .raz-search-item:active { background: var(--bg-card); }

        .raz-notif-detail-overlay {
            position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 800; display: none;
            align-items: center; justify-content: center; padding: 20px;
        }
        .raz-notif-detail-overlay.open { display: flex; }
        .raz-notif-detail-card {
            background: var(--bg-sidebar); border-radius: 12px; width: 100%; max-width: 500px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3); overflow: hidden; animation: slideInUp 0.3s ease; position: relative;
        }
        .raz-notif-detail-header {
            padding: 16px 20px; border-bottom: 1px solid var(--border);
            display: flex; justify-content: space-between; align-items: center;
            background: var(--bg-card);
        }
        .raz-notif-detail-title { font-size: 16px; font-weight: 600; margin: 0; color: var(--text-primary); }
        .raz-notif-detail-close { background: none; border: none; cursor: pointer; color: var(--text-secondary); padding: 4px; }
        .raz-notif-detail-close:hover { color: var(--text-primary); }
        .raz-notif-detail-content { padding: 20px; color: var(--text-primary); line-height: 1.6; max-height: 60vh; overflow-y: auto; font-size: 14px; }
        .raz-notif-detail-meta { padding: 12px 20px; border-top: 1px solid var(--border); font-size: 12px; color: var(--text-secondary); background: var(--bg-card); display: flex; justify-content: space-between; }

        .raz-lock-screen {
            padding: 40px 20px; text-align: center; background: var(--bg-card); border-radius: 12px;
            margin: 20px auto; max-width: 600px; border: 1px solid var(--border);
        }
        .raz-lock-icon { font-size: 48px; margin-bottom: 20px; display: block; }
        .raz-lock-title { font-size: 20px; font-weight: 600; margin-bottom: 10px; }
        .raz-lock-message { color: var(--text-secondary); margin-bottom: 20px; }
        .raz-lock-date { display: inline-block; background: var(--bg-main); padding: 8px 16px; border-radius: 8px; font-weight: 500; font-size: 14px; border: 1px solid var(--border); }

        @keyframes slideInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

        @media (max-width: 768px) {
            .raz-player-header { padding: 8px 12px; }
            .raz-back-btn { width: 32px; height: 32px; min-width: 32px; }
            .raz-back-btn svg { width: 16px; height: 16px; }
            
            .raz-sidebar { position: fixed; top: 0; right: 0; bottom: 0; width: 85%; max-width: 320px; z-index: 500; min-width: auto; transform: translateX(100%); transition: transform 0.3s; }
            .raz-sidebar.mobile-open { transform: translateX(0); }
            .raz-sidebar-toggle-btn { display: flex; }
            
            .raz-lesson-controls { 
                padding: 12px 16px; 
                align-items: flex-start; /* Alinhamento ao topo para suportar quebras de linha */
            }

            /* Força o grupo de título a ocupar 100% da largura, empurrando botões para baixo */
            .raz-title-group {
                flex: 0 0 100%; /* Força 100% da largura do flex container */
                width: 100%;
                margin-right: 0;
                margin-bottom: 12px; /* Espaço para os botões abaixo */
            }

            /* Ajusta os botões para ocuparem a largura total na linha de baixo e subirem 10px */
            .raz-lesson-actions {
                width: 100%;
                justify-content: space-between; /* Botões espalhados (Esq/Dir) */
                margin-top: -10px; /* <--- Puxa 10px para cima */
            }

            .raz-lesson-title { 
                font-size: 16px;
            }

            /* Estilo dos botões no mobile (garante borda e fundo iguais) */
            .raz-nav-btn { 
                padding: 8px 10px; 
                font-size: 11px;
                border: 1px solid var(--border); /* <--- Borda igual para todos */
                background: var(--bg-card); /* <--- Fundo sólido para consistência */
            }
            .raz-nav-btn .btn-text { display: none; }
            .raz-nav-btn svg { width: 16px; height: 16px; }
            
            .raz-rating .star svg { width: 16px; height: 16px; }
            
            .raz-show-sidebar { display: none !important; }
            
            .raz-lesson-content { padding: 20px 14px; font-size: 14px; }
            .raz-materials { padding: 20px 14px; }
        }
        
        @media (min-width: 769px) and (max-width: 1024px) {
            .raz-sidebar { width: 320px; min-width: 320px; }
        }
        
        @media (min-width: 1400px) {
            .raz-lesson-content { max-width: 900px; font-size: 17px; padding: 40px 24px; }
            .raz-lesson-controls { padding: 16px 24px; }
            .raz-sidebar { width: 420px; min-width: 420px; }
        }
        
        @media (min-width: 769px) {
            .raz-sidebar-toggle-btn { display: none; }
            .raz-sidebar-overlay { display: none !important; }
        }
        
        .raz-wrapper.fullscreen .raz-sidebar,
        .raz-wrapper.fullscreen .raz-show-sidebar,
        .raz-wrapper.fullscreen .raz-lesson-controls,
        .raz-wrapper.fullscreen .raz-tabs,
        .raz-wrapper.fullscreen .raz-tab-content,
        .raz-wrapper.fullscreen .raz-sidebar-toggle-btn { display: none !important; }
        .raz-wrapper.fullscreen .raz-player-container { aspect-ratio: auto; height: 100vh; }
    </style>
</head>
<body>

<div class="raz-wrapper" id="wrapper">
    <main class="raz-main">
        <?php if ($is_locked) : ?>
            <div class="raz-lock-screen">
                <span class="raz-lock-icon">🔒</span>
                <h2 class="raz-lock-title">Conteúdo Bloqueado</h2>
                <p class="raz-lock-message"><?php echo esc_html($rotina_status['message']); ?></p>
                <div class="raz-lock-date">
                    Disponível em: <?php echo date_i18n('d/m/Y', $rotina_status['release_date']); ?>
                </div>
            </div>
        <?php else : ?>
            
            <?php if ($has_video) : ?>
                <div class="raz-player-container has-video">
                    <div class="raz-player-header">
                        <a href="<?php echo get_permalink($curso->ID); ?>" class="raz-back-btn" title="Voltar">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                        </a>
                        <div style="display:flex;gap:6px;">
                            <button class="raz-back-btn raz-notif-btn" title="Notificações" onclick="toggleNotifications()">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                                <span class="notif-badge" id="notif-badge" style="display:none;">0</span>
                            </button>
                            <button class="raz-back-btn" title="Buscar" onclick="openSearch()">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                            </button>
                            <button class="raz-back-btn" title="Tela cheia" onclick="toggleFullscreen()">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg>
                            </button>
                        </div>
                    </div>
                    <div class="raz-video-wrapper">
                        <?php echo raz_get_video_embed_v5($video_url, $video_provider); ?>
                    </div>
                </div>
            <?php else : ?>
                <div class="raz-player-header" style="position: relative; background: transparent;">
                    <a href="<?php echo get_permalink($curso->ID); ?>" class="raz-back-btn" title="Voltar">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                    </a>
                    <div style="display:flex;gap:6px;">
                        <button class="raz-back-btn raz-notif-btn" title="Notificações" onclick="toggleNotifications()">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                            <span class="notif-badge" id="notif-badge" style="display:none;">0</span>
                        </button>
                        <button class="raz-back-btn" title="Buscar" onclick="openSearch()">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                        </button>
                        <button class="raz-back-btn" title="Tela cheia" onclick="toggleFullscreen()">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg>
                        </button>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="raz-lesson-controls">
                <div class="raz-title-group">
                    <?php if ($modulo) : ?>
                    <div class="raz-lesson-module-label"><?php echo esc_html($modulo->post_title); ?></div>
                    <?php endif; ?>
                    <div class="raz-lesson-title"><?php echo esc_html($aula->post_title); ?></div>
                </div>

                <div class="raz-lesson-actions">
                    <?php if ($prev_aula) : ?>
                    <a href="<?php echo get_permalink($prev_aula->ID); ?>" class="raz-nav-btn">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
                        <span class="btn-text">Anterior</span>
                    </a>
                    <?php endif; ?>
                    
                    <div class="raz-rating" id="rating">
                        <?php for ($i = 1; $i <= 5; $i++) : ?>
                        <span class="star <?php echo $i <= $user_rating ? 'active' : ''; ?>" onclick="rateLesson(<?php echo $i; ?>)">
                            <svg viewBox="0 0 24 24" fill="<?php echo $i <= $user_rating ? 'currentColor' : 'none'; ?>" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        </span>
                        <?php endfor; ?>
                    </div>
                    
                    <?php if ($next_aula) : ?>
                    <a href="<?php echo get_permalink($next_aula->ID); ?>" class="raz-nav-btn primary">
                        <span class="btn-text">Próxima</span>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
                    </a>
                    <?php else : ?>
                    <button class="raz-nav-btn success" onclick="finishCourse()">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
                        <span class="btn-text">Concluir</span>
                    </button>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="raz-tabs">
                <div class="raz-tab active" data-tab="conteudo">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    Conteúdo
                </div>
                <?php if ($has_materials) : ?>
                <div class="raz-tab" data-tab="materiais">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                    Materiais (<?php echo count($materiais); ?>)
                </div>
                <?php endif; ?>
            </div>
            
            <div class="raz-tab-content active" id="tab-conteudo">
                <?php if (get_the_content()) : ?>
                <div class="raz-lesson-content"><?php the_content(); ?></div>
                <?php else : ?>
                <div class="raz-lesson-content" style="text-align:center;color:var(--text-secondary);padding:40px 16px;">
                    <p>Esta aula não possui conteúdo escrito.</p>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if ($has_materials) : ?>
            <div class="raz-tab-content" id="tab-materiais">
                <div class="raz-materials">
                    <h3 class="raz-materials-title">📎 Materiais Complementares</h3>
                    <div class="raz-materials-list">
                        <?php foreach ($materiais as $mat) : ?>
                        <a href="<?php echo esc_url($mat['url']); ?>" class="raz-material-item" target="_blank" download>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="22" height="22"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><polyline points="9 15 12 18 15 15"/></svg>
                            <div>
                                <span class="raz-material-name"><?php echo esc_html($mat['display_name'] ?? $mat['nome']); ?></span>
                                <span class="raz-material-type"><?php echo strtoupper(esc_html($mat['tipo'])); ?></span>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </main>
    
    <aside class="raz-sidebar" id="sidebar">
        <div class="raz-sidebar-header">
            <div>
                <span style="font-size:11px;color:var(--text-secondary);display:block;margin-bottom:2px;"><?php echo esc_html($curso->post_title); ?></span>
                <h2 class="raz-sidebar-title">Aulas</h2>
            </div>
            <button class="raz-sidebar-close" onclick="closeSidebar()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M18 6 6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="raz-sidebar-content">
            <?php foreach ($modulos as $mod) :
                $mod_aulas = raz_lms_get_aulas($mod->ID);
                $mod_progress = raz_lms_get_module_progress($user_id, $mod->ID);
                $is_current = $modulo && $mod->ID == $modulo->ID;
            ?>
            <div class="raz-module <?php echo $is_current ? 'open' : ''; ?>">
                <div class="raz-module-header" onclick="this.parentElement.classList.toggle('open')">
                    <span class="raz-module-title"><?php echo esc_html($mod->post_title); ?></span>
                    <span style="font-size:11px;color:var(--text-secondary);"><?php echo $mod_progress['completed']; ?>/<?php echo $mod_progress['total']; ?></span>
                </div>
                <div class="raz-module-lessons">
                    <?php foreach ($mod_aulas as $lesson) :
                        $completed = raz_lms_is_lesson_completed($user_id, $lesson->ID);
                        $current = $lesson->ID == $aula_id;
                        $lesson_has_mat = raz_aula_has_materials($lesson->ID);
                        
                        // Verificar lock no loop da sidebar
                        $lesson_lock = raz_lms_check_routine_access($user_id, $lesson->ID);
                        $is_lesson_locked = $lesson_lock['locked'];
                    ?>
                    
                    <?php if ($is_lesson_locked) : ?>
                    <div class="raz-lesson-item locked">
                        <div class="raz-lesson-check" style="border-color:#cbd5e1;background:#f1f5f9;cursor:not-allowed;">
                            <span class="raz-lock-badge">🔒</span>
                        </div>
                        <div class="raz-lesson-link" style="cursor:not-allowed;">
                            <span class="raz-lesson-item-title" style="color:var(--text-secondary);"><?php echo esc_html($lesson->post_title); ?></span>
                            <span class="raz-release-info">
                                Liberada em: <?php echo date_i18n('d/m/Y', $lesson_lock['release_date']); ?>
                            </span>
                        </div>
                    </div>
                    <?php else : ?>
                    <div class="raz-lesson-item <?php echo $current ? 'active' : ''; ?>">
                        <div class="raz-lesson-check <?php echo $completed ? 'completed' : ''; ?>" data-aula="<?php echo $lesson->ID; ?>" onclick="toggleLessonComplete(this, <?php echo $lesson->ID; ?>)">
                            <?php if ($completed) : ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" width="12" height="12"><polyline points="20 6 9 17 4 12"/></svg>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo get_permalink($lesson->ID); ?>" class="raz-lesson-link">
                            <span class="raz-lesson-item-title"><?php echo esc_html($lesson->post_title); ?></span>
                            <?php if ($lesson_has_mat) : ?>
                            <svg class="raz-material-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12" title="Possui materiais"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                            <?php endif; ?>
                        </a>
                    </div>
                    <?php endif; ?>
                    
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="raz-theme-toggle" onclick="toggleDarkMode()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            <span class="raz-theme-toggle-label">Modo escuro</span>
            <div class="raz-theme-switch"></div>
        </div>
    </aside>
    <div class="raz-sidebar-overlay" id="sidebar-overlay"></div>
</div>

<button class="raz-show-sidebar" id="show-sidebar-btn" onclick="showSidebarDesktop()">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
</button>

<button class="raz-sidebar-toggle-btn" id="sidebar-toggle" onclick="openMobileSidebar()">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
    <span>Aulas</span>
</button>

<div class="raz-search-modal" id="search-modal" onclick="if(event.target===this)closeSearch()">
    <div class="raz-search-box">
        <input type="text" class="raz-search-input" id="search-input" placeholder="Buscar aulas..." oninput="filterSearch(this.value)">
        <div class="raz-search-results" id="search-results">
            <?php foreach ($all_aulas_visible as $sa) : $sm = raz_lms_get_modulo_from_aula($sa->ID); ?>
            <a href="<?php echo get_permalink($sa->ID); ?>" class="raz-search-item" data-title="<?php echo esc_attr(strtolower($sa->post_title)); ?>">
                <div style="font-weight:500;font-size:14px;"><?php echo esc_html($sa->post_title); ?></div>
                <div style="font-size:11px;color:var(--text-secondary);"><?php echo $sm ? esc_html($sm->post_title) : ''; ?></div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="raz-notif-modal" id="notif-modal">
    <div class="raz-notif-header">
        <h4>🔔 Notificações</h4>
        <button style="background:none;border:none;cursor:pointer;font-size:12px;color:var(--primary);" onclick="markAllRead()">Marcar todas como lidas</button>
    </div>
    <div class="raz-notif-list" id="notif-list">
        <div class="raz-notif-empty">Carregando...</div>
    </div>
</div>

<div class="raz-notif-detail-overlay" id="notif-detail-modal" onclick="if(event.target===this)closeNotifDetail()">
    <div class="raz-notif-detail-card">
        <div class="raz-notif-detail-header">
            <h3 class="raz-notif-detail-title" id="notif-detail-title">Título da Notificação</h3>
            <button class="raz-notif-detail-close" onclick="closeNotifDetail()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M18 6 6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="raz-notif-detail-content" id="notif-detail-message"></div>
        <div class="raz-notif-detail-meta" id="notif-detail-meta"></div>
    </div>
</div>

<?php wp_footer(); ?>

<script src="https://player.vimeo.com/api/player.js"></script>
<script>
    var razLMS = {
        ajaxurl: '<?php echo admin_url('admin-ajax.php'); ?>',
        nonce: '<?php echo wp_create_nonce('raz_lms_nonce'); ?>'
    };
    var aulaId = <?php echo $aula_id; ?>;
    var nextUrl = <?php echo $next_aula ? '"' . get_permalink($next_aula->ID) . '"' : 'null'; ?>;
    var videoEnded = false;
    var isMobile = window.innerWidth < 769;

    // Abas
    document.querySelectorAll('.raz-tab').forEach(function(tab) {
        tab.addEventListener('click', function() {
            document.querySelectorAll('.raz-tab').forEach(function(t) { t.classList.remove('active'); });
            document.querySelectorAll('.raz-tab-content').forEach(function(c) { c.classList.remove('active'); });
            this.classList.add('active');
            document.getElementById('tab-' + this.dataset.tab).classList.add('active');
        });
    });

    // Dark Mode
    function toggleDarkMode() {
        var html = document.documentElement;
        var isDark = html.getAttribute('data-theme') === 'dark';
        html.setAttribute('data-theme', isDark ? 'light' : 'dark');
        localStorage.setItem('raz-theme', isDark ? 'light' : 'dark');
    }

    (function() {
        var saved = localStorage.getItem('raz-theme');
        if (saved) {
            document.documentElement.setAttribute('data-theme', saved);
        } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
            document.documentElement.setAttribute('data-theme', 'dark');
        }
    })();

    // Sidebar Desktop
    function hideSidebarDesktop() { document.getElementById('wrapper').classList.add('sidebar-hidden'); }
    function showSidebarDesktop() { document.getElementById('wrapper').classList.remove('sidebar-hidden'); }

    // Sidebar unificada
    function closeSidebar() {
        if (isMobile) {
            closeMobileSidebar();
        } else {
            hideSidebarDesktop();
        }
    }

    // Sidebar Mobile
    function openMobileSidebar() {
        document.getElementById('sidebar').classList.add('mobile-open');
        document.getElementById('sidebar-overlay').style.display = 'block';
    }

    function closeMobileSidebar() {
        document.getElementById('sidebar').classList.remove('mobile-open');
        document.getElementById('sidebar-overlay').style.display = 'none';
    }

    document.getElementById('sidebar-overlay').addEventListener('click', closeMobileSidebar);

    function toggleFullscreen() {
        var wrapper = document.getElementById('wrapper');
        if (wrapper.classList.contains('fullscreen')) {
            wrapper.classList.remove('fullscreen');
            wrapper.classList.remove('sidebar-hidden');
        } else {
            wrapper.classList.add('fullscreen');
        }
    }

    function openSearch() {
        document.getElementById('search-modal').classList.add('open');
        document.getElementById('search-input').focus();
    }
    function closeSearch() { document.getElementById('search-modal').classList.remove('open'); }
    function filterSearch(q) {
        q = q.toLowerCase();
        document.querySelectorAll('.raz-search-item').forEach(function(i) {
            i.style.display = i.getAttribute('data-title').includes(q) ? 'block' : 'none';
        });
    }

    function toggleLessonComplete(el, lessonId) {
        var isCompleted = el.classList.contains('completed');
        var newState = !isCompleted;
        
        fetch(razLMS.ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=raz_complete_lesson&nonce=' + razLMS.nonce + '&aula_id=' + lessonId
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                if (newState) {
                    el.classList.add('completed');
                    el.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" width="12" height="12"><polyline points="20 6 9 17 4 12"/></svg>';
                } else {
                    el.classList.remove('completed');
                    el.innerHTML = '';
                }
            }
        });
    }

    function rateLesson(rating) {
        document.querySelectorAll('#rating .star').forEach(function(s, i) {
            var active = (i + 1) <= rating;
            s.classList.toggle('active', active);
            s.querySelector('svg').setAttribute('fill', active ? 'currentColor' : 'none');
        });
        
        // Salvar rating no banco de dados via AJAX
        fetch(razLMS.ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=raz_rate_lesson&nonce=' + razLMS.nonce + '&aula_id=' + aulaId + '&rating=' + rating
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                console.log('Avaliação salva com sucesso!');
            }
        });
    }

    function markComplete() {
        fetch(razLMS.ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=raz_complete_lesson&nonce=' + razLMS.nonce + '&aula_id=' + aulaId
        });
        var check = document.querySelector('.raz-lesson-check[data-aula="' + aulaId + '"]');
        if (check && !check.classList.contains('completed')) {
            check.classList.add('completed');
            check.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" width="12" height="12"><polyline points="20 6 9 17 4 12"/></svg>';
        }
    }

    function finishCourse() {
        markComplete();
        alert('Parabéns! Curso concluído!');
        location.reload();
    }

    function onVideoEnd() {
        if (videoEnded) return;
        videoEnded = true;
        markComplete();
        if (nextUrl) { setTimeout(function() { window.location.href = nextUrl; }, 1500); }
    }

    // YouTube API
    var ytPlayer;
    function onYouTubeIframeAPIReady() {
        var iframe = document.querySelector('#raz-video-iframe[data-provider="youtube"]');
        if (iframe) {
            ytPlayer = new YT.Player(iframe, { events: { 'onStateChange': function(e) { if (e.data === YT.PlayerState.ENDED) onVideoEnd(); } } });
        }
    }
    if (document.querySelector('[data-provider="youtube"]')) {
        var tag = document.createElement('script');
        tag.src = 'https://www.youtube.com/iframe_api';
        document.head.appendChild(tag);
    }

    // Vimeo
    var vimeoIframe = document.querySelector('#raz-video-iframe[data-provider="vimeo"]');
    if (vimeoIframe && typeof Vimeo !== 'undefined') {
        var vPlayer = new Vimeo.Player(vimeoIframe);
        vPlayer.on('ended', onVideoEnd);
    }

    // HTML5 Video
    var videoEl = document.getElementById('raz-video-element');
    if (videoEl) videoEl.addEventListener('ended', onVideoEnd);

    // Panda Video - usando a API oficial (panda_ended)
    window.addEventListener('message', function(e) {
        // Debug: descomentar para ver todos os eventos recebidos
        // console.log('Evento recebido:', e.data);
        
        if (e.data) {
            // Panda Video usa o formato: { message: 'panda_ended', ... }
            if (e.data.message === 'panda_ended') {
                console.log('Panda Video: vídeo finalizado!');
                onVideoEnd();
            }
            // Bunny Stream e outros formatos de fallback
            else if (e.data.event === 'ended' || e.data.type === 'ended' || e.data === 'ended') {
                console.log('Video ended (fallback)');
                onVideoEnd();
            }
        }
    });

    document.addEventListener('keydown', function(e) { if (e.key === 'Escape') closeSearch(); });
    window.addEventListener('resize', function() { isMobile = window.innerWidth < 769; });

    // --- SISTEMA DE NOTIFICAÇÕES ---

    function toggleNotifications() {
        var modal = document.getElementById('notif-modal');
        var btn = document.querySelector('.raz-notif-btn');
        if (modal.classList.contains('open')) {
            modal.classList.remove('open');
        } else {
            modal.classList.add('open');
            loadNotifications();
        }
    }

    function loadNotifications() {
        fetch(razLMS.ajaxurl + '?action=raz_get_notifications')
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (d.success) {
                    updateNotifBadge(d.data.unread_count);
                    var list = document.getElementById('notif-list');
                    if (d.data.notifications.length === 0) {
                        list.innerHTML = '<div class="raz-notif-empty">Nenhuma notificação</div>';
                        return;
                    }
                    var html = '';
                    d.data.notifications.forEach(function(n) {
                        var safeTitle = n.title.replace(/"/g, '&quot;');
                        var safeMsg = n.message.replace(/"/g, '&quot;');
                        
                        html += `<div class="raz-notif-item unread" 
                                    data-id="${n.id}"
                                    data-title="${safeTitle}"
                                    data-message="${safeMsg}"
                                    data-date="${n.date}"
                                    data-curso="${n.curso}"
                                    onclick="openNotifDetail(this)">`;
                        html += `<h5>${n.title}</h5>`;
                        html += `<p>${n.message.substring(0, 80) + (n.message.length > 80 ? '...' : '')}</p>`;
                        html += `<small>${n.date} • ${n.curso}</small>`;
                        html += `</div>`;
                    });
                    list.innerHTML = html;
                }
            });
    }

    function updateNotifBadge(count) {
        var badge = document.getElementById('notif-badge');
        if (count > 0) {
            badge.textContent = count > 9 ? '9+' : count;
            badge.style.display = 'flex';
        } else {
            badge.style.display = 'none';
        }
    }

    function openNotifDetail(el) {
        var id = el.getAttribute('data-id');
        var title = el.getAttribute('data-title');
        var message = el.getAttribute('data-message');
        var date = el.getAttribute('data-date');
        var curso = el.getAttribute('data-curso');
        
        document.getElementById('notif-detail-title').innerText = title;
        document.getElementById('notif-detail-message').innerHTML = message;
        document.getElementById('notif-detail-meta').innerHTML = '<span>' + date + '</span><span>' + curso + '</span>';
        
        document.getElementById('notif-detail-modal').classList.add('open');
        el.classList.remove('unread');
        el.style.opacity = '0.6'; 
        
        markNotifRead(id);
    }

    function closeNotifDetail() {
        document.getElementById('notif-detail-modal').classList.remove('open');
    }

    function markNotifRead(id) {
        fetch(razLMS.ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=raz_mark_notification_read&notification_id=' + id
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                updateNotifBadge(d.data.unread_count);
            }
        });
    }

    function markAllRead() {
        fetch(razLMS.ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=raz_mark_all_notifications_read'
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                updateNotifBadge(0);
                document.querySelectorAll('.raz-notif-item').forEach(function(el) { 
                    el.classList.remove('unread');
                    el.style.opacity = '0.6';
                });
            }
        });
    }

    document.addEventListener('click', function(e) {
        var modal = document.getElementById('notif-modal');
        var btn = document.querySelector('.raz-notif-btn');
        if (modal.classList.contains('open') && !modal.contains(e.target) && !btn.contains(e.target)) {
            modal.classList.remove('open');
        }
    });

    fetch(razLMS.ajaxurl + '?action=raz_get_notifications')
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) updateNotifBadge(d.data.unread_count);
        });

</script>

</body>
</html>